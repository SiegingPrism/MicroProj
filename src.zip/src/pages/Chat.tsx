import Navbar from "@/components/Navbar";
import ChatInterface from "@/components/ChatInterface";
import GradientMesh from "@/components/effects/GradientMesh";

const Chat = () => {
  return (
    <div className="min-h-screen bg-background relative">
      <GradientMesh />
      <Navbar />
      <main className="pt-20 px-4 pb-4 relative z-10">
        <ChatInterface />
      </main>
    </div>
  );
};

export default Chat;
