import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Brain, User, BookOpen, Loader2, ArrowRight,
  Code, Briefcase, FlaskConical, Palette, Sparkles,
  CheckCircle2
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import GradientMesh from '@/components/effects/GradientMesh';

const domains = [
  {
    id: 'tech_engineering',
    label: 'Tech & Engineering',
    icon: Code,
    description: 'CS, Software, Data Science, AI/ML, Electronics',
    subjects: ['Machine Learning', 'Web Development', 'Data Structures', 'Cloud Computing', 'Cybersecurity', 'System Design', 'Mobile Development', 'DevOps']
  },
  {
    id: 'business_management',
    label: 'Business & Management',
    icon: Briefcase,
    description: 'MBA, Marketing, Finance, Entrepreneurship, HR',
    subjects: ['Financial Analysis', 'Marketing Strategy', 'Leadership', 'Project Management', 'Economics', 'Business Analytics', 'Entrepreneurship', 'Operations']
  },
  {
    id: 'sciences',
    label: 'Sciences',
    icon: FlaskConical,
    description: 'Physics, Chemistry, Biology, Mathematics, Medicine',
    subjects: ['Quantum Physics', 'Organic Chemistry', 'Molecular Biology', 'Statistics', 'Research Methods', 'Calculus', 'Medical Sciences', 'Astronomy']
  },
  {
    id: 'arts_humanities',
    label: 'Arts & Humanities',
    icon: Palette,
    description: 'Literature, History, Philosophy, Design, Languages',
    subjects: ['Creative Writing', 'Art History', 'Critical Thinking', 'Cultural Studies', 'Ethics', 'Linguistics', 'World History', 'Philosophy']
  },
  {
    id: 'other',
    label: 'Other',
    icon: Sparkles,
    description: 'Cross-disciplinary or specialized fields',
    subjects: ['Study Skills', 'Research Writing', 'Time Management', 'Academic Success', 'Career Planning', 'Public Speaking', 'Critical Analysis']
  },
];

const educationLevels = [
  'High School',
  'Undergraduate',
  'Graduate',
  'PhD',
  'Professional',
];

const Onboarding = () => {
  const [step, setStep] = useState(1);
  const [fullName, setFullName] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<string | null>(null);
  const [educationLevel, setEducationLevel] = useState<string | null>(null);
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [checkingProfile, setCheckingProfile] = useState(true);
  const [userRole, setUserRole] = useState<string | null>(null);
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
      return;
    }

    const checkProfile = async () => {
      if (!user) return;

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (profile?.onboarding_completed) {
        navigate('/dashboard');
      }

      if (profile?.role) {
        setUserRole(profile.role);
      }

      setCheckingProfile(false);
    };

    if (user) {
      checkProfile();
    }
  }, [user, loading, navigate]);

  const handleSubjectToggle = (subject: string) => {
    setSelectedSubjects(prev =>
      prev.includes(subject)
        ? prev.filter(s => s !== subject)
        : [...prev, subject]
    );
  };

  const handleContinue = async () => {
    if (step === 1) {
      if (!fullName.trim()) {
        toast.error('Please enter your name');
        return;
      }
      setStep(2);
    } else if (step === 2) {
      if (!selectedDomain) {
        toast.error('Please select your study domain');
        return;
      }
      setStep(3);
    } else if (step === 3) {
      if (!educationLevel) {
        toast.error('Please select your education level');
        return;
      }
      setStep(4);
    } else if (step === 4) {
      if (selectedSubjects.length === 0) {
        toast.error('Please select at least one subject');
        return;
      }
      await saveProfile();
    }
  };

  const saveProfile = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: fullName,
          domain: selectedDomain as any,
          education_level: educationLevel,
          interests: selectedSubjects,
          onboarding_completed: true,
        })
        .eq('user_id', user.id);

      if (error) {
        toast.error('Failed to save profile');
        console.error(error);
      } else {
        await generateStudySchedule(selectedSubjects, selectedDomain);
        toast.success('Profile completed!');
        navigate('/dashboard');
      }
    } catch (error) {
      toast.error('An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const generateStudySchedule = async (subjects: string[], domain: string | null) => {
    if (!user || subjects.length === 0) return;

    const scheduleEntries = subjects.slice(0, 6).map((subject, index) => ({
      user_id: user.id,
      subject,
      day_of_week: index,
      start_time: '09:00:00',
      end_time: '10:30:00',
      domain: domain,
    }));

    await supabase.from('study_schedules').insert(scheduleEntries);
  };

  if (loading || checkingProfile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const currentDomainSubjects = selectedDomain
    ? domains.find(d => d.id === selectedDomain)?.subjects || []
    : [];

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative">
      <GradientMesh />

      <div className="w-full max-w-2xl relative z-10">
        {/* Progress indicator */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={`h-2 rounded-full transition-all duration-500 ${s === step ? 'w-12 bg-gradient-to-r from-primary to-secondary' : s < step ? 'w-8 bg-primary/50' : 'w-8 bg-white/10'
                }`}
            />
          ))}
        </div>

        {/* Role indicator */}
        {userRole && (
          <div className="text-center mb-4">
            <span className="px-3 py-1 rounded-full bg-primary/20 text-primary text-sm capitalize">
              {userRole}
            </span>
          </div>
        )}

        {/* Step 1: Name */}
        {step === 1 && (
          <div className="bento-card animate-in fade-in duration-300 noise-overlay">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/60 to-secondary/60" />
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center border border-white/10 shadow-inner">
                <User className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Welcome to StudyAI!</h2>
                <p className="text-muted-foreground">Let's personalize your experience</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">What's your name?</label>
                <Input
                  placeholder="Enter your full name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="bg-muted/50 border-border text-lg py-6"
                  autoFocus
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Domain */}
        {step === 2 && (
          <div className="bento-card animate-in fade-in duration-300 noise-overlay">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-secondary/60 to-primary/60" />
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-secondary/20 to-primary/20 flex items-center justify-center border border-white/10 shadow-inner">
                <BookOpen className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">What's your field of study?</h2>
                <p className="text-muted-foreground">We'll customize your learning path</p>
              </div>
            </div>

            <div className="grid gap-3">
              {domains.map((domain) => {
                const Icon = domain.icon;
                return (
                  <button
                    key={domain.id}
                    onClick={() => {
                      setSelectedDomain(domain.id);
                      setSelectedSubjects([]);
                    }}
                    className={`w-full p-4 rounded-xl text-left transition-all ${selectedDomain === domain.id
                      ? 'bg-primary/10 border-2 border-primary shadow-lg shadow-primary/10'
                      : 'bg-white/5 border-2 border-transparent hover:bg-white/10'
                      }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${selectedDomain === domain.id ? 'bg-primary/20' : 'bg-black/20'
                        }`}>
                        <Icon className={`w-5 h-5 ${selectedDomain === domain.id ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">{domain.label}</p>
                        <p className="text-sm text-muted-foreground">{domain.description}</p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 3: Education Level */}
        {step === 3 && (
          <div className="bento-card animate-in fade-in duration-300 noise-overlay">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-accent/60 to-primary/60" />
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center border border-white/10 shadow-inner">
                <Brain className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Education level?</h2>
                <p className="text-muted-foreground">This helps us adjust the complexity</p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {educationLevels.map((level) => (
                <button
                  key={level}
                  onClick={() => setEducationLevel(level)}
                  className={`p-4 rounded-xl text-center transition-all ${educationLevel === level
                    ? 'bg-primary/10 border-2 border-primary shadow-lg shadow-primary/10'
                    : 'bg-white/5 border-2 border-transparent hover:bg-white/10'
                    }`}
                >
                  <p className="font-medium">{level}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 4: Subject Selection */}
        {step === 4 && (
          <div className="bento-card animate-in fade-in duration-300 noise-overlay">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/60 to-accent/60" />
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center border border-white/10 shadow-inner">
                <BookOpen className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Select subjects to study</h2>
                <p className="text-muted-foreground">We'll create a personalized schedule for you</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {currentDomainSubjects.map((subject) => (
                <button
                  key={subject}
                  onClick={() => handleSubjectToggle(subject)}
                  className={`p-4 rounded-xl text-left transition-all flex items-center gap-3 ${selectedSubjects.includes(subject)
                    ? 'bg-primary/20 border-2 border-primary'
                    : 'bg-muted/50 border-2 border-transparent hover:bg-muted'
                    }`}
                >
                  {selectedSubjects.includes(subject) ? (
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                  ) : (
                    <div className="w-5 h-5 rounded-full border-2 border-muted-foreground shrink-0" />
                  )}
                  <span className="font-medium text-sm">{subject}</span>
                </button>
              ))}
            </div>

            {selectedSubjects.length > 0 && (
              <div className="mt-6 p-4 rounded-xl bg-primary/10 border border-primary/20">
                <p className="text-sm text-muted-foreground mb-2">
                  Your weekly study schedule will include:
                </p>
                <div className="flex flex-wrap gap-2">
                  {selectedSubjects.map((subject) => (
                    <span key={subject} className="px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-medium">
                      {subject}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Continue button */}
        <div className="mt-6 flex justify-between items-center">
          {step > 1 && (
            <Button variant="ghost" onClick={() => setStep(step - 1)}>
              Back
            </Button>
          )}
          <Button
            onClick={handleContinue}
            className="ml-auto text-white"
            style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
            disabled={isLoading}
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : step === 4 ? (
              'Complete Setup'
            ) : (
              <>
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Onboarding;