import { useState, useEffect } from 'react';
import { Trophy, Clock, Target, BookOpen, Flame, Medal, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import Navbar from '@/components/Navbar';
import GradientMesh from '@/components/effects/GradientMesh';

type SortKey = 'study_time' | 'xp' | 'quizzes' | 'streaks';

interface LeaderboardEntry {
  user_id: string;
  display_name: string;
  total_study_minutes: number;
  total_sessions: number;
  total_quizzes: number;
  avg_quiz_score: number;
  topics_completed: number;
  current_streak: number;
}

const calculateXP = (e: LeaderboardEntry) =>
  e.total_study_minutes * 2 + e.topics_completed * 50 + e.total_quizzes * 30;

const tabs: { key: SortKey; label: string; icon: any }[] = [
  { key: 'xp', label: 'XP & Levels', icon: Trophy },
  { key: 'study_time', label: 'Study Time', icon: Clock },
  { key: 'quizzes', label: 'Quiz Scores', icon: Target },
  { key: 'streaks', label: 'Streaks', icon: Flame },
];

const Leaderboard = () => {
  const { user } = useAuth();
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<SortKey>('xp');

  useEffect(() => {
    const fetchLeaderboard = async () => {
      const { data, error } = await supabase.rpc('get_leaderboard');
      if (!error && data) setEntries(data as LeaderboardEntry[]);
      setLoading(false);
    };
    fetchLeaderboard();
  }, []);

  const sorted = [...entries].sort((a, b) => {
    switch (activeTab) {
      case 'xp': return calculateXP(b) - calculateXP(a);
      case 'study_time': return b.total_study_minutes - a.total_study_minutes;
      case 'quizzes': return b.avg_quiz_score - a.avg_quiz_score;
      case 'streaks': return b.current_streak - a.current_streak;
    }
  });

  const getStatValue = (e: LeaderboardEntry) => {
    switch (activeTab) {
      case 'xp': return `${calculateXP(e).toLocaleString()} XP`;
      case 'study_time': return `${Math.round(e.total_study_minutes / 60)}h ${e.total_study_minutes % 60}m`;
      case 'quizzes': return `${Math.round(e.avg_quiz_score)}% avg`;
      case 'streaks': return `${e.current_streak} days`;
    }
  };

  const medalColors = ['text-amber-400', 'text-gray-300', 'text-orange-600'];

  return (
    <div className="min-h-screen bg-background relative">
      <GradientMesh />
      <Navbar />
      <main className="pt-24 pb-12 px-4 max-w-4xl mx-auto relative z-10">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2">
            <span className="gradient-shimmer">Leaderboard</span>
          </h1>
          <p className="text-muted-foreground">See how you rank among fellow students</p>
        </div>

        {/* Tabs */}
        <div className="flex justify-center mb-8">
          <div className="glass p-1.5 rounded-full flex gap-1 overflow-x-auto max-w-full">
            {tabs.map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-medium transition-all whitespace-nowrap ${activeTab === tab.key
                  ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : sorted.length === 0 ? (
          <div className="text-center py-20 glass-morphism rounded-2xl">
            <Trophy className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No rankings yet</h3>
            <p className="text-muted-foreground">Start studying to appear on the leaderboard!</p>
          </div>
        ) : (
          <div className="space-y-3 stagger-fade-in">
            {/* Top 3 podium */}
            {sorted.length >= 3 && (
              <div className="grid grid-cols-3 gap-4 mb-8">
                {[1, 0, 2].map(idx => {
                  const e = sorted[idx];
                  if (!e) return null;
                  const rank = idx + 1;
                  const isCenter = idx === 0;
                  return (
                    <div
                      key={e.user_id}
                      className={`bento-card text-center ${isCenter ? 'scale-110 shadow-2xl shadow-primary/20 z-10 !border-primary/50' : 'opacity-90 scale-[0.98]'} ${e.user_id === user?.id ? 'ring-2 ring-primary' : ''}`}
                    >
                      {isCenter && (
                        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-primary via-secondary to-accent" />
                      )}
                      <Medal className={`w-8 h-8 mx-auto mb-2 ${medalColors[rank - 1]}`} />
                      <p className="font-semibold text-sm truncate">{e.display_name}</p>
                      <p className="text-primary font-bold text-lg mt-1">{getStatValue(e)}</p>
                      <p className="text-xs text-muted-foreground mt-1">#{rank}</p>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Rest of list */}
            {sorted.slice(3).map((e, i) => (
              <div
                key={e.user_id}
                className={`bento-card flex items-center gap-4 group ${e.user_id === user?.id ? 'bg-primary/5 !border-primary/30 ring-1 ring-primary/30' : ''}`}
              >
                <span className={`text-lg font-bold w-8 text-center ${e.user_id === user?.id ? 'text-primary' : 'text-muted-foreground'}`}>
                  {i + 4}
                </span>
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center text-primary font-bold shadow-inner border border-white/10">
                  {e.display_name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">{e.display_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {e.total_sessions} sessions • {e.topics_completed} topics
                  </p>
                </div>
                <span className="text-primary font-bold">{getStatValue(e)}</span>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Leaderboard;
