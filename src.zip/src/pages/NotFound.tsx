import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Brain, ArrowLeft, Home } from "lucide-react";
import GradientMesh from "@/components/effects/GradientMesh";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6 relative overflow-hidden">
      <GradientMesh />

      <div className="relative z-10 text-center max-w-md mx-auto">
        {/* Logo */}
        <Link to="/" className="inline-flex items-center gap-2.5 mb-12 group">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}>
            <Brain className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg">Study<span className="text-primary">AI</span></span>
        </Link>

        {/* 404 display */}
        <div className="mb-6 relative">
          <span className="text-[120px] md:text-[160px] font-extrabold leading-none select-none"
            style={{
              background: 'linear-gradient(135deg, hsl(var(--primary) / 0.15) 0%, hsl(var(--secondary) / 0.1) 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>
            404
          </span>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-[120px] md:text-[160px] font-extrabold leading-none select-none"
              style={{
                background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                opacity: 0.9,
              }}>
              404
            </span>
          </div>
        </div>

        <h1 className="text-2xl font-extrabold tracking-tight mb-3">Page not found</h1>
        <p className="text-muted-foreground text-sm mb-8 leading-relaxed">
          We couldn't find the page you're looking for. It might have been moved or never existed.
        </p>

        <div className="flex items-center justify-center gap-3">
          <Link to="/"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold text-white transition-all hover:opacity-90 hover:scale-[1.02] shadow-lg shadow-primary/20"
            style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}>
            <Home className="w-4 h-4" />
            Back to Home
          </Link>
          <button onClick={() => window.history.back()}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold border border-border hover:border-primary/30 hover:bg-white/5 transition-all">
            <ArrowLeft className="w-4 h-4" />
            Go Back
          </button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
