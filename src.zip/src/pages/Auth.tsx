import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Brain, Mail, Lock, Loader2, GraduationCap, ArrowLeft, Users, Sparkles, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';

const perks = [
  "Personalized AI study plans",
  "Instant answers to any question",
  "Progress tracking & analytics",
  "24/7 availability, always free",
];

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<'student' | 'teacher'>('student');
  const [isLoading, setIsLoading] = useState(false);
  const { signIn, signUp, user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && user) {
      navigate('/onboarding');
    }
  }, [user, loading, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!email || !password) {
      toast.error('Please fill in all fields');
      setIsLoading(false);
      return;
    }

    if (password.length < 6) {
      toast.error('Password must be at least 6 characters');
      setIsLoading(false);
      return;
    }

    try {
      if (isLogin) {
        const { error } = await signIn(email, password);
        if (error) {
          if (error.message.includes('Invalid login credentials')) {
            toast.error('Invalid email or password');
          } else {
            toast.error(error.message);
          }
        } else {
          toast.success('Welcome back!');
          navigate('/onboarding');
        }
      } else {
        const { error } = await signUp(email, password, selectedRole);
        if (error) {
          if (error.message.includes('User already registered')) {
            toast.error('An account with this email already exists');
          } else {
            toast.error(error.message);
          }
        } else {
          toast.success('Account created successfully!');
          navigate('/onboarding');
        }
      }
    } catch (error) {
      toast.error('An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}>
            <Brain className="w-6 h-6 text-white" />
          </div>
          <Loader2 className="w-5 h-5 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex overflow-hidden">
      {/* Left panel — branding & perks (desktop only) */}
      <div className="hidden lg:flex flex-col justify-between w-[44%] p-12 relative overflow-hidden">
        {/* Background gradients */}
        <div className="absolute inset-0"
          style={{ background: 'linear-gradient(160deg, hsl(var(--background)) 0%, hsl(220 20% 7%) 100%)' }} />
        <div className="absolute top-0 left-0 w-full h-full opacity-100"
          style={{ background: 'radial-gradient(ellipse 80% 60% at 10% 0%, hsl(var(--primary) / 0.2) 0%, transparent 60%)' }} />
        <div className="absolute bottom-0 right-0 w-full h-full opacity-100"
          style={{ background: 'radial-gradient(ellipse 60% 50% at 90% 100%, hsl(var(--secondary) / 0.15) 0%, transparent 60%)' }} />

        {/* Content */}
        <div className="relative z-10">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group w-fit">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}>
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-lg">Study<span className="text-primary">AI</span></span>
          </Link>
        </div>

        <div className="relative z-10 space-y-8">
          <div>
            <h2 className="text-3xl font-extrabold tracking-tight leading-tight mb-3">
              Unlock your full
              <span className="block" style={{
                background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}>
                learning potential
              </span>
            </h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Join over 10,000 students achieving better results with AI-powered personalized study.
            </p>
          </div>

          <ul className="space-y-3.5">
            {perks.map((perk) => (
              <li key={perk} className="flex items-center gap-3 text-sm text-foreground/80">
                <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: 'hsl(var(--primary) / 0.15)' }}>
                  <CheckCircle2 className="w-3.5 h-3.5 text-primary" />
                </div>
                {perk}
              </li>
            ))}
          </ul>
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-2 text-xs text-muted-foreground/60">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Trusted by 10,000+ learners worldwide</span>
          </div>
        </div>
      </div>

      {/* Right panel — auth form */}
      <div className="flex-1 flex items-center justify-center p-6 relative">
        {/* Subtle background */}
        <div className="absolute inset-0"
          style={{ background: 'radial-gradient(ellipse 60% 40% at 80% 20%, hsl(var(--secondary) / 0.06) 0%, transparent 60%)' }} />

        <div className="w-full max-w-md relative z-10">
          {/* Back link */}
          <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors group">
            <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
            Back to home
          </Link>

          {/* Mobile logo */}
          <div className="flex items-center gap-3 mb-8 lg:hidden">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}>
              <Brain className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-bold text-lg leading-none">Study<span className="text-primary">AI</span></div>
              <div className="text-xs text-muted-foreground mt-0.5">Your AI Study Companion</div>
            </div>
          </div>

          {/* Heading */}
          <div className="mb-8">
            <h1 className="text-2xl font-extrabold tracking-tight mb-1">
              {isLogin ? 'Welcome back 👋' : 'Create your account'}
            </h1>
            <p className="text-sm text-muted-foreground">
              {isLogin
                ? 'Sign in to continue your learning journey.'
                : 'Start learning smarter with AI today.'}
            </p>
          </div>

          {/* Toggle tabs */}
          <div className="flex gap-1 p-1 rounded-xl mb-8 border border-white/10"
            style={{ background: 'hsl(var(--card))' }}>
            {(['Sign In', 'Sign Up'] as const).map((tab) => {
              const active = tab === 'Sign In' ? isLogin : !isLogin;
              return (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setIsLogin(tab === 'Sign In')}
                  className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all duration-200 ${active
                    ? 'text-white shadow-md'
                    : 'text-muted-foreground hover:text-foreground'
                    }`}
                  style={active ? { background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' } : {}}
                >
                  {tab}
                </button>
              );
            })}
          </div>

          {/* Role selection for signup */}
          {!isLogin && (
            <div className="mb-6">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3 block">I am a...</label>
              <div className="grid grid-cols-2 gap-3">
                {([
                  { role: 'student' as const, icon: GraduationCap, label: 'Student' },
                  { role: 'teacher' as const, icon: Users, label: 'Teacher' },
                ]).map(({ role, icon: Icon, label }) => (
                  <button
                    key={role}
                    type="button"
                    onClick={() => setSelectedRole(role)}
                    className={`p-4 rounded-xl flex flex-col items-center gap-2 transition-all border text-sm font-medium ${selectedRole === role
                      ? 'border-primary/50 text-primary'
                      : 'border-white/10 text-muted-foreground hover:border-white/20 hover:text-foreground'
                      }`}
                    style={selectedRole === role ? { background: 'hsl(var(--primary) / 0.1)' } : { background: 'hsl(var(--card))' }}
                  >
                    <Icon className={`w-5 h-5 ${selectedRole === role ? 'text-primary' : 'text-muted-foreground'}`} />
                    {label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                <Input
                  type="email"
                  placeholder="your.email@university.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 h-11 rounded-xl border-white/10 focus:border-primary/50 bg-white/4 placeholder:text-muted-foreground/40 transition-colors"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 h-11 rounded-xl border-white/10 focus:border-primary/50 bg-white/4 placeholder:text-muted-foreground/40 transition-colors"
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full h-11 rounded-xl font-semibold mt-2 border-0 shadow-lg shadow-primary/20 hover:opacity-90 transition-all"
              disabled={isLoading}
              style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {isLogin ? 'Signing in...' : 'Creating account...'}
                </>
              ) : (
                isLogin ? 'Sign In' : `Create Account as ${selectedRole === 'student' ? 'Student' : 'Teacher'}`
              )}
            </Button>
          </form>

          {/* Footer hint */}
          <p className="mt-6 text-center text-xs text-muted-foreground/60">
            By continuing, you agree to our{' '}
            <span className="text-muted-foreground hover:text-primary cursor-pointer transition-colors">Terms of Service</span>
            {' & '}
            <span className="text-muted-foreground hover:text-primary cursor-pointer transition-colors">Privacy Policy</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;