import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import {
  Brain, MessageCircle, BookOpen, Loader2, LogOut,
  Code, Briefcase, FlaskConical, Palette, Sparkles,
  ArrowRight, CheckCircle, Calendar, BarChart3, Timer, Smile, Wrench
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { StudyProgressTracker } from '@/components/StudyProgressTracker';
import { StudySchedule } from '@/components/StudySchedule';
import { AnalyticsDashboard } from '@/components/analytics/AnalyticsDashboard';
import { useStudySession } from '@/hooks/useStudySession';
import GradientMesh from '@/components/effects/GradientMesh';
import PomodoroTimer from '@/components/focus/PomodoroTimer';
import MoodTracker from '@/components/wellness/MoodTracker';
import { AchievementSystem } from '@/components/gamification/AchievementSystem';
import DailyStreak from '@/components/streak/DailyStreak';
import DailyChallenges from '@/components/challenges/DailyChallenges';
import GoalTracker from '@/components/goals/GoalTracker';
import WeeklyReport from '@/components/analytics/WeeklyReport';
import AmbientSounds from '@/components/ambient/AmbientSounds';

const domainData: Record<string, {
  icon: any;
  color: string;
  topics: { title: string; description: string; difficulty: string }[];
  resources: string[];
}> = {
  tech_engineering: {
    icon: Code,
    color: 'text-emerald-400',
    topics: [
      { title: 'Machine Learning Fundamentals', description: 'Learn neural networks, deep learning, and AI concepts', difficulty: 'Intermediate' },
      { title: 'Data Structures & Algorithms', description: 'Master essential CS concepts for coding interviews', difficulty: 'Advanced' },
      { title: 'Web Development', description: 'Build modern web apps with React, Node.js', difficulty: 'Beginner' },
      { title: 'Cloud Computing', description: 'AWS, Azure, and GCP fundamentals', difficulty: 'Intermediate' },
      { title: 'Cybersecurity Basics', description: 'Learn security principles and best practices', difficulty: 'Beginner' },
      { title: 'System Design', description: 'Design scalable distributed systems', difficulty: 'Advanced' },
    ],
    resources: ['LeetCode', 'freeCodeCamp', 'Coursera', 'GitHub'],
  },
  business_management: {
    icon: Briefcase,
    color: 'text-amber-400',
    topics: [
      { title: 'Financial Analysis', description: 'Learn to read financial statements and valuations', difficulty: 'Intermediate' },
      { title: 'Marketing Strategy', description: 'Digital marketing, branding, and growth hacking', difficulty: 'Beginner' },
      { title: 'Leadership & Management', description: 'Team building, communication, and decision making', difficulty: 'Intermediate' },
      { title: 'Entrepreneurship', description: 'Startup fundamentals, pitching, and fundraising', difficulty: 'Beginner' },
      { title: 'Operations Management', description: 'Supply chain, logistics, and process optimization', difficulty: 'Advanced' },
      { title: 'Business Analytics', description: 'Data-driven decision making with Excel and SQL', difficulty: 'Intermediate' },
    ],
    resources: ['Harvard Business Review', 'McKinsey Insights', 'Bloomberg', 'LinkedIn Learning'],
  },
  sciences: {
    icon: FlaskConical,
    color: 'text-teal-400',
    topics: [
      { title: 'Research Methodology', description: 'Design experiments and analyze scientific data', difficulty: 'Intermediate' },
      { title: 'Organic Chemistry', description: 'Reactions, mechanisms, and synthesis', difficulty: 'Advanced' },
      { title: 'Molecular Biology', description: 'DNA, RNA, proteins, and gene expression', difficulty: 'Intermediate' },
      { title: 'Quantum Physics', description: 'Wave functions, quantum mechanics fundamentals', difficulty: 'Advanced' },
      { title: 'Statistics & Probability', description: 'Statistical analysis for research', difficulty: 'Beginner' },
      { title: 'Medical Sciences', description: 'Anatomy, physiology, and pathology basics', difficulty: 'Intermediate' },
    ],
    resources: ['PubMed', 'Nature', 'Khan Academy', 'Wolfram Alpha'],
  },
  arts_humanities: {
    icon: Palette,
    color: 'text-rose-400',
    topics: [
      { title: 'Creative Writing', description: 'Fiction, poetry, and storytelling techniques', difficulty: 'Beginner' },
      { title: 'Art History', description: 'Major movements from Renaissance to Contemporary', difficulty: 'Intermediate' },
      { title: 'Philosophy & Ethics', description: 'Critical thinking and moral reasoning', difficulty: 'Intermediate' },
      { title: 'Cultural Studies', description: 'Society, media, and cultural analysis', difficulty: 'Beginner' },
      { title: 'Linguistics', description: 'Language structure, syntax, and semantics', difficulty: 'Advanced' },
      { title: 'World History', description: 'Major events and civilizations', difficulty: 'Beginner' },
    ],
    resources: ['JSTOR', 'Stanford Encyclopedia', 'Google Arts & Culture', 'OpenLibrary'],
  },
  other: {
    icon: Sparkles,
    color: 'text-amber-400',
    topics: [
      { title: 'Study Skills', description: 'Memory techniques, note-taking, and focus', difficulty: 'Beginner' },
      { title: 'Academic Writing', description: 'Research papers, citations, and structure', difficulty: 'Intermediate' },
      { title: 'Time Management', description: 'Productivity systems and goal setting', difficulty: 'Beginner' },
      { title: 'Career Planning', description: 'Resume building, interviews, and networking', difficulty: 'Beginner' },
      { title: 'Critical Thinking', description: 'Logic, reasoning, and problem solving', difficulty: 'Intermediate' },
      { title: 'Presentation Skills', description: 'Public speaking and visual communication', difficulty: 'Beginner' },
    ],
    resources: ['TED Talks', 'Skillshare', 'Notion', 'Canva'],
  },
};

interface Profile {
  full_name: string | null;
  domain: string | null;
  education_level: string | null;
  role: string | null;
  interests: string[] | null;
}

const Dashboard = () => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [completedTopics, setCompletedTopics] = useState<string[]>([]);
  const [showSchedule, setShowSchedule] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(true);
  const [showFocusTools, setShowFocusTools] = useState(false);
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const { markTopicCompleted } = useStudySession({ userId: user?.id });

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
      return;
    }

    const fetchProfile = async () => {
      if (!user) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('full_name, domain, education_level, role, interests')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) {
        console.error(error);
      } else if (data && !data.domain) {
        navigate('/onboarding');
      } else {
        setProfile(data);
      }

      const { data: topics } = await supabase
        .from('completed_topics')
        .select('topic')
        .eq('user_id', user.id);

      setCompletedTopics(topics?.map(t => t.topic) || []);
      setIsLoading(false);
    };

    if (user) {
      fetchProfile();
    }
  }, [user, loading, navigate]);

  const handleSignOut = async () => {
    await signOut();
    toast.success('Signed out successfully');
    navigate('/');
  };

  if (loading || isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const domainInfo = profile?.domain ? domainData[profile.domain] : domainData.other;
  const DomainIcon = domainInfo.icon;

  return (
    <div className="min-h-screen bg-background relative">
      {/* Gradient Mesh Background */}
      <GradientMesh />

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-border">
        <div className="max-w-7xl mx-auto px-6 h-[68px] flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}>
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-[17px] tracking-tight">Study<span className="text-primary">AI</span></span>
          </Link>

          <div className="flex items-center gap-2 flex-wrap justify-end">
            <Button
              variant={showFocusTools ? "default" : "ghost"}
              size="sm"
              className={`gap-2 rounded-lg text-xs font-semibold ${showFocusTools ? 'shadow-md shadow-primary/20' : 'text-muted-foreground hover:text-foreground hover:bg-white/5 border border-border'}`}
              style={showFocusTools ? { background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)', border: 'none' } : {}}
              onClick={() => setShowFocusTools(!showFocusTools)}
            >
              <Timer className="w-3.5 h-3.5" />
              Focus
            </Button>
            <Button
              variant={showAnalytics ? "default" : "ghost"}
              size="sm"
              className={`gap-2 rounded-lg text-xs font-semibold ${showAnalytics ? 'shadow-md shadow-primary/20' : 'text-muted-foreground hover:text-foreground hover:bg-white/5 border border-border'}`}
              style={showAnalytics ? { background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)', border: 'none' } : {}}
              onClick={() => setShowAnalytics(!showAnalytics)}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              Analytics
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 rounded-lg text-xs font-semibold text-muted-foreground hover:text-foreground hover:bg-white/5 border border-border"
              onClick={() => setShowSchedule(!showSchedule)}
            >
              <Calendar className="w-3.5 h-3.5" />
              Schedule
            </Button>
            <Link to="/leaderboard">
              <Button variant="ghost" size="sm" className="gap-2 rounded-lg text-xs font-semibold text-muted-foreground hover:text-foreground hover:bg-white/5 border border-border">
                <BarChart3 className="w-3.5 h-3.5" />Leaderboard
              </Button>
            </Link>
            <Link to="/tools">
              <Button variant="ghost" size="sm" className="gap-2 rounded-lg text-xs font-semibold text-muted-foreground hover:text-foreground hover:bg-white/5 border border-border">
                <Wrench className="w-3.5 h-3.5" />Tools
              </Button>
            </Link>
            <Link to="/chat">
              <Button size="sm" className="gap-2 rounded-lg text-xs font-semibold border-0 shadow-md shadow-primary/20 text-white"
                style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}>
                <MessageCircle className="w-3.5 h-3.5" />AI Chat
              </Button>
            </Link>
            <Link to="/settings">
              <Button variant="ghost" size="icon" className="w-8 h-8 rounded-lg hover:bg-white/5">
                <Wrench className="w-3.5 h-3.5 text-muted-foreground" />
              </Button>
            </Link>
            <Button variant="ghost" size="icon" className="w-8 h-8 rounded-lg hover:bg-white/5" onClick={handleSignOut}>
              <LogOut className="w-3.5 h-3.5 text-muted-foreground" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="pt-24 pb-12 px-4 max-w-7xl mx-auto relative z-10">
        {/* Welcome section + DailyStreak */}
        <div className="mb-8 grid md:grid-cols-[1fr_auto] gap-6 items-start">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">
              Welcome back, <span className="gradient-text">{profile?.full_name || 'Student'}</span>!
            </h1>
            <div className="flex items-center gap-2 text-muted-foreground mb-4">
              <DomainIcon className={`w-5 h-5 ${domainInfo.color}`} />
              <span>{profile?.domain?.replace('_', ' & ').replace(/^\w/, c => c.toUpperCase())} • {profile?.education_level}</span>
              {profile?.role && (
                <span className="ml-2 px-2 py-0.5 rounded-full bg-primary/20 text-primary text-xs capitalize">
                  {profile.role}
                </span>
              )}
            </div>
            {/* Quick access links */}
            <div className="flex flex-wrap gap-2">
              {[
                { to: '/flashcards', label: 'Flashcards', icon: BookOpen },
                { to: '/notes', label: 'Notes', icon: BookOpen },
                { to: '/exam-prep', label: 'Exam Prep', icon: Brain },
                { to: '/study-groups', label: 'Study Groups', icon: Sparkles },
                { to: '/profile', label: 'Profile', icon: Sparkles },
              ].map(item => (
                <Link key={item.to} to={item.to}>
                  <Button variant="ghost" size="sm" className="gap-1.5 text-xs rounded-lg border border-border hover:bg-primary/10 hover:text-primary hover:border-primary/20 transition-all">
                    <item.icon className="w-3 h-3" />
                    {item.label}
                  </Button>
                </Link>
              ))}
            </div>
          </div>
          <div className="w-full md:w-80">
            <DailyStreak />
          </div>
        </div>

        {/* Focus & Wellness Tools */}
        {showFocusTools && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-primary animate-pulse" />
              <h2 className="text-xl font-semibold">Focus & Wellness</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="animate-fade-in">
                <PomodoroTimer />
              </div>
              <div className="animate-fade-in" style={{ animationDelay: '0.1s' }}>
                <MoodTracker />
              </div>
            </div>
          </div>
        )}

        {/* Daily Challenges & Goals */}
        <div className="mb-8 grid md:grid-cols-2 gap-6">
          <div className="animate-fade-in">
            <DailyChallenges />
          </div>
          <div className="animate-fade-in" style={{ animationDelay: '0.1s' }}>
            <GoalTracker />
          </div>
        </div>

        {/* AI Analytics Dashboard */}
        {showAnalytics && user && (
          <div className="mb-8">
            <AnalyticsDashboard userId={user.id} domain={profile?.domain || null} />
          </div>
        )}

        {/* Study Schedule */}
        {showSchedule && user && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Your Study Schedule</h2>
            <StudySchedule userId={user.id} />
          </div>
        )}

        {/* Study Progress Tracker */}
        {!showAnalytics && !showFocusTools && user && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Your Study Progress</h2>
            <StudyProgressTracker userId={user.id} />
          </div>
        )}

        {/* Selected Subjects */}
        {profile?.interests && profile.interests.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Your Subjects</h2>
            <div className="flex flex-wrap gap-2">
              {profile.interests.map((subject) => (
                <Link
                  key={subject}
                  to={`/chat?topic=${encodeURIComponent(subject)}`}
                  className="px-4 py-2 rounded-full bg-primary/15 text-primary hover:bg-primary/25 transition-colors font-medium text-sm"
                >
                  {subject}
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Recommended Topics — Bento Grid */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Recommended Topics for You</h2>
            <Link to="/chat" className="text-primary text-sm hover:underline flex items-center gap-1">
              Ask AI for more <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {domainInfo.topics.map((topic) => {
              const isCompleted = completedTopics.includes(topic.title);
              return (
                <div
                  key={topic.title}
                  className={`bento-card transition-colors group ${isCompleted ? 'border-2 border-primary/50 bg-primary/5' : ''}`}
                >
                  <div className="flex items-start justify-between mb-3">
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5 text-primary" />
                    ) : (
                      <BookOpen className="w-5 h-5 text-primary" />
                    )}
                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-1 rounded-full ${topic.difficulty === 'Beginner' ? 'bg-emerald-500/20 text-emerald-400' :
                        topic.difficulty === 'Intermediate' ? 'bg-amber-500/20 text-amber-400' :
                          'bg-rose-500/20 text-rose-400'
                        }`}>
                        {topic.difficulty}
                      </span>
                    </div>
                  </div>
                  <h3 className="font-semibold mb-2">{topic.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{topic.description}</p>
                  <div className="flex gap-2">
                    <Link
                      to={`/chat?topic=${encodeURIComponent(topic.title)}`}
                      className="text-xs text-primary hover:underline font-medium"
                    >
                      Study with AI →
                    </Link>
                    {!isCompleted && (
                      <button
                        onClick={async () => {
                          await markTopicCompleted(topic.title, profile?.domain || undefined);
                          setCompletedTopics(prev => [...prev, topic.title]);
                          toast.success(`Marked "${topic.title}" as completed!`);
                        }}
                        className="text-xs text-muted-foreground hover:text-primary ml-auto"
                      >
                        Mark complete
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Resources */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Recommended Resources</h2>
          <div className="flex flex-wrap gap-3">
            {domainInfo.resources.map((resource) => (
              <span key={resource} className="px-4 py-2 rounded-full bg-muted/50 border border-border text-sm hover:bg-muted transition-colors cursor-pointer font-medium">
                {resource}
              </span>
            ))}
          </div>
        </div>

        {/* Achievements */}
        {user && (
          <div className="mb-8 mt-8">
            <AchievementSystem />
          </div>
        )}

        {/* Weekly Report */}
        <div className="mb-8">
          <WeeklyReport />
        </div>

        {/* CTA */}
        <div className="mt-12 rounded-2xl p-px overflow-hidden"
          style={{ background: 'linear-gradient(135deg, hsl(var(--primary) / 0.4) 0%, hsl(var(--secondary) / 0.4) 50%, hsl(var(--accent) / 0.4) 100%)' }}>
          <div className="rounded-[15px] p-8 md:p-10 text-center flex flex-col md:flex-row items-center justify-between gap-6"
            style={{ background: 'linear-gradient(160deg, hsl(var(--card)) 0%, hsl(var(--background)) 100%)' }}>
            <div className="text-left">
              <h2 className="text-2xl font-extrabold tracking-tight mb-1">Ready to learn something new?</h2>
              <p className="text-muted-foreground text-sm">Chat with our AI to get personalized explanations and study help</p>
            </div>
            <Link to="/chat" className="flex-shrink-0">
              <Button size="lg" className="gap-2 font-semibold rounded-xl border-0 shadow-lg shadow-primary/20 hover:opacity-90 text-white"
                style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}>
                <MessageCircle className="w-5 h-5" />
                Start Learning with AI
              </Button>
            </Link>
          </div>
        </div>
      </main>

      {/* Ambient Sounds Floating Player */}
      <AmbientSounds />
    </div>
  );
};

export default Dashboard;