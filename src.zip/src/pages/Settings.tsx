import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Brain, User, Palette, Bell, Shield, Loader2, Save, ArrowLeft, Trash2, Moon, Sun } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import Navbar from '@/components/Navbar';
import GradientMesh from '@/components/effects/GradientMesh';
import { useTheme } from '@/hooks/useTheme';

const Settings = () => {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const [profile, setProfile] = useState({
    full_name: '',
    email: '',
    education_level: '',
    domain: '',
    interests: [] as string[],
  });
  const [notifications, setNotifications] = useState({
    studyReminders: true,
    achievementAlerts: true,
    weeklyReport: true,
    communityUpdates: false,
  });
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
      return;
    }
    if (user) fetchProfile();
  }, [user, loading]);

  const fetchProfile = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('profiles')
      .select('full_name, email, education_level, domain, interests')
      .eq('user_id', user.id)
      .maybeSingle();
    if (data) {
      setProfile({
        full_name: data.full_name || '',
        email: data.email || user.email || '',
        education_level: data.education_level || '',
        domain: data.domain || '',
        interests: data.interests || [],
      });
    }
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from('profiles')
      .update({
        full_name: profile.full_name,
        education_level: profile.education_level,
        domain: profile.domain as any,
        interests: profile.interests,
      })
      .eq('user_id', user.id);
    setSaving(false);
    if (error) toast.error('Failed to update profile');
    else toast.success('Profile updated!');
  };

  const handleChangePassword = async () => {
    if (newPassword !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    if (newPassword.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) toast.error(error.message);
    else {
      toast.success('Password updated!');
      setNewPassword('');
      setConfirmPassword('');
    }
  };

  const handleDeleteAccount = async () => {
    if (!confirm('Are you sure you want to delete your account? This cannot be undone.')) return;
    await signOut();
    toast.success('Signed out. Contact support to delete your account data.');
    navigate('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background relative">
      <GradientMesh />
      <Navbar />
      <main className="pt-24 pb-12 px-4 max-w-3xl mx-auto relative z-10">
        <div className="flex items-center gap-3 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-3xl font-bold">Settings</h1>
        </div>

        {/* Profile Section */}
        <section className="bento-card mb-6">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/50 to-secondary/50" />
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
              <User className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-bold">Profile</h2>
              <p className="text-sm text-muted-foreground">Manage your personal information</p>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" value={profile.full_name} onChange={e => setProfile(p => ({ ...p, full_name: e.target.value }))} />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" value={profile.email} disabled className="opacity-60" />
              <p className="text-xs text-muted-foreground mt-1">Email cannot be changed</p>
            </div>
            <div>
              <Label>Education Level</Label>
              <Select value={profile.education_level} onValueChange={v => setProfile(p => ({ ...p, education_level: v }))}>
                <SelectTrigger><SelectValue placeholder="Select level" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="high_school">High School</SelectItem>
                  <SelectItem value="undergraduate">Undergraduate</SelectItem>
                  <SelectItem value="graduate">Graduate</SelectItem>
                  <SelectItem value="postgraduate">Postgraduate</SelectItem>
                  <SelectItem value="professional">Professional</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Study Domain</Label>
              <Select value={profile.domain} onValueChange={v => setProfile(p => ({ ...p, domain: v }))}>
                <SelectTrigger><SelectValue placeholder="Select domain" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="tech_engineering">Tech & Engineering</SelectItem>
                  <SelectItem value="business_management">Business & Management</SelectItem>
                  <SelectItem value="sciences">Sciences</SelectItem>
                  <SelectItem value="arts_humanities">Arts & Humanities</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleSaveProfile} disabled={saving} className="gap-2">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Save Profile
            </Button>
          </div>
        </section>

        {/* Theme Section */}
        <section className="bento-card mb-6">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-secondary/50 to-accent/50" />
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-secondary/20 flex items-center justify-center">
              <Palette className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <h2 className="text-xl font-bold">Appearance</h2>
              <p className="text-sm text-muted-foreground">Customize how StudyAI looks</p>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {theme === 'dark' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              <span>{theme === 'dark' ? 'Dark' : 'Light'} Mode</span>
            </div>
            <Switch checked={theme === 'dark'} onCheckedChange={toggleTheme} />
          </div>
        </section>

        {/* Notifications Section */}
        <section className="bento-card mb-6">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-accent/50 to-primary/50" />
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
              <Bell className="w-5 h-5 text-accent" />
            </div>
            <div>
              <h2 className="text-xl font-bold">Notifications</h2>
              <p className="text-sm text-muted-foreground">Control what alerts you receive</p>
            </div>
          </div>
          <div className="space-y-4">
            {Object.entries(notifications).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                <Switch checked={value} onCheckedChange={v => setNotifications(n => ({ ...n, [key]: v }))} />
              </div>
            ))}
          </div>
        </section>

        {/* Account Section */}
        <section className="bento-card mb-6 !border-rose-500/20 bg-rose-500/5">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-rose-500/50 to-orange-500/50" />
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-rose-500/20 flex items-center justify-center">
              <Shield className="w-5 h-5 text-rose-500" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-rose-500">Danger Zone</h2>
              <p className="text-sm text-rose-400/80">Irreversible account actions</p>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <Label htmlFor="new-password">New Password</Label>
              <Input id="new-password" type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="Enter new password" />
            </div>
            <div>
              <Label htmlFor="confirm-password">Confirm Password</Label>
              <Input id="confirm-password" type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Confirm new password" />
            </div>
            <Button onClick={handleChangePassword} variant="outline">Change Password</Button>
            <Separator />
            <Button onClick={handleDeleteAccount} variant="destructive" className="gap-2">
              <Trash2 className="w-4 h-4" />
              Delete Account
            </Button>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Settings;
