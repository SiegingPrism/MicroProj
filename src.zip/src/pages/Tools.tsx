import { lazy, Suspense } from "react";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { FileText, BookOpen, PenTool, Calculator, Languages, Sparkles, Network, Users, Loader2, Brain, Timer, GraduationCap, Bookmark, Activity } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import PomodoroTimer from "@/components/focus/PomodoroTimer";
import MoodTracker from "@/components/wellness/MoodTracker";
import GradientMesh from "@/components/effects/GradientMesh";
import QuizGenerator from "@/components/quiz/QuizGenerator";
import StudyScheduler from "@/components/scheduler/StudyScheduler";
import StudyRoom from "@/components/collaboration/StudyRoom";
import SpacedRepetition from "@/components/flashcards/SpacedRepetition";
import BookmarkSystem from "@/components/bookmarks/BookmarkSystem";
import ActivityFeed from "@/components/activity/ActivityFeed";
const KnowledgeGraph3D = lazy(() => import("@/components/knowledge/KnowledgeGraph3D"));

const tools = [
  {
    icon: FileText,
    title: "Document Summarizer",
    description: "Upload any document and get an AI-generated summary in seconds.",
    prompt: "Help me summarize a document. Ask me to paste the text and then create a concise summary.",
  },
  {
    icon: BookOpen,
    title: "Study Notes Generator",
    description: "Transform lecture content into organized, easy-to-review notes.",
    prompt: "Help me create organized study notes. Ask me for the topic or lecture content and generate structured notes.",
  },
  {
    icon: PenTool,
    title: "Essay Helper",
    description: "Get help structuring, writing, and improving your essays.",
    prompt: "Help me write an essay. Ask me for the topic, thesis, and requirements, then help me structure and draft it.",
  },
  {
    icon: Calculator,
    title: "Math Solver",
    description: "Step-by-step solutions for math problems of any complexity.",
    prompt: "Help me solve a math problem step by step. Ask me for the problem and show detailed working.",
  },
  {
    icon: Languages,
    title: "Language Tutor",
    description: "Practice conversations and improve your language skills.",
    prompt: "Be my language tutor. Ask me which language I want to practice and start a conversation exercise.",
  },
];

const Tools = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background relative">
      <GradientMesh />
      <Navbar />
      <main className="pt-24 px-4 pb-12 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/25 mb-5"
              style={{ background: 'hsl(var(--primary) / 0.08)' }}>
              <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              <span className="text-sm font-medium text-primary/80">Powered by AI</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold mb-4 tracking-tight">
              AI Study{' '}
              <span style={{
                background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 50%, hsl(var(--accent)) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}>Tools</span>
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto font-normal">
              Powerful tools designed to enhance your learning experience and boost productivity.
            </p>
          </div>

          {/* AI Power Tools */}
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Sparkles className="w-5 h-5 text-primary animate-pulse" />
              <h2 className="text-2xl font-bold">
                AI-Powered <span className="gradient-text">Learning</span>
              </h2>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="animate-fade-in" style={{ animationDelay: '0.1s' }}>
                <QuizGenerator />
              </div>
              <div className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
                <StudyScheduler />
              </div>
            </div>
          </div>

          {/* Knowledge & Social */}
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Network className="w-5 h-5 text-primary animate-pulse" />
              <h2 className="text-2xl font-bold">
                Knowledge & <span className="gradient-text">Social</span>
              </h2>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="animate-fade-in" style={{ animationDelay: '0.15s' }}>
                <Suspense fallback={<div className="glass-morphism rounded-xl p-12 flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>}>
                  <KnowledgeGraph3D />
                </Suspense>
              </div>
              <div className="animate-fade-in" style={{ animationDelay: '0.25s' }}>
                <StudyRoom />
              </div>
            </div>
          </div>

          {/* New Feature Cards: Exam Prep & Study Groups */}
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <GraduationCap className="w-5 h-5 text-primary animate-pulse" />
              <h2 className="text-2xl font-bold">
                New <span className="gradient-text">Features</span>
              </h2>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <Link to="/exam-prep" className="block">
                <div className="bento-card group cursor-pointer hover:border-primary/30 transition-all animate-fade-in">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center"
                      style={{ background: 'hsl(var(--primary) / 0.12)', border: '1px solid hsl(var(--primary) / 0.2)' }}>
                      <Brain className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-[17px] font-bold tracking-tight">AI Exam Prep</h3>
                      <p className="text-xs text-muted-foreground">Timed exam simulations</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">Simulate real exam conditions with timed MCQs, instant scoring, and detailed explanations.</p>
                  <span className="text-xs font-semibold text-primary opacity-0 group-hover:opacity-100 transition-opacity">Try it now →</span>
                </div>
              </Link>
              <Link to="/study-groups" className="block">
                <div className="bento-card group cursor-pointer hover:border-primary/30 transition-all animate-fade-in" style={{ animationDelay: '0.1s' }}>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center"
                      style={{ background: 'hsl(var(--primary) / 0.12)', border: '1px solid hsl(var(--primary) / 0.2)' }}>
                      <Users className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-[17px] font-bold tracking-tight">Study Groups</h3>
                      <p className="text-xs text-muted-foreground">Collaborative learning</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">Create or join study rooms, chat with peers, and share notes in real-time.</p>
                  <span className="text-xs font-semibold text-primary opacity-0 group-hover:opacity-100 transition-opacity">Try it now →</span>
                </div>
              </Link>
            </div>
          </div>

          {/* Spaced Repetition & Bookmarks */}
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Bookmark className="w-5 h-5 text-primary animate-pulse" />
              <h2 className="text-2xl font-bold">
                Review & <span className="gradient-text">Save</span>
              </h2>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="animate-fade-in" style={{ animationDelay: '0.15s' }}>
                <SpacedRepetition />
              </div>
              <div className="animate-fade-in" style={{ animationDelay: '0.25s' }}>
                <BookmarkSystem />
              </div>
            </div>
          </div>

          {/* Activity Feed */}
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Activity className="w-5 h-5 text-primary animate-pulse" />
              <h2 className="text-2xl font-bold">
                Study <span className="gradient-text">Timeline</span>
              </h2>
            </div>
            <div className="animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <ActivityFeed />
            </div>
          </div>

          {/* Wellness Tools */}
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <Sparkles className="w-5 h-5 text-secondary animate-pulse" />
              <h2 className="text-2xl font-bold">
                Focus & <span className="gradient-text">Wellness</span>
              </h2>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="animate-fade-in" style={{ animationDelay: '0.3s' }}>
                <PomodoroTimer />
              </div>
              <div className="animate-fade-in" style={{ animationDelay: '0.4s' }}>
                <MoodTracker />
              </div>
            </div>
          </div>

          {/* AI Tools */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6">
              More <span className="gradient-text">AI Tools</span>
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {tools.map((tool, index) => (
                <div
                  key={tool.title}
                  className="bento-card group cursor-pointer animate-fade-in"
                  style={{ animationDelay: `${(index + 5) * 0.08}s` }}
                  onClick={() => navigate(`/chat?topic=${encodeURIComponent(tool.prompt)}`)}
                >
                  {/* Live badge */}
                  <div className="absolute top-4 right-4">
                    <span className="text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/25 px-2 py-0.5 rounded-full">
                      Live
                    </span>
                  </div>
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-4"
                    style={{ background: 'hsl(var(--primary) / 0.12)', border: '1px solid hsl(var(--primary) / 0.2)' }}>
                    <tool.icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="text-[17px] font-bold mb-2 tracking-tight">{tool.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-4">{tool.description}</p>
                  <span className="text-xs font-semibold text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    Try it now →
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 rounded-2xl p-px overflow-hidden"
            style={{ background: 'linear-gradient(135deg, hsl(var(--primary) / 0.4) 0%, hsl(var(--secondary) / 0.4) 50%, hsl(var(--accent) / 0.4) 100%)' }}>
            <div className="rounded-[15px] p-8 md:p-10 text-center flex flex-col md:flex-row items-center justify-between gap-6"
              style={{ background: 'linear-gradient(160deg, hsl(var(--card)) 0%, hsl(var(--background)) 100%)' }}>
              <div className="text-left">
                <h2 className="text-2xl font-extrabold tracking-tight mb-1">Ready to Start Learning?</h2>
                <p className="text-muted-foreground text-sm">Use our AI Chat to get personalized study help on any topic!</p>
              </div>
              <Link to="/chat" className="flex-shrink-0">
                <Button size="lg" className="font-semibold rounded-xl border-0 shadow-lg shadow-primary/20 hover:opacity-90 text-white"
                  style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}>
                  Try AI Chat Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Tools;
