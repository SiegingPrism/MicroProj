import Navbar from "@/components/Navbar";
import GradientMesh from "@/components/effects/GradientMesh";
import NotebookSystem from "@/components/notes/NotebookSystem";
import { StickyNote } from "lucide-react";

const Notes = () => {
    return (
        <div className="min-h-screen bg-background relative">
            <GradientMesh />
            <Navbar />
            <main className="pt-24 pb-12 px-4 max-w-6xl mx-auto relative z-10">
                <div className="text-center mb-10">
                    <div
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-secondary/25 mb-5"
                        style={{ background: 'hsl(var(--secondary) / 0.08)' }}
                    >
                        <StickyNote className="w-3.5 h-3.5 text-secondary" />
                        <span className="text-sm font-medium text-secondary/80">Quick Capture</span>
                    </div>
                    <h1 className="text-4xl md:text-5xl font-extrabold mb-4 tracking-tight">
                        <span
                            style={{
                                background: 'linear-gradient(135deg, hsl(var(--secondary)) 0%, hsl(var(--primary)) 50%, hsl(var(--accent)) 100%)',
                                WebkitBackgroundClip: 'text',
                                WebkitTextFillColor: 'transparent',
                                backgroundClip: 'text',
                            }}
                        >
                            Notebook
                        </span>
                    </h1>
                    <p className="text-muted-foreground text-lg max-w-xl mx-auto">
                        Capture ideas, take lecture notes, and organize your study material.
                    </p>
                </div>

                <NotebookSystem />
            </main>
        </div>
    );
};

export default Notes;
