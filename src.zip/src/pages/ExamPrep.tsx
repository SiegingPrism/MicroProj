import { useState, useEffect, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import GradientMesh from '@/components/effects/GradientMesh';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import {
    Brain, Timer, ArrowLeft, CheckCircle, XCircle, RotateCcw,
    Trophy, Sparkles, ChevronRight, Clock, Target, Zap
} from 'lucide-react';

interface Question {
    id: number;
    question: string;
    options: string[];
    correct: number;
    explanation: string;
}

interface ExamConfig {
    subject: string;
    duration: number; // minutes
    questionCount: number;
}

const SUBJECTS: { name: string; emoji: string; color: string }[] = [
    { name: 'Data Structures', emoji: '🔗', color: 'hsl(160, 70%, 45%)' },
    { name: 'Machine Learning', emoji: '🤖', color: 'hsl(200, 80%, 50%)' },
    { name: 'Biology', emoji: '🧬', color: 'hsl(140, 60%, 45%)' },
    { name: 'Physics', emoji: '⚛️', color: 'hsl(270, 70%, 55%)' },
    { name: 'Chemistry', emoji: '🧪', color: 'hsl(45, 80%, 50%)' },
    { name: 'Mathematics', emoji: '📐', color: 'hsl(340, 65%, 50%)' },
    { name: 'History', emoji: '📜', color: 'hsl(30, 60%, 45%)' },
    { name: 'Economics', emoji: '📊', color: 'hsl(190, 70%, 45%)' },
];

// Question banks per subject
const QUESTION_BANKS: Record<string, Question[]> = {
    'Data Structures': [
        { id: 1, question: 'What is the time complexity of searching in a balanced BST?', options: ['O(1)', 'O(log n)', 'O(n)', 'O(n²)'], correct: 1, explanation: 'A balanced BST halves the search space at each step, giving O(log n).' },
        { id: 2, question: 'Which data structure uses FIFO?', options: ['Stack', 'Queue', 'Tree', 'Graph'], correct: 1, explanation: 'A Queue follows First-In-First-Out (FIFO) ordering.' },
        { id: 3, question: 'What is the space complexity of a hash table?', options: ['O(1)', 'O(log n)', 'O(n)', 'O(n²)'], correct: 2, explanation: 'Hash tables store n elements, requiring O(n) space.' },
        { id: 4, question: 'Which traversal visits root first?', options: ['Inorder', 'Preorder', 'Postorder', 'Level-order'], correct: 1, explanation: 'Preorder: Root → Left → Right.' },
        { id: 5, question: 'Worst case of quicksort?', options: ['O(n log n)', 'O(n)', 'O(n²)', 'O(log n)'], correct: 2, explanation: 'Quicksort degrades to O(n²) when pivot selection is poor.' },
    ],
    'Machine Learning': [
        { id: 1, question: 'What does CNN stand for?', options: ['Central Neural Network', 'Convolutional Neural Network', 'Connected Neural Network', 'Conditional Neural Network'], correct: 1, explanation: 'CNN = Convolutional Neural Network, used mainly for image processing.' },
        { id: 2, question: 'Which is a supervised learning algorithm?', options: ['K-means', 'DBSCAN', 'Random Forest', 'PCA'], correct: 2, explanation: 'Random Forest is a supervised ensemble method using decision trees.' },
        { id: 3, question: 'What is overfitting?', options: ['Model too simple', 'Model too complex for training data', 'Too little data', 'Fast training'], correct: 1, explanation: 'Overfitting occurs when a model memorizes training data instead of generalizing.' },
        { id: 4, question: 'Activation function for output in binary classification?', options: ['ReLU', 'Sigmoid', 'Tanh', 'Softmax'], correct: 1, explanation: 'Sigmoid outputs values between 0 and 1, ideal for binary classification.' },
        { id: 5, question: 'What is the vanishing gradient problem?', options: ['Gradients become too large', 'Gradients approach zero', 'Loss increases', 'Weights become negative'], correct: 1, explanation: 'Gradients shrink exponentially in deep networks, slowing learning.' },
    ],
    'Biology': [
        { id: 1, question: 'What is the powerhouse of the cell?', options: ['Nucleus', 'Ribosome', 'Mitochondria', 'Golgi body'], correct: 2, explanation: 'Mitochondria produce ATP through cellular respiration.' },
        { id: 2, question: 'DNA stands for?', options: ['Deoxyribonucleic Acid', 'Dinitrogen Acid', 'Deoxyribonitric Acid', 'Dynamic Nucleic Acid'], correct: 0, explanation: 'DNA = Deoxyribonucleic Acid, carrying genetic instructions.' },
        { id: 3, question: 'Which blood type is the universal donor?', options: ['A', 'B', 'AB', 'O'], correct: 3, explanation: 'Type O negative can be donated to anyone.' },
        { id: 4, question: 'How many chromosomes do humans have?', options: ['23', '44', '46', '48'], correct: 2, explanation: 'Humans have 46 chromosomes (23 pairs).' },
        { id: 5, question: 'What carries oxygen in blood?', options: ['White blood cells', 'Platelets', 'Plasma', 'Hemoglobin'], correct: 3, explanation: 'Hemoglobin in red blood cells binds and transports oxygen.' },
    ],
};

// Fill missing subjects with generic questions
SUBJECTS.forEach(s => {
    if (!QUESTION_BANKS[s.name]) {
        QUESTION_BANKS[s.name] = [
            { id: 1, question: `What is a fundamental concept in ${s.name}?`, options: ['Theory A', 'Theory B', 'Theory C', 'Theory D'], correct: 0, explanation: 'This is a foundational concept.' },
            { id: 2, question: `Which principle is key to ${s.name}?`, options: ['Principle 1', 'Principle 2', 'Principle 3', 'Principle 4'], correct: 1, explanation: 'This principle forms the basis.' },
            { id: 3, question: `Who is a pioneer in ${s.name}?`, options: ['Person A', 'Person B', 'Person C', 'Person D'], correct: 2, explanation: 'A key contributor to the field.' },
            { id: 4, question: `What method is used in ${s.name}?`, options: ['Method X', 'Method Y', 'Method Z', 'Method W'], correct: 0, explanation: 'A commonly used method.' },
            { id: 5, question: `What is a recent development in ${s.name}?`, options: ['Dev 1', 'Dev 2', 'Dev 3', 'Dev 4'], correct: 3, explanation: 'A recent advancement.' },
        ];
    }
});

type ExamState = 'setup' | 'exam' | 'review';

const ExamPrep = () => {
    const [state, setState] = useState<ExamState>('setup');
    const [config, setConfig] = useState<ExamConfig>({ subject: '', duration: 10, questionCount: 5 });
    const [questions, setQuestions] = useState<Question[]>([]);
    const [currentQ, setCurrentQ] = useState(0);
    const [answers, setAnswers] = useState<(number | null)[]>([]);
    const [timeLeft, setTimeLeft] = useState(0);
    const [showExplanation, setShowExplanation] = useState(false);
    const timerRef = useRef<NodeJS.Timeout>();

    // Timer
    useEffect(() => {
        if (state !== 'exam' || timeLeft <= 0) return;
        timerRef.current = setInterval(() => {
            setTimeLeft(prev => {
                if (prev <= 1) {
                    clearInterval(timerRef.current);
                    setState('review');
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
        return () => clearInterval(timerRef.current);
    }, [state, timeLeft]);

    const startExam = () => {
        const bank = QUESTION_BANKS[config.subject] || [];
        const shuffled = [...bank].sort(() => Math.random() - 0.5).slice(0, config.questionCount);
        setQuestions(shuffled);
        setAnswers(new Array(shuffled.length).fill(null));
        setTimeLeft(config.duration * 60);
        setCurrentQ(0);
        setShowExplanation(false);
        setState('exam');
    };

    const selectAnswer = (optIdx: number) => {
        setAnswers(prev => { const n = [...prev]; n[currentQ] = optIdx; return n; });
    };

    const finishExam = () => {
        clearInterval(timerRef.current);
        setState('review');
    };

    const score = questions.reduce((s, q, i) => s + (answers[i] === q.correct ? 1 : 0), 0);
    const percent = questions.length > 0 ? Math.round((score / questions.length) * 100) : 0;

    const formatTime = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;

    return (
        <div className="min-h-screen bg-background relative">
            <GradientMesh />
            <Navbar />
            <main className="pt-24 px-4 pb-12 relative z-10">
                <div className="max-w-4xl mx-auto">

                    {/* SETUP */}
                    {state === 'setup' && (
                        <div className="animate-fade-in">
                            <Link to="/dashboard" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary mb-6 transition-colors">
                                <ArrowLeft className="w-4 h-4" /> Back to Dashboard
                            </Link>
                            <div className="text-center mb-10">
                                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/25 mb-5"
                                    style={{ background: 'hsl(var(--primary) / 0.08)' }}>
                                    <Brain className="w-4 h-4 text-primary" />
                                    <span className="text-sm font-medium text-primary/80">AI Exam Simulator</span>
                                </div>
                                <h1 className="text-4xl font-extrabold tracking-tight mb-3">
                                    Test <span className="gradient-text">Prep Mode</span>
                                </h1>
                                <p className="text-muted-foreground max-w-lg mx-auto">
                                    Simulate real exam conditions with timed questions and instant feedback.
                                </p>
                            </div>

                            {/* Subject Selection */}
                            <div className="mb-8">
                                <h3 className="text-lg font-bold mb-4">Choose Subject</h3>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                    {SUBJECTS.map(sub => (
                                        <button key={sub.name} onClick={() => setConfig(c => ({ ...c, subject: sub.name }))}
                                            className={cn('flex flex-col items-center gap-2 p-4 rounded-xl border transition-all duration-300',
                                                config.subject === sub.name
                                                    ? 'bg-primary/15 border-primary/40 ring-2 ring-primary/20 scale-[1.02]'
                                                    : 'bg-muted/20 border-border/30 hover:border-border/60 hover:bg-muted/30')}>
                                            <span className="text-3xl">{sub.emoji}</span>
                                            <span className="text-sm font-medium">{sub.name}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Config */}
                            <div className="grid md:grid-cols-2 gap-4 mb-8">
                                <div className="bento-card">
                                    <div className="flex items-center gap-2 mb-3">
                                        <Timer className="w-4 h-4 text-primary" />
                                        <span className="font-medium text-sm">Duration</span>
                                    </div>
                                    <div className="flex gap-2">
                                        {[5, 10, 15, 20].map(m => (
                                            <button key={m} onClick={() => setConfig(c => ({ ...c, duration: m }))}
                                                className={cn('flex-1 py-2 rounded-lg text-sm font-medium transition-all',
                                                    config.duration === m ? 'bg-primary/20 text-primary border border-primary/30' : 'bg-muted/30 border border-transparent')}>
                                                {m} min
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div className="bento-card">
                                    <div className="flex items-center gap-2 mb-3">
                                        <Target className="w-4 h-4 text-primary" />
                                        <span className="font-medium text-sm">Questions</span>
                                    </div>
                                    <div className="flex gap-2">
                                        {[3, 5].map(n => (
                                            <button key={n} onClick={() => setConfig(c => ({ ...c, questionCount: n }))}
                                                className={cn('flex-1 py-2 rounded-lg text-sm font-medium transition-all',
                                                    config.questionCount === n ? 'bg-primary/20 text-primary border border-primary/30' : 'bg-muted/30 border border-transparent')}>
                                                {n}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            <div className="text-center">
                                <Button size="lg" disabled={!config.subject} onClick={startExam}
                                    className="gap-2 font-semibold rounded-xl border-0 shadow-lg shadow-primary/20 text-white px-8"
                                    style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}>
                                    <Zap className="w-5 h-5" /> Start Exam
                                </Button>
                            </div>
                        </div>
                    )}

                    {/* EXAM */}
                    {state === 'exam' && questions.length > 0 && (
                        <div className="animate-fade-in">
                            {/* Top Bar */}
                            <div className="flex items-center justify-between mb-6">
                                <div className="flex items-center gap-3">
                                    <span className="text-sm font-medium">Q {currentQ + 1}/{questions.length}</span>
                                    <Progress value={((currentQ + 1) / questions.length) * 100} className="w-32 h-2" />
                                </div>
                                <div className={cn('flex items-center gap-2 px-4 py-2 rounded-full font-mono text-sm font-bold',
                                    timeLeft < 60 ? 'bg-red-500/15 text-red-400 animate-pulse' : 'bg-muted/50 text-foreground')}>
                                    <Clock className="w-4 h-4" />
                                    {formatTime(timeLeft)}
                                </div>
                            </div>

                            {/* Question Card */}
                            <div className="bento-card mb-6">
                                <span className="text-xs text-muted-foreground mb-2 block">{config.subject}</span>
                                <h2 className="text-xl font-bold mb-6">{questions[currentQ].question}</h2>
                                <div className="space-y-3">
                                    {questions[currentQ].options.map((opt, i) => (
                                        <button key={i} onClick={() => selectAnswer(i)}
                                            className={cn('w-full text-left p-4 rounded-xl border transition-all duration-200 flex items-center gap-3',
                                                answers[currentQ] === i
                                                    ? 'bg-primary/15 border-primary/40 ring-1 ring-primary/20'
                                                    : 'bg-muted/10 border-border/30 hover:border-border/60 hover:bg-muted/20')}>
                                            <div className={cn('w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border',
                                                answers[currentQ] === i ? 'bg-primary text-white border-primary' : 'border-border/50')}>
                                                {String.fromCharCode(65 + i)}
                                            </div>
                                            <span className="text-sm">{opt}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Navigation */}
                            <div className="flex items-center justify-between">
                                <Button variant="ghost" disabled={currentQ === 0} onClick={() => { setCurrentQ(c => c - 1); setShowExplanation(false); }}>
                                    Previous
                                </Button>
                                <div className="flex gap-1">
                                    {questions.map((_, i) => (
                                        <button key={i} onClick={() => { setCurrentQ(i); setShowExplanation(false); }}
                                            className={cn('w-8 h-8 rounded-lg text-xs font-bold transition-all',
                                                i === currentQ ? 'bg-primary text-white' : answers[i] !== null ? 'bg-primary/20 text-primary' : 'bg-muted/30 text-muted-foreground')}>
                                            {i + 1}
                                        </button>
                                    ))}
                                </div>
                                {currentQ < questions.length - 1 ? (
                                    <Button onClick={() => { setCurrentQ(c => c + 1); setShowExplanation(false); }}
                                        className="gap-1">
                                        Next <ChevronRight className="w-4 h-4" />
                                    </Button>
                                ) : (
                                    <Button onClick={finishExam}
                                        className="gap-1 bg-emerald-600 hover:bg-emerald-700">
                                        Finish <CheckCircle className="w-4 h-4" />
                                    </Button>
                                )}
                            </div>
                        </div>
                    )}

                    {/* REVIEW */}
                    {state === 'review' && (
                        <div className="animate-fade-in">
                            <div className="text-center mb-8">
                                <div className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center"
                                    style={{ background: percent >= 70 ? 'linear-gradient(135deg, hsl(160, 70%, 45%), hsl(var(--primary)))' : 'linear-gradient(135deg, hsl(45, 80%, 50%), hsl(20, 80%, 50%))' }}>
                                    <span className="text-2xl font-extrabold text-white">{percent}%</span>
                                </div>
                                <h2 className="text-2xl font-extrabold mb-1">
                                    {percent >= 80 ? '🎉 Excellent!' : percent >= 60 ? '👏 Good Job!' : '💪 Keep Practicing!'}
                                </h2>
                                <p className="text-muted-foreground">You scored {score}/{questions.length} in {config.subject}</p>
                            </div>

                            {/* Results */}
                            <div className="space-y-4 mb-8">
                                {questions.map((q, i) => {
                                    const isCorrect = answers[i] === q.correct;
                                    return (
                                        <div key={q.id} className={cn('bento-card', isCorrect ? 'border-emerald-500/20' : 'border-red-500/20')}>
                                            <div className="flex items-start gap-3">
                                                {isCorrect ? (
                                                    <CheckCircle className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                                                ) : (
                                                    <XCircle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                                                )}
                                                <div className="flex-1">
                                                    <p className="font-medium text-sm mb-2">{q.question}</p>
                                                    <p className={cn('text-xs mb-1', isCorrect ? 'text-emerald-400' : 'text-red-400')}>
                                                        Your answer: {answers[i] !== null ? q.options[answers[i]!] : 'Not answered'}
                                                    </p>
                                                    {!isCorrect && (
                                                        <p className="text-xs text-emerald-400">Correct: {q.options[q.correct]}</p>
                                                    )}
                                                    <p className="text-xs text-muted-foreground mt-2 p-2 rounded-lg bg-muted/20">{q.explanation}</p>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>

                            <div className="flex items-center justify-center gap-3">
                                <Button onClick={() => { setState('setup'); setConfig(c => ({ ...c, subject: '' })); }} variant="outline" className="gap-2">
                                    <RotateCcw className="w-4 h-4" /> Try Again
                                </Button>
                                <Link to="/dashboard">
                                    <Button variant="ghost">Back to Dashboard</Button>
                                </Link>
                            </div>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
};

export default ExamPrep;
