import Navbar from "@/components/Navbar";
import GradientMesh from "@/components/effects/GradientMesh";
import FlashcardSystem from "@/components/flashcards/FlashcardSystem";
import { BookOpen } from "lucide-react";

const Flashcards = () => {
    return (
        <div className="min-h-screen bg-background relative">
            <GradientMesh />
            <Navbar />
            <main className="pt-24 pb-12 px-4 max-w-6xl mx-auto relative z-10">
                {/* Page header */}
                <div className="text-center mb-10">
                    <div
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/25 mb-5"
                        style={{ background: 'hsl(var(--primary) / 0.08)' }}
                    >
                        <BookOpen className="w-3.5 h-3.5 text-primary" />
                        <span className="text-sm font-medium text-primary/80">Spaced Repetition</span>
                    </div>
                    <h1 className="text-4xl md:text-5xl font-extrabold mb-4 tracking-tight">
                        <span
                            style={{
                                background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 50%, hsl(var(--accent)) 100%)',
                                WebkitBackgroundClip: 'text',
                                WebkitTextFillColor: 'transparent',
                                backgroundClip: 'text',
                            }}
                        >
                            Flashcards
                        </span>
                    </h1>
                    <p className="text-muted-foreground text-lg max-w-xl mx-auto">
                        Create, study, and master your material with smart spaced repetition.
                    </p>
                </div>

                <FlashcardSystem />
            </main>
        </div>
    );
};

export default Flashcards;
