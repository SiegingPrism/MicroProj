import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import GradientMesh from '@/components/effects/GradientMesh';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import {
    Users, Plus, ArrowLeft, UserPlus, MessageCircle, BookOpen, Send,
    Crown, Clock, Hash, Copy, LogOut, Sparkles
} from 'lucide-react';

interface Room {
    id: string;
    name: string;
    code: string;
    subject: string;
    members: Member[];
    messages: GroupMessage[];
    createdAt: string;
}

interface Member {
    id: string;
    name: string;
    avatar: string;
    isOnline: boolean;
    isHost: boolean;
}

interface GroupMessage {
    id: string;
    memberId: string;
    memberName: string;
    content: string;
    timestamp: string;
    type: 'message' | 'system' | 'note';
}

const STORAGE_KEY = 'studyai_study_groups';
const AVATARS = ['🧑‍💻', '👩‍🔬', '🧑‍🎓', '👨‍💼', '👩‍🏫', '🧑‍🔧', '👨‍🎨', '👩‍⚕️'];
const SUBJECTS_EMOJI: Record<string, string> = {
    'Computer Science': '💻', 'Mathematics': '📐', 'Physics': '⚛️',
    'Biology': '🧬', 'Chemistry': '🧪', 'Economics': '📊',
    'Literature': '📖', 'General': '📚',
};

const generateCode = () => Math.random().toString(36).substring(2, 8).toUpperCase();

const loadRooms = (): Room[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch { return []; }
};

const saveRooms = (rooms: Room[]) => localStorage.setItem(STORAGE_KEY, JSON.stringify(rooms));

const StudyGroups = () => {
    const [rooms, setRooms] = useState<Room[]>(loadRooms);
    const [activeRoom, setActiveRoom] = useState<Room | null>(null);
    const [showCreate, setShowCreate] = useState(false);
    const [showJoin, setShowJoin] = useState(false);
    const [newRoomName, setNewRoomName] = useState('');
    const [newRoomSubject, setNewRoomSubject] = useState('General');
    const [joinCode, setJoinCode] = useState('');
    const [msgInput, setMsgInput] = useState('');
    const [userName] = useState(() => {
        try {
            const stored = localStorage.getItem('studyai_streak_data');
            return 'You';
        } catch { return 'You'; }
    });

    useEffect(() => { saveRooms(rooms); }, [rooms]);

    // Seed demo room
    useEffect(() => {
        if (rooms.length === 0) {
            const demo: Room = {
                id: 'demo-1',
                name: 'CS Study Group',
                code: 'ABC123',
                subject: 'Computer Science',
                members: [
                    { id: 'you', name: 'You', avatar: '🧑‍💻', isOnline: true, isHost: true },
                    { id: 'alice', name: 'Alice', avatar: '👩‍🔬', isOnline: true, isHost: false },
                    { id: 'bob', name: 'Bob', avatar: '🧑‍🎓', isOnline: false, isHost: false },
                ],
                messages: [
                    { id: '1', memberId: 'alice', memberName: 'Alice', content: 'Hey! Ready for the algorithms study session?', timestamp: new Date(Date.now() - 3600000).toISOString(), type: 'message' },
                    { id: '2', memberId: 'you', memberName: 'You', content: "Yes! Let's start with dynamic programming.", timestamp: new Date(Date.now() - 3000000).toISOString(), type: 'message' },
                    { id: '3', memberId: 'system', memberName: 'System', content: 'Bob joined the room', timestamp: new Date(Date.now() - 2400000).toISOString(), type: 'system' },
                    { id: '4', memberId: 'alice', memberName: 'Alice', content: 'Key insight: DP = recursion + memoization. Break problems into overlapping subproblems.', timestamp: new Date(Date.now() - 1800000).toISOString(), type: 'note' },
                ],
                createdAt: new Date(Date.now() - 86400000).toISOString(),
            };
            setRooms([demo]);
        }
    }, []);

    const createRoom = () => {
        if (!newRoomName.trim()) return;
        const room: Room = {
            id: Date.now().toString(36),
            name: newRoomName.trim(),
            code: generateCode(),
            subject: newRoomSubject,
            members: [{ id: 'you', name: userName, avatar: AVATARS[0], isOnline: true, isHost: true }],
            messages: [{ id: '0', memberId: 'system', memberName: 'System', content: `Room "${newRoomName.trim()}" created`, timestamp: new Date().toISOString(), type: 'system' }],
            createdAt: new Date().toISOString(),
        };
        setRooms(prev => [...prev, room]);
        setShowCreate(false);
        setNewRoomName('');
        setActiveRoom(room);
    };

    const joinRoom = () => {
        const room = rooms.find(r => r.code === joinCode.toUpperCase());
        if (room) {
            setActiveRoom(room);
            setShowJoin(false);
            setJoinCode('');
        }
    };

    const sendMessage = (type: 'message' | 'note' = 'message') => {
        if (!msgInput.trim() || !activeRoom) return;
        const msg: GroupMessage = {
            id: Date.now().toString(36),
            memberId: 'you',
            memberName: userName,
            content: msgInput.trim(),
            timestamp: new Date().toISOString(),
            type,
        };
        setRooms(prev => prev.map(r =>
            r.id === activeRoom.id ? { ...r, messages: [...r.messages, msg] } : r
        ));
        setActiveRoom(prev => prev ? { ...prev, messages: [...prev.messages, msg] } : null);
        setMsgInput('');
    };

    const copyCode = (code: string) => {
        navigator.clipboard.writeText(code);
    };

    const leaveRoom = () => setActiveRoom(null);

    // Active room view
    if (activeRoom) {
        return (
            <div className="min-h-screen bg-background relative">
                <GradientMesh />
                <Navbar />
                <main className="pt-24 px-4 pb-4 relative z-10">
                    <div className="max-w-5xl mx-auto flex gap-4 h-[calc(100vh-7rem)]">
                        {/* Chat Area */}
                        <div className="flex-1 flex flex-col glass-morphism rounded-2xl overflow-hidden">
                            {/* Room Header */}
                            <div className="px-5 py-3 border-b border-border/30 flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <button onClick={leaveRoom} className="hover:text-primary transition-colors">
                                        <ArrowLeft className="w-5 h-5" />
                                    </button>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <span>{SUBJECTS_EMOJI[activeRoom.subject] || '📚'}</span>
                                            <h3 className="font-bold">{activeRoom.name}</h3>
                                        </div>
                                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                            <Hash className="w-3 h-3" />
                                            <span>{activeRoom.code}</span>
                                            <button onClick={() => copyCode(activeRoom.code)} className="hover:text-primary">
                                                <Copy className="w-3 h-3" />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="flex -space-x-2">
                                        {activeRoom.members.slice(0, 4).map(m => (
                                            <div key={m.id} className="w-7 h-7 rounded-full bg-muted/50 flex items-center justify-center text-sm border-2 border-background">
                                                {m.avatar}
                                            </div>
                                        ))}
                                    </div>
                                    <span className="text-xs text-muted-foreground">{activeRoom.members.length} members</span>
                                </div>
                            </div>

                            {/* Messages */}
                            <div className="flex-1 overflow-y-auto p-4 space-y-3">
                                {activeRoom.messages.map(msg => (
                                    <div key={msg.id} className={cn(
                                        msg.type === 'system' ? 'text-center' : msg.memberId === 'you' ? 'flex justify-end' : 'flex justify-start'
                                    )}>
                                        {msg.type === 'system' ? (
                                            <span className="text-xs text-muted-foreground bg-muted/20 px-3 py-1 rounded-full">{msg.content}</span>
                                        ) : (
                                            <div className={cn('max-w-[70%]', msg.memberId === 'you' ? 'items-end' : 'items-start')}>
                                                {msg.memberId !== 'you' && (
                                                    <span className="text-[10px] text-muted-foreground mb-1 block">{msg.memberName}</span>
                                                )}
                                                <div className={cn(
                                                    'rounded-2xl px-4 py-2.5 text-sm',
                                                    msg.type === 'note'
                                                        ? 'bg-amber-500/10 border border-amber-500/20 text-foreground'
                                                        : msg.memberId === 'you'
                                                            ? 'bg-primary/20 text-foreground'
                                                            : 'bg-muted/30 text-foreground'
                                                )}>
                                                    {msg.type === 'note' && <span className="text-[10px] text-amber-400 font-medium block mb-1">📌 Shared Note</span>}
                                                    {msg.content}
                                                </div>
                                                <span className="text-[9px] text-muted-foreground mt-1 block">
                                                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                </span>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>

                            {/* Input */}
                            <div className="px-4 py-3 border-t border-border/30">
                                <div className="flex gap-2">
                                    <Input value={msgInput} onChange={e => setMsgInput(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && sendMessage()}
                                        placeholder="Type a message..." className="bg-muted/30 border-0" />
                                    <Button variant="outline" size="icon" onClick={() => sendMessage('note')}
                                        title="Share as note" className="flex-shrink-0">
                                        <BookOpen className="w-4 h-4" />
                                    </Button>
                                    <Button size="icon" onClick={() => sendMessage()}
                                        className="flex-shrink-0 text-white"
                                        style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}>
                                        <Send className="w-4 h-4" />
                                    </Button>
                                </div>
                            </div>
                        </div>

                        {/* Members Sidebar */}
                        <div className="w-64 hidden lg:block glass-morphism rounded-2xl p-4">
                            <h4 className="font-bold text-sm mb-4 flex items-center gap-2">
                                <Users className="w-4 h-4 text-primary" /> Members
                            </h4>
                            <div className="space-y-2">
                                {activeRoom.members.map(m => (
                                    <div key={m.id} className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-muted/20 transition-colors">
                                        <div className="relative">
                                            <span className="text-xl">{m.avatar}</span>
                                            <div className={cn('absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-background',
                                                m.isOnline ? 'bg-emerald-400' : 'bg-muted-foreground/30')} />
                                        </div>
                                        <div>
                                            <p className="text-sm font-medium flex items-center gap-1">
                                                {m.name}
                                                {m.isHost && <Crown className="w-3 h-3 text-amber-400" />}
                                            </p>
                                            <p className="text-[10px] text-muted-foreground">{m.isOnline ? 'Online' : 'Offline'}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="mt-6 pt-4 border-t border-border/30">
                                <h4 className="font-bold text-sm mb-3">Room Info</h4>
                                <div className="space-y-2 text-xs text-muted-foreground">
                                    <p className="flex items-center gap-2"><BookOpen className="w-3.5 h-3.5" /> {activeRoom.subject}</p>
                                    <p className="flex items-center gap-2"><Clock className="w-3.5 h-3.5" /> Created {new Date(activeRoom.createdAt).toLocaleDateString()}</p>
                                    <p className="flex items-center gap-2"><MessageCircle className="w-3.5 h-3.5" /> {activeRoom.messages.filter(m => m.type !== 'system').length} messages</p>
                                </div>
                            </div>

                            <Button variant="ghost" size="sm" className="w-full mt-4 gap-2 text-muted-foreground hover:text-destructive" onClick={leaveRoom}>
                                <LogOut className="w-3.5 h-3.5" /> Leave Room
                            </Button>
                        </div>
                    </div>
                </main>
            </div>
        );
    }

    // Room List View
    return (
        <div className="min-h-screen bg-background relative">
            <GradientMesh />
            <Navbar />
            <main className="pt-24 px-4 pb-12 relative z-10">
                <div className="max-w-4xl mx-auto">
                    <Link to="/dashboard" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary mb-6 transition-colors">
                        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
                    </Link>

                    <div className="text-center mb-10">
                        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/25 mb-5"
                            style={{ background: 'hsl(var(--primary) / 0.08)' }}>
                            <Users className="w-4 h-4 text-primary" />
                            <span className="text-sm font-medium text-primary/80">Collaborative Learning</span>
                        </div>
                        <h1 className="text-4xl font-extrabold tracking-tight mb-3">
                            Study <span className="gradient-text">Groups</span>
                        </h1>
                        <p className="text-muted-foreground max-w-lg mx-auto">
                            Create or join study rooms to collaborate with peers in real-time.
                        </p>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-3 justify-center mb-8">
                        <Button onClick={() => { setShowCreate(true); setShowJoin(false); }}
                            className="gap-2 rounded-xl text-white"
                            style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}>
                            <Plus className="w-4 h-4" /> Create Room
                        </Button>
                        <Button variant="outline" onClick={() => { setShowJoin(true); setShowCreate(false); }}
                            className="gap-2 rounded-xl">
                            <UserPlus className="w-4 h-4" /> Join Room
                        </Button>
                    </div>

                    {/* Create form */}
                    {showCreate && (
                        <div className="bento-card mb-6 animate-fade-in max-w-md mx-auto">
                            <h3 className="font-bold mb-4">Create Study Room</h3>
                            <div className="space-y-3">
                                <Input value={newRoomName} onChange={e => setNewRoomName(e.target.value)}
                                    placeholder="Room name..." className="bg-muted/30 border-0" />
                                <div className="flex flex-wrap gap-2">
                                    {Object.entries(SUBJECTS_EMOJI).map(([sub, emoji]) => (
                                        <button key={sub} onClick={() => setNewRoomSubject(sub)}
                                            className={cn('px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1',
                                                newRoomSubject === sub ? 'bg-primary/20 text-primary border border-primary/30' : 'bg-muted/30 border border-transparent')}>
                                            {emoji} {sub}
                                        </button>
                                    ))}
                                </div>
                                <Button onClick={createRoom} disabled={!newRoomName.trim()} className="w-full">Create</Button>
                            </div>
                        </div>
                    )}

                    {/* Join form */}
                    {showJoin && (
                        <div className="bento-card mb-6 animate-fade-in max-w-md mx-auto">
                            <h3 className="font-bold mb-4">Join Study Room</h3>
                            <div className="flex gap-2">
                                <Input value={joinCode} onChange={e => setJoinCode(e.target.value)}
                                    placeholder="Enter room code..." className="bg-muted/30 border-0 uppercase" maxLength={6} />
                                <Button onClick={joinRoom} disabled={joinCode.length < 4}>Join</Button>
                            </div>
                        </div>
                    )}

                    {/* Room List */}
                    <div className="grid md:grid-cols-2 gap-4">
                        {rooms.map(room => (
                            <div key={room.id} className="bento-card cursor-pointer hover:border-primary/30 transition-all group"
                                onClick={() => setActiveRoom(room)}>
                                <div className="flex items-start justify-between mb-3">
                                    <div className="flex items-center gap-2">
                                        <span className="text-2xl">{SUBJECTS_EMOJI[room.subject] || '📚'}</span>
                                        <div>
                                            <h4 className="font-bold">{room.name}</h4>
                                            <p className="text-xs text-muted-foreground">{room.subject}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                        <Hash className="w-3 h-3" />
                                        <span>{room.code}</span>
                                    </div>
                                </div>
                                <div className="flex items-center justify-between">
                                    <div className="flex -space-x-1.5">
                                        {room.members.slice(0, 3).map(m => (
                                            <div key={m.id} className="w-6 h-6 rounded-full bg-muted/50 flex items-center justify-center text-xs border border-background">
                                                {m.avatar}
                                            </div>
                                        ))}
                                        {room.members.length > 3 && (
                                            <div className="w-6 h-6 rounded-full bg-muted/50 flex items-center justify-center text-[9px] border border-background font-medium">
                                                +{room.members.length - 3}
                                            </div>
                                        )}
                                    </div>
                                    <span className="text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                                        Enter →
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>

                    {rooms.length === 0 && (
                        <div className="text-center py-16">
                            <Users className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
                            <p className="text-muted-foreground">No study rooms yet. Create one to get started!</p>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
};

export default StudyGroups;
