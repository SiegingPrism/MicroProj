import { useState, useEffect, useMemo } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import GradientMesh from '@/components/effects/GradientMesh';
import DailyStreak from '@/components/streak/DailyStreak';
import { Button } from '@/components/ui/button';
import {
    User, Brain, BookOpen, MessageCircle, Flame, Trophy,
    Target, Clock, Medal, Star, Zap, Award, Loader2, ArrowLeft
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

interface ProfileData {
    full_name: string | null;
    domain: string | null;
    education_level: string | null;
    role: string | null;
    interests: string[] | null;
}

interface Badge {
    id: string;
    name: string;
    description: string;
    icon: any;
    earned: boolean;
    color: string;
}

// Generate study heatmap data (last 12 weeks)
const generateHeatmapData = () => {
    const data: { date: string; count: number }[] = [];
    const now = new Date();
    for (let i = 83; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(d.getDate() - i);
        const dateStr = d.toISOString().split('T')[0];
        // Simulate some study data
        const count = Math.random() > 0.3 ? Math.floor(Math.random() * 4) + 1 : 0;
        data.push({ date: dateStr, count });
    }
    return data;
};

const Profile = () => {
    const { user, loading } = useAuth();
    const navigate = useNavigate();
    const [profile, setProfile] = useState<ProfileData | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const heatmapData = useMemo(() => generateHeatmapData(), []);

    useEffect(() => {
        if (!loading && !user) {
            navigate('/auth');
            return;
        }
        if (user) {
            supabase
                .from('profiles')
                .select('full_name, domain, education_level, role, interests')
                .eq('user_id', user.id)
                .maybeSingle()
                .then(({ data }) => {
                    setProfile(data);
                    setIsLoading(false);
                });
        }
    }, [user, loading]);

    // Badges (static demo — in production these would come from DB)
    const badges: Badge[] = [
        { id: '1', name: 'First Steps', description: 'Complete your first study session', icon: Star, earned: true, color: 'text-amber-400' },
        { id: '2', name: 'Bookworm', description: 'Study for 10 total hours', icon: BookOpen, earned: true, color: 'text-emerald-400' },
        { id: '3', name: 'Speed Learner', description: 'Complete 5 flashcard decks', icon: Zap, earned: false, color: 'text-amber-400' },
        { id: '4', name: 'Streak Master', description: 'Maintain a 7-day streak', icon: Flame, earned: true, color: 'text-rose-400' },
        { id: '5', name: 'Quiz Champion', description: 'Score 100% on 3 quizzes', icon: Trophy, earned: false, color: 'text-teal-400' },
        { id: '6', name: 'Night Owl', description: 'Study after midnight', icon: Clock, earned: true, color: 'text-violet-400' },
        { id: '7', name: 'Goal Crusher', description: 'Meet daily goal 5 days in a row', icon: Target, earned: false, color: 'text-emerald-400' },
        { id: '8', name: 'Scholar', description: 'Complete 50 topics', icon: Award, earned: false, color: 'text-amber-400' },
        { id: '9', name: 'Social Learner', description: 'Join 3 study rooms', icon: MessageCircle, earned: true, color: 'text-teal-400' },
    ];

    const earnedCount = badges.filter(b => b.earned).length;

    if (loading || isLoading) {
        return (
            <div className="min-h-screen bg-background flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
        );
    }

    const getHeatmapColor = (count: number) => {
        if (count === 0) return 'bg-muted/30';
        if (count === 1) return 'bg-primary/20';
        if (count === 2) return 'bg-primary/40';
        if (count === 3) return 'bg-primary/60';
        return 'bg-primary/80';
    };

    return (
        <div className="min-h-screen bg-background relative">
            <GradientMesh />
            <Navbar />
            <main className="pt-24 pb-12 px-4 max-w-5xl mx-auto relative z-10">
                {/* Back button */}
                <Button variant="ghost" size="sm" className="mb-4 gap-1" onClick={() => navigate(-1)}>
                    <ArrowLeft className="w-4 h-4" /> Back
                </Button>

                {/* Profile header */}
                <div className="bento-card mb-6 noise-overlay">
                    <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-primary via-secondary to-accent" />
                    <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                        {/* Avatar */}
                        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center text-3xl font-bold text-primary border-2 border-primary/20 shadow-inner">
                            {profile?.full_name?.charAt(0)?.toUpperCase() || '?'}
                        </div>
                        <div className="flex-1">
                            <h1 className="text-2xl md:text-3xl font-bold">{profile?.full_name || 'Student'}</h1>
                            <div className="flex flex-wrap items-center gap-2 mt-1 text-muted-foreground text-sm">
                                <span className="capitalize">{profile?.domain?.replace('_', ' & ')}</span>
                                {profile?.education_level && <span>• {profile.education_level}</span>}
                                {profile?.role && (
                                    <span className="px-2 py-0.5 rounded-full bg-primary/20 text-primary text-xs capitalize font-medium">
                                        {profile.role}
                                    </span>
                                )}
                            </div>
                            {profile?.interests && profile.interests.length > 0 && (
                                <div className="flex flex-wrap gap-1.5 mt-3">
                                    {profile.interests.map(interest => (
                                        <span key={interest} className="px-2.5 py-1 rounded-full bg-muted/50 text-xs font-medium border border-border">
                                            {interest}
                                        </span>
                                    ))}
                                </div>
                            )}
                        </div>
                        <Link to="/settings">
                            <Button variant="outline" size="sm" className="gap-1.5 text-xs">
                                <User className="w-3.5 h-3.5" /> Edit Profile
                            </Button>
                        </Link>
                    </div>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                    {/* Left column — streak + stats */}
                    <div className="md:col-span-1 space-y-6">
                        <DailyStreak />

                        {/* Quick stats */}
                        <div className="bento-card">
                            <h3 className="font-bold mb-3 flex items-center gap-2">
                                <Medal className="w-4 h-4 text-primary" /> Stats
                            </h3>
                            <div className="space-y-3">
                                <div className="flex justify-between text-sm">
                                    <span className="text-muted-foreground">Badges Earned</span>
                                    <span className="font-bold">{earnedCount}/{badges.length}</span>
                                </div>
                                <div className="flex justify-between text-sm">
                                    <span className="text-muted-foreground">Study Sessions</span>
                                    <span className="font-bold">47</span>
                                </div>
                                <div className="flex justify-between text-sm">
                                    <span className="text-muted-foreground">Questions Asked</span>
                                    <span className="font-bold">234</span>
                                </div>
                                <div className="flex justify-between text-sm">
                                    <span className="text-muted-foreground">Topics Completed</span>
                                    <span className="font-bold">12</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Right column — heatmap + badges */}
                    <div className="md:col-span-2 space-y-6">
                        {/* Study Heatmap */}
                        <div className="bento-card noise-overlay">
                            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/60 to-secondary/60" />
                            <h3 className="font-bold mb-4 flex items-center gap-2">
                                <Brain className="w-5 h-5 text-primary" /> Study Activity
                            </h3>
                            <div className="overflow-x-auto">
                                <div className="grid grid-flow-col grid-rows-7 gap-1 min-w-[500px]">
                                    {heatmapData.map((day, i) => (
                                        <div
                                            key={i}
                                            className={`w-4 h-4 rounded-sm ${getHeatmapColor(day.count)} transition-colors hover:ring-1 hover:ring-primary/50`}
                                            title={`${day.date}: ${day.count} sessions`}
                                        />
                                    ))}
                                </div>
                            </div>
                            <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
                                <span>Less</span>
                                {[0, 1, 2, 3, 4].map(c => (
                                    <div key={c} className={`w-3 h-3 rounded-sm ${getHeatmapColor(c)}`} />
                                ))}
                                <span>More</span>
                            </div>
                        </div>

                        {/* Badges */}
                        <div className="bento-card">
                            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500/60 to-rose-500/60" />
                            <h3 className="font-bold mb-4 flex items-center gap-2">
                                <Trophy className="w-5 h-5 text-amber-400" /> Badges
                                <span className="text-xs text-muted-foreground font-normal ml-auto">{earnedCount}/{badges.length} earned</span>
                            </h3>
                            <div className="grid grid-cols-3 gap-3">
                                {badges.map(badge => (
                                    <div
                                        key={badge.id}
                                        className={`p-3 rounded-xl border text-center transition-all ${badge.earned
                                                ? 'border-primary/20 bg-primary/5'
                                                : 'border-transparent bg-muted/30 opacity-40 grayscale'
                                            }`}
                                    >
                                        <badge.icon className={`w-6 h-6 mx-auto mb-1.5 ${badge.earned ? badge.color : 'text-muted-foreground'}`} />
                                        <p className="text-xs font-semibold truncate">{badge.name}</p>
                                        <p className="text-[10px] text-muted-foreground leading-tight mt-0.5">{badge.description}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Profile;
