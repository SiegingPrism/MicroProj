import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface Conversation {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

export const useChatHistory = (userId: string | undefined) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch all conversations
  useEffect(() => {
    if (!userId) return;

    const fetchConversations = async () => {
      const { data, error } = await supabase
        .from('chat_conversations')
        .select('*')
        .eq('user_id', userId)
        .order('updated_at', { ascending: false });

      if (!error && data) {
        setConversations(data);
      }
    };

    fetchConversations();
  }, [userId]);

  // Fetch messages for current conversation
  useEffect(() => {
    if (!currentConversationId || !userId) return;

    const fetchMessages = async () => {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('conversation_id', currentConversationId)
        .order('created_at', { ascending: true });

      if (!error && data) {
        setMessages(data.map(m => ({
          id: m.id,
          role: m.role as 'user' | 'assistant',
          content: m.content,
          timestamp: new Date(m.created_at),
        })));
      }
      setIsLoading(false);
    };

    fetchMessages();
  }, [currentConversationId, userId]);

  const createConversation = async (initialMessage?: string) => {
    if (!userId) return null;

    const title = initialMessage 
      ? initialMessage.slice(0, 50) + (initialMessage.length > 50 ? '...' : '')
      : 'New Chat';

    const { data, error } = await supabase
      .from('chat_conversations')
      .insert({ user_id: userId, title })
      .select()
      .single();

    if (!error && data) {
      setConversations(prev => [data, ...prev]);
      setCurrentConversationId(data.id);
      setMessages([]);
      return data.id;
    }
    return null;
  };

  const saveMessage = async (conversationId: string, role: 'user' | 'assistant', content: string) => {
    if (!userId) return;

    const { data, error } = await supabase
      .from('chat_messages')
      .insert({
        conversation_id: conversationId,
        user_id: userId,
        role,
        content,
      })
      .select()
      .single();

    if (!error && data) {
      const newMessage: Message = {
        id: data.id,
        role: data.role as 'user' | 'assistant',
        content: data.content,
        timestamp: new Date(data.created_at),
      };
      setMessages(prev => [...prev, newMessage]);

      // Update conversation title if it's the first message
      if (role === 'user' && messages.length === 0) {
        await supabase
          .from('chat_conversations')
          .update({ 
            title: content.slice(0, 50) + (content.length > 50 ? '...' : ''),
            updated_at: new Date().toISOString()
          })
          .eq('id', conversationId);
      } else {
        await supabase
          .from('chat_conversations')
          .update({ updated_at: new Date().toISOString() })
          .eq('id', conversationId);
      }
    }

    return data;
  };

  const deleteConversation = async (conversationId: string) => {
    const { error } = await supabase
      .from('chat_conversations')
      .delete()
      .eq('id', conversationId);

    if (!error) {
      setConversations(prev => prev.filter(c => c.id !== conversationId));
      if (currentConversationId === conversationId) {
        setCurrentConversationId(null);
        setMessages([]);
      }
    }
  };

  const loadConversation = async (conversationId: string) => {
    setCurrentConversationId(conversationId);
  };

  const startNewChat = () => {
    setCurrentConversationId(null);
    setMessages([]);
  };

  return {
    conversations,
    currentConversationId,
    messages,
    isLoading,
    createConversation,
    saveMessage,
    deleteConversation,
    loadConversation,
    startNewChat,
    setMessages,
  };
};