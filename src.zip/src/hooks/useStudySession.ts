import { useState, useCallback, useRef, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface UseStudySessionProps {
  userId: string | undefined;
  topic?: string;
}

export const useStudySession = ({ userId, topic }: UseStudySessionProps) => {
  const [isTracking, setIsTracking] = useState(false);
  const [elapsedMinutes, setElapsedMinutes] = useState(0);
  const sessionIdRef = useRef<string | null>(null);
  const startTimeRef = useRef<Date | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const startSession = useCallback(async (sessionTopic?: string) => {
    if (!userId || isTracking) return;

    const topicName = sessionTopic || topic || 'General Study';
    
    const { data, error } = await supabase
      .from('study_sessions')
      .insert({
        user_id: userId,
        topic: topicName,
        duration_minutes: 0,
      })
      .select('id')
      .single();

    if (error) {
      console.error('Error starting session:', error);
      return;
    }

    sessionIdRef.current = data.id;
    startTimeRef.current = new Date();
    setIsTracking(true);
    setElapsedMinutes(0);

    intervalRef.current = setInterval(() => {
      if (startTimeRef.current) {
        const diff = Math.floor((Date.now() - startTimeRef.current.getTime()) / 60000);
        setElapsedMinutes(diff);
      }
    }, 60000);
  }, [userId, topic, isTracking]);

  const endSession = useCallback(async () => {
    if (!sessionIdRef.current || !startTimeRef.current) return;

    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    const durationMinutes = Math.max(1, Math.floor((Date.now() - startTimeRef.current.getTime()) / 60000));

    await supabase
      .from('study_sessions')
      .update({
        duration_minutes: durationMinutes,
        ended_at: new Date().toISOString(),
      })
      .eq('id', sessionIdRef.current);

    sessionIdRef.current = null;
    startTimeRef.current = null;
    setIsTracking(false);
    setElapsedMinutes(0);
  }, []);

  const markTopicCompleted = useCallback(async (topicName: string, domain?: string) => {
    if (!userId) return;

    const { error } = await supabase
      .from('completed_topics')
      .upsert({
        user_id: userId,
        topic: topicName,
        domain: domain,
      }, {
        onConflict: 'user_id,topic'
      });

    if (error) {
      console.error('Error marking topic completed:', error);
    }
  }, [userId]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (sessionIdRef.current) {
        endSession();
      }
    };
  }, [endSession]);

  return {
    isTracking,
    elapsedMinutes,
    startSession,
    endSession,
    markTopicCompleted,
  };
};
