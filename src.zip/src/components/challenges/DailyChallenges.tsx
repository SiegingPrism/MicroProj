import { useState, useEffect } from 'react';
import { Zap, Target, BookOpen, Brain, Timer, Trophy, CheckCircle, Flame, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface Challenge {
    id: string;
    title: string;
    description: string;
    icon: React.ElementType;
    target: number;
    unit: string;
    xpReward: number;
    color: string;
    type: string;
}

interface ChallengeProgress {
    id: string;
    current: number;
    completed: boolean;
    completedAt?: string;
}

const ALL_CHALLENGES: Omit<Challenge, 'id'>[] = [
    { title: 'Flash Master', description: 'Review flashcards', icon: BookOpen, target: 10, unit: 'cards', xpReward: 50, color: 'hsl(160, 84%, 39%)', type: 'flashcards' },
    { title: 'Focus Champion', description: 'Study without breaks', icon: Timer, target: 30, unit: 'minutes', xpReward: 75, color: 'hsl(200, 80%, 50%)', type: 'focus' },
    { title: 'Quiz Whiz', description: 'Complete quizzes', icon: Brain, target: 3, unit: 'quizzes', xpReward: 60, color: 'hsl(270, 70%, 55%)', type: 'quiz' },
    { title: 'Chat Explorer', description: 'Ask AI questions', icon: Sparkles, target: 5, unit: 'questions', xpReward: 40, color: 'hsl(45, 80%, 50%)', type: 'chat' },
    { title: 'Topic Hunter', description: 'Complete study topics', icon: Target, target: 2, unit: 'topics', xpReward: 80, color: 'hsl(340, 70%, 55%)', type: 'topics' },
    { title: 'Note Taker', description: 'Create study notes', icon: BookOpen, target: 3, unit: 'notes', xpReward: 45, color: 'hsl(140, 60%, 45%)', type: 'notes' },
    { title: 'Marathon Runner', description: 'Total study time', icon: Flame, target: 60, unit: 'minutes', xpReward: 100, color: 'hsl(20, 80%, 50%)', type: 'study_time' },
    { title: 'Early Bird', description: 'Start studying before 9 AM', icon: Zap, target: 1, unit: 'session', xpReward: 35, color: 'hsl(50, 80%, 50%)', type: 'early' },
    { title: 'Streak Builder', description: 'Maintain study streak', icon: Flame, target: 1, unit: 'day', xpReward: 30, color: 'hsl(15, 85%, 55%)', type: 'streak' },
];

const STORAGE_KEY = 'studyai_daily_challenges';

// Use date as seed for consistent daily challenges
const getDaySeed = () => {
    const d = new Date();
    return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
};

const seededShuffle = <T,>(arr: T[], seed: number): T[] => {
    const shuffled = [...arr];
    let s = seed;
    for (let i = shuffled.length - 1; i > 0; i--) {
        s = (s * 1103515245 + 12345) & 0x7fffffff;
        const j = s % (i + 1);
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
};

const getDailyChallenges = (): Challenge[] => {
    const seed = getDaySeed();
    const shuffled = seededShuffle(ALL_CHALLENGES, seed);
    return shuffled.slice(0, 3).map((c, i) => ({ ...c, id: `${seed}-${i}` }));
};

const loadProgress = (challenges: Challenge[]): ChallengeProgress[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
            const data = JSON.parse(stored);
            if (data.date === getDaySeed()) return data.progress;
        }
    } catch { }
    return challenges.map(c => ({ id: c.id, current: 0, completed: false }));
};

const saveProgress = (progress: ChallengeProgress[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ date: getDaySeed(), progress }));
};

const DailyChallenges = () => {
    const [challenges] = useState(getDailyChallenges);
    const [progress, setProgress] = useState<ChallengeProgress[]>(() => loadProgress(challenges));
    const [showCelebration, setShowCelebration] = useState<string | null>(null);

    useEffect(() => {
        saveProgress(progress);
    }, [progress]);

    const simulateProgress = (challengeId: string) => {
        setProgress(prev => {
            const challenge = challenges.find(c => c.id === challengeId);
            if (!challenge) return prev;

            return prev.map(p => {
                if (p.id !== challengeId || p.completed) return p;
                const newCurrent = Math.min(p.current + 1, challenge.target);
                const isComplete = newCurrent >= challenge.target;
                if (isComplete) {
                    setShowCelebration(challengeId);
                    setTimeout(() => setShowCelebration(null), 2000);
                }
                return {
                    ...p,
                    current: newCurrent,
                    completed: isComplete,
                    completedAt: isComplete ? new Date().toISOString() : undefined,
                };
            });
        });
    };

    const completedCount = progress.filter(p => p.completed).length;
    const totalXp = challenges.reduce((sum, c, i) => sum + (progress[i]?.completed ? c.xpReward : 0), 0);

    return (
        <div className="bento-card noise-overlay">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500/60 via-primary/60 to-violet-500/60" />

            {/* Header */}
            <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center">
                        <Zap className="w-5 h-5 text-amber-400" />
                    </div>
                    <div>
                        <h3 className="font-bold text-lg">Daily Challenges</h3>
                        <p className="text-xs text-muted-foreground">Refresh in {24 - new Date().getHours()}h</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <div className="px-3 py-1.5 rounded-full bg-primary/15 border border-primary/25">
                        <span className="text-xs font-bold text-primary">{completedCount}/3 Done</span>
                    </div>
                    {totalXp > 0 && (
                        <div className="px-3 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/25">
                            <span className="text-xs font-bold text-amber-400">+{totalXp} XP</span>
                        </div>
                    )}
                </div>
            </div>

            {/* Challenges */}
            <div className="space-y-3">
                {challenges.map((challenge, idx) => {
                    const prog = progress[idx];
                    const percent = Math.round((prog.current / challenge.target) * 100);
                    const Icon = challenge.icon;

                    return (
                        <div
                            key={challenge.id}
                            className={cn(
                                'relative rounded-xl p-4 transition-all duration-300 overflow-hidden',
                                prog.completed
                                    ? 'bg-primary/10 border border-primary/25'
                                    : 'bg-muted/20 border border-border/30 hover:border-border/60'
                            )}
                        >
                            {/* Celebration overlay */}
                            {showCelebration === challenge.id && (
                                <div className="absolute inset-0 flex items-center justify-center bg-primary/10 backdrop-blur-sm z-10 animate-fade-in">
                                    <div className="flex items-center gap-2">
                                        <Trophy className="w-6 h-6 text-primary animate-bounce" />
                                        <span className="font-bold text-primary">+{challenge.xpReward} XP!</span>
                                    </div>
                                </div>
                            )}

                            <div className="flex items-start gap-3">
                                <div
                                    className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                                    style={{ backgroundColor: `${challenge.color}20`, border: `1px solid ${challenge.color}30` }}
                                >
                                    {prog.completed ? (
                                        <CheckCircle className="w-5 h-5" style={{ color: challenge.color }} />
                                    ) : (
                                        <Icon className="w-5 h-5" style={{ color: challenge.color }} />
                                    )}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between mb-1">
                                        <h4 className={cn('font-semibold text-sm', prog.completed && 'line-through text-muted-foreground')}>
                                            {challenge.title}
                                        </h4>
                                        <span className="text-xs text-muted-foreground">
                                            {prog.current}/{challenge.target} {challenge.unit}
                                        </span>
                                    </div>
                                    <p className="text-xs text-muted-foreground mb-2">{challenge.description}</p>
                                    <div className="flex items-center gap-3">
                                        <Progress value={percent} className="h-1.5 flex-1" />
                                        {!prog.completed && (
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                className="h-7 px-3 text-xs hover:bg-primary/10 hover:text-primary"
                                                onClick={() => simulateProgress(challenge.id)}
                                            >
                                                +1
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* All Complete Banner */}
            {completedCount === 3 && (
                <div className="mt-4 rounded-xl p-4 text-center bg-gradient-to-r from-primary/15 via-amber-500/15 to-violet-500/15 border border-primary/20 animate-fade-in">
                    <Trophy className="w-8 h-8 mx-auto mb-2 text-primary" />
                    <p className="font-bold gradient-text">All Challenges Complete! 🎉</p>
                    <p className="text-xs text-muted-foreground mt-1">You earned {totalXp} XP today</p>
                </div>
            )}
        </div>
    );
};

export default DailyChallenges;
