import { useState, useEffect } from 'react';
import { Activity, MessageCircle, BookOpen, Brain, Target, Timer, Smile, FileText, Flame, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ActivityItem {
    id: string;
    type: 'chat' | 'quiz' | 'flashcard' | 'focus' | 'mood' | 'topic' | 'note' | 'streak' | 'goal';
    title: string;
    description: string;
    timestamp: string;
    metadata?: Record<string, string>;
}

const TYPE_CONFIG: Record<string, { icon: React.ElementType; color: string; bgColor: string }> = {
    chat: { icon: MessageCircle, color: 'text-blue-400', bgColor: 'bg-blue-500/15' },
    quiz: { icon: Brain, color: 'text-violet-400', bgColor: 'bg-violet-500/15' },
    flashcard: { icon: BookOpen, color: 'text-emerald-400', bgColor: 'bg-emerald-500/15' },
    focus: { icon: Timer, color: 'text-cyan-400', bgColor: 'bg-cyan-500/15' },
    mood: { icon: Smile, color: 'text-amber-400', bgColor: 'bg-amber-500/15' },
    topic: { icon: Target, color: 'text-rose-400', bgColor: 'bg-rose-500/15' },
    note: { icon: FileText, color: 'text-teal-400', bgColor: 'bg-teal-500/15' },
    streak: { icon: Flame, color: 'text-orange-400', bgColor: 'bg-orange-500/15' },
    goal: { icon: Target, color: 'text-indigo-400', bgColor: 'bg-indigo-500/15' },
};

const STORAGE_KEY = 'studyai_activity_feed';

export const logActivity = (item: Omit<ActivityItem, 'id' | 'timestamp'>) => {
    const activities = getActivities();
    const newItem: ActivityItem = {
        ...item,
        id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
        timestamp: new Date().toISOString(),
    };
    activities.unshift(newItem);
    // Keep last 100 items
    localStorage.setItem(STORAGE_KEY, JSON.stringify(activities.slice(0, 100)));
    window.dispatchEvent(new CustomEvent('activity-updated'));
};

const getActivities = (): ActivityItem[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch { return []; }
};

const formatTime = (ts: string) => {
    const d = new Date(ts);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    if (days < 7) return `${days}d ago`;
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

const getDateLabel = (ts: string) => {
    const d = new Date(ts);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const itemDate = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const diff = today.getTime() - itemDate.getTime();
    const days = Math.floor(diff / 86400000);
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return d.toLocaleDateString('en-US', { weekday: 'long' });
    return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric' });
};

const ActivityFeed = () => {
    const [activities, setActivities] = useState<ActivityItem[]>(getActivities);
    const [filterType, setFilterType] = useState<string | null>(null);

    useEffect(() => {
        const handler = () => setActivities(getActivities());
        window.addEventListener('activity-updated', handler);
        return () => window.removeEventListener('activity-updated', handler);
    }, []);

    // Seed demo activities if empty
    useEffect(() => {
        if (activities.length === 0) {
            const now = Date.now();
            const demos: Omit<ActivityItem, 'id' | 'timestamp'>[] = [
                { type: 'chat', title: 'AI Chat Session', description: 'Discussed neural network architectures' },
                { type: 'quiz', title: 'Quiz Completed', description: 'Data Structures — Score: 8/10' },
                { type: 'focus', title: 'Focus Session', description: '25 min Pomodoro completed' },
                { type: 'mood', title: 'Mood Check-in', description: 'Feeling great, high energy' },
                { type: 'flashcard', title: 'Flashcard Review', description: 'Reviewed 15 Biology cards' },
                { type: 'topic', title: 'Topic Completed', description: 'Finished "Machine Learning Fundamentals"' },
                { type: 'streak', title: 'Streak Milestone', description: '7-day streak achieved! 🔥' },
                { type: 'note', title: 'Notes Created', description: 'Chapter 5 — Macro Economics summary' },
                { type: 'goal', title: 'Goal Reached', description: 'Completed "Study 10 hours" weekly goal' },
                { type: 'chat', title: 'AI Chat Session', description: 'Explored quantum computing basics' },
            ];
            demos.forEach((d, i) => {
                const item: ActivityItem = {
                    ...d,
                    id: (now - i).toString(36),
                    timestamp: new Date(now - i * 3600000 * (1 + Math.random() * 5)).toISOString(),
                };
                const stored = getActivities();
                stored.push(item);
                localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
            });
            setActivities(getActivities());
        }
    }, []);

    const filtered = filterType ? activities.filter(a => a.type === filterType) : activities;

    // Group by date
    const grouped: { label: string; items: ActivityItem[] }[] = [];
    filtered.forEach(item => {
        const label = getDateLabel(item.timestamp);
        const existing = grouped.find(g => g.label === label);
        if (existing) existing.items.push(item);
        else grouped.push({ label, items: [item] });
    });

    const types = [...new Set(activities.map(a => a.type))];

    return (
        <div className="glass-morphism rounded-2xl overflow-hidden">
            {/* Header */}
            <div className="px-5 py-4 border-b border-border/30">
                <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                        <Activity className="w-5 h-5 text-primary" />
                        <h3 className="font-bold text-lg"><span className="gradient-text">Activity Feed</span></h3>
                        <span className="text-xs bg-muted/50 px-2 py-0.5 rounded-full text-muted-foreground">{activities.length}</span>
                    </div>
                </div>
                {types.length > 1 && (
                    <div className="flex gap-1.5 flex-wrap">
                        <button onClick={() => setFilterType(null)}
                            className={cn('px-2.5 py-1 rounded-lg text-xs font-medium transition-all',
                                !filterType ? 'bg-primary/20 text-primary' : 'bg-muted/30 text-muted-foreground hover:bg-muted/50')}>
                            All
                        </button>
                        {types.map(t => {
                            const cfg = TYPE_CONFIG[t];
                            const Icon = cfg.icon;
                            return (
                                <button key={t} onClick={() => setFilterType(filterType === t ? null : t)}
                                    className={cn('flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-all',
                                        filterType === t ? 'bg-primary/20 text-primary' : 'bg-muted/30 text-muted-foreground hover:bg-muted/50')}>
                                    <Icon className="w-3 h-3" />
                                    {t.charAt(0).toUpperCase() + t.slice(1)}
                                </button>
                            );
                        })}
                    </div>
                )}
            </div>

            {/* Timeline */}
            <div className="max-h-[450px] overflow-y-auto p-4">
                {grouped.length === 0 ? (
                    <div className="py-12 text-center">
                        <Activity className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
                        <p className="text-sm text-muted-foreground">No activity yet</p>
                    </div>
                ) : (
                    grouped.map(group => (
                        <div key={group.label} className="mb-6 last:mb-0">
                            <div className="flex items-center gap-2 mb-3">
                                <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{group.label}</span>
                                <div className="flex-1 h-px bg-border/30" />
                            </div>
                            <div className="space-y-2 pl-2 border-l-2 border-border/20">
                                {group.items.map(item => {
                                    const cfg = TYPE_CONFIG[item.type];
                                    const Icon = cfg.icon;
                                    return (
                                        <div key={item.id} className="relative flex items-start gap-3 pl-4 py-2 hover:bg-muted/10 rounded-lg transition-colors -ml-[9px]">
                                            <div className="absolute left-0 top-4 w-2 h-2 rounded-full bg-border" style={{ marginLeft: '-5px' }} />
                                            <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0', cfg.bgColor)}>
                                                <Icon className={cn('w-4 h-4', cfg.color)} />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center gap-2">
                                                    <p className="text-sm font-medium">{item.title}</p>
                                                    <span className="text-[10px] text-muted-foreground">{formatTime(item.timestamp)}</span>
                                                </div>
                                                <p className="text-xs text-muted-foreground">{item.description}</p>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default ActivityFeed;
