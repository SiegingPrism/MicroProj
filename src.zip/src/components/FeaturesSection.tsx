import { Brain, MessageSquare, FileText, Zap, Target, Clock, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const features = [
  {
    icon: Brain,
    title: "Smart AI Chat",
    description: "Get instant, detailed answers to any question. Our AI understands context and provides comprehensive explanations tailored to your level.",
    tag: "Core Feature",
    href: "/chat",
    gradientFrom: "hsl(160, 84%, 39%)",
    gradientTo: "hsl(160, 70%, 32%)",
    glowColor: "hsl(160 84% 39% / 0.12)",
    iconColor: "hsl(160, 84%, 45%)",
  },
  {
    icon: FileText,
    title: "Document Analysis",
    description: "Upload PDFs, notes, or textbooks. The AI summarizes, explains, and helps you understand even the most complex content.",
    tag: "Upload & Learn",
    href: "/tools",
    glowColor: "hsl(38 92% 50% / 0.12)",
    iconColor: "hsl(38, 92%, 55%)",
    gradientFrom: "hsl(38, 92%, 50%)",
    gradientTo: "hsl(28, 90%, 48%)",
  },
  {
    icon: MessageSquare,
    title: "Interactive Learning",
    description: "Engage in natural conversations. Ask follow-up questions, dive deeper into topics, and get clear step-by-step explanations.",
    tag: "Conversational",
    href: "/chat",
    glowColor: "hsl(350 89% 60% / 0.12)",
    iconColor: "hsl(350, 89%, 60%)",
    gradientFrom: "hsl(350, 89%, 60%)",
    gradientTo: "hsl(330, 80%, 55%)",
  },
  {
    icon: Zap,
    title: "Instant Responses",
    description: "No waiting. Get immediate, accurate answers powered by advanced AI — faster than searching through textbooks.",
    tag: "< 1 Second",
    href: "/chat",
    glowColor: "hsl(38 92% 50% / 0.15)",
    iconColor: "hsl(38, 92%, 52%)",
    gradientFrom: "hsl(38, 92%, 50%)",
    gradientTo: "hsl(20, 90%, 52%)",
  },
  {
    icon: Target,
    title: "Personalized Help",
    description: "The AI adapts to your learning style, knowledge level, and subject domain — giving you the right explanation every time.",
    tag: "Adaptive AI",
    href: "/onboarding",
    glowColor: "hsl(160 84% 39% / 0.12)",
    iconColor: "hsl(170, 80%, 42%)",
    gradientFrom: "hsl(160, 84%, 39%)",
    gradientTo: "hsl(180, 75%, 38%)",
  },
  {
    icon: Clock,
    title: "24/7 Availability",
    description: "Study at 2 AM or 2 PM — your AI companion is always ready to help, day or night, without any waiting.",
    tag: "Always On",
    href: "/chat",
    glowColor: "hsl(350 89% 60% / 0.12)",
    iconColor: "hsl(340, 80%, 58%)",
    gradientFrom: "hsl(350, 89%, 60%)",
    gradientTo: "hsl(20, 85%, 55%)",
  },
];

const FeaturesSection = () => {
  return (
    <section className="py-32 px-4 relative overflow-hidden">
      {/* Background */}
      <div
        className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse 60% 40% at 50% 100%, hsl(var(--primary) / 0.06) 0%, transparent 70%)' }}
      />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section header */}
        <div className="text-center mb-20">
          <div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/25 mb-6"
            style={{ background: 'hsl(var(--primary) / 0.08)' }}
          >
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            <span className="text-sm font-medium text-primary/80">Everything You Need</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-extrabold mb-5 tracking-tight text-foreground">
            Features designed to make
            <span
              className="block mt-1"
              style={{
                background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 50%, hsl(var(--accent)) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              you learn smarter
            </span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto font-normal leading-relaxed">
            Powerful AI features that accelerate your learning and help you achieve more — in less time.
          </p>
        </div>

        {/* Feature cards grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((feature, index) => (
            <Link
              key={feature.title}
              to={feature.href}
              className="group relative rounded-2xl p-6 border border-border transition-all duration-300 cursor-pointer overflow-hidden animate-fade-in hover:border-primary/30 hover:shadow-lg hover:-translate-y-1 block"
              style={{
                animationDelay: `${index * 0.08}s`,
                background: 'hsl(var(--card))',
              }}
            >
              {/* Hover glow overlay */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl pointer-events-none"
                style={{ background: `radial-gradient(ellipse 80% 60% at 30% 0%, ${feature.glowColor} 0%, transparent 70%)` }}
              />

              {/* Top row */}
              <div className="flex items-center justify-between mb-5">
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 border"
                  style={{
                    background: `linear-gradient(135deg, ${feature.glowColor} 0%, hsl(var(--muted)) 100%)`,
                    borderColor: feature.glowColor,
                  }}
                >
                  <feature.icon className="w-5 h-5 relative z-10" style={{ color: feature.iconColor }} />
                </div>
                <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full border border-border text-muted-foreground bg-muted">
                  {feature.tag}
                </span>
              </div>

              {/* Content */}
              <h3 className="text-[17px] font-bold mb-2.5 text-foreground tracking-tight">{feature.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>

              {/* Bottom reveal action */}
              <div
                className="mt-5 flex items-center gap-1.5 text-xs font-semibold opacity-0 group-hover:opacity-100 transition-all duration-300 -translate-y-1 group-hover:translate-y-0"
                style={{ color: feature.iconColor }}
              >
                <span>Explore</span>
                <ArrowRight className="w-3 h-3" />
              </div>
            </Link>
          ))}
        </div>

        {/* Bottom CTA banner */}
        <div
          className="mt-16 rounded-2xl p-px overflow-hidden"
          style={{ background: 'linear-gradient(135deg, hsl(var(--primary) / 0.4) 0%, hsl(var(--secondary) / 0.4) 50%, hsl(var(--accent) / 0.4) 100%)' }}
        >
          <div
            className="rounded-[15px] p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6"
            style={{ background: 'hsl(var(--card))' }}
          >
            <div className="text-left">
              <h3 className="text-2xl font-extrabold tracking-tight mb-1 text-foreground">Ready to transform your learning?</h3>
              <p className="text-muted-foreground text-sm">Join thousands of students who study smarter with AI.</p>
            </div>
            <Link to="/auth" className="flex-shrink-0">
              <button
                className="flex items-center gap-2 px-7 py-3.5 rounded-xl font-semibold text-sm text-white transition-all duration-300 hover:opacity-90 hover:scale-[1.02] active:scale-[0.98] shadow-xl shadow-primary/20 border-0"
                style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
              >
                Start for Free
                <ArrowRight className="w-4 h-4" />
              </button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
