import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Clock, Target, Trophy, Flame, BookOpen, Star } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface StudyStats {
  topicsCompleted: number;
  totalMinutes: number;
  currentStreak: number;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  requirement_type: string;
  requirement_value: number;
  earned: boolean;
  earned_at?: string;
}

interface StudyProgressTrackerProps {
  userId: string;
}

const iconMap: Record<string, any> = {
  star: Star,
  'book-open': BookOpen,
  'graduation-cap': Trophy,
  clock: Clock,
  timer: Flame,
  trophy: Trophy,
};

export const StudyProgressTracker = ({ userId }: StudyProgressTrackerProps) => {
  const [stats, setStats] = useState<StudyStats>({
    topicsCompleted: 0,
    totalMinutes: 0,
    currentStreak: 0,
  });
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchProgress = async () => {
      try {
        // Fetch completed topics count
        const { count: topicsCount } = await supabase
          .from('completed_topics')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', userId);

        // Fetch total study time
        const { data: sessions } = await supabase
          .from('study_sessions')
          .select('duration_minutes')
          .eq('user_id', userId);

        const totalMinutes = sessions?.reduce((acc, s) => acc + (s.duration_minutes || 0), 0) || 0;

        // Calculate streak (days with sessions)
        const { data: recentSessions } = await supabase
          .from('study_sessions')
          .select('started_at')
          .eq('user_id', userId)
          .order('started_at', { ascending: false })
          .limit(30);

        const streak = calculateStreak(recentSessions?.map(s => s.started_at) || []);

        setStats({
          topicsCompleted: topicsCount || 0,
          totalMinutes,
          currentStreak: streak,
        });

        // Fetch all achievements and user's earned ones
        const { data: allAchievements } = await supabase
          .from('achievements')
          .select('*');

        const { data: earnedAchievements } = await supabase
          .from('user_achievements')
          .select('achievement_id, earned_at')
          .eq('user_id', userId);

        const earnedMap = new Map(earnedAchievements?.map(a => [a.achievement_id, a.earned_at]));

        const achievementsWithStatus = allAchievements?.map(a => ({
          ...a,
          earned: earnedMap.has(a.id),
          earned_at: earnedMap.get(a.id),
        })) || [];

        setAchievements(achievementsWithStatus);

        // Check for new achievements
        await checkAndAwardAchievements(userId, topicsCount || 0, totalMinutes, achievementsWithStatus);
      } catch (error) {
        console.error('Error fetching progress:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProgress();
  }, [userId]);

  const calculateStreak = (dates: string[]): number => {
    if (dates.length === 0) return 0;
    
    const uniqueDays = [...new Set(dates.map(d => new Date(d).toDateString()))];
    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    for (let i = 0; i < uniqueDays.length; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(checkDate.getDate() - i);
      if (uniqueDays.includes(checkDate.toDateString())) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    
    return streak;
  };

  const checkAndAwardAchievements = async (
    userId: string,
    topicsCount: number,
    totalMinutes: number,
    currentAchievements: Achievement[]
  ) => {
    const toAward = currentAchievements.filter(a => {
      if (a.earned) return false;
      if (a.requirement_type === 'topics_completed' && topicsCount >= a.requirement_value) return true;
      if (a.requirement_type === 'minutes_studied' && totalMinutes >= a.requirement_value) return true;
      return false;
    });

    for (const achievement of toAward) {
      await supabase.from('user_achievements').insert({
        user_id: userId,
        achievement_id: achievement.id,
      });
    }

    if (toAward.length > 0) {
      // Refresh achievements
      const { data: allAchievements } = await supabase.from('achievements').select('*');
      const { data: earnedAchievements } = await supabase
        .from('user_achievements')
        .select('achievement_id, earned_at')
        .eq('user_id', userId);

      const earnedMap = new Map(earnedAchievements?.map(a => [a.achievement_id, a.earned_at]));
      setAchievements(allAchievements?.map(a => ({
        ...a,
        earned: earnedMap.has(a.id),
        earned_at: earnedMap.get(a.id),
      })) || []);
    }
  };

  const formatTime = (minutes: number): string => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  };

  if (isLoading) {
    return (
      <div className="glass rounded-xl p-6 animate-pulse">
        <div className="h-6 bg-muted rounded w-1/3 mb-4" />
        <div className="grid grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-20 bg-muted rounded" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="glass rounded-xl p-4 text-center">
          <Target className="w-6 h-6 text-primary mx-auto mb-2" />
          <p className="text-2xl font-bold">{stats.topicsCompleted}</p>
          <p className="text-xs text-muted-foreground">Topics Completed</p>
        </div>
        <div className="glass rounded-xl p-4 text-center">
          <Clock className="w-6 h-6 text-green-400 mx-auto mb-2" />
          <p className="text-2xl font-bold">{formatTime(stats.totalMinutes)}</p>
          <p className="text-xs text-muted-foreground">Time Studied</p>
        </div>
        <div className="glass rounded-xl p-4 text-center">
          <Flame className="w-6 h-6 text-orange-400 mx-auto mb-2" />
          <p className="text-2xl font-bold">{stats.currentStreak}</p>
          <p className="text-xs text-muted-foreground">Day Streak</p>
        </div>
      </div>

      {/* Achievements Section */}
      <div className="glass rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="w-5 h-5 text-amber-400" />
          <h3 className="font-semibold">Achievements</h3>
          <span className="text-xs text-muted-foreground ml-auto">
            {achievements.filter(a => a.earned).length}/{achievements.length} unlocked
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {achievements.map((achievement) => {
            const Icon = iconMap[achievement.icon] || Trophy;
            const progress = achievement.requirement_type === 'topics_completed'
              ? Math.min((stats.topicsCompleted / achievement.requirement_value) * 100, 100)
              : Math.min((stats.totalMinutes / achievement.requirement_value) * 100, 100);

            return (
              <div
                key={achievement.id}
                className={`relative rounded-lg p-3 border transition-all ${
                  achievement.earned
                    ? 'bg-primary/10 border-primary/30'
                    : 'bg-muted/30 border-border/50 opacity-60'
                }`}
              >
                <div className="flex items-start gap-2">
                  <div className={`p-2 rounded-lg ${achievement.earned ? 'bg-primary/20' : 'bg-muted'}`}>
                    <Icon className={`w-4 h-4 ${achievement.earned ? 'text-primary' : 'text-muted-foreground'}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{achievement.name}</p>
                    <p className="text-xs text-muted-foreground line-clamp-2">{achievement.description}</p>
                  </div>
                </div>
                {!achievement.earned && (
                  <Progress value={progress} className="h-1 mt-2" />
                )}
                {achievement.earned && (
                  <div className="absolute top-2 right-2">
                    <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
