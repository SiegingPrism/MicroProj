import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Calendar, Clock, BookOpen, Loader2 } from 'lucide-react';

interface ScheduleItem {
  id: string;
  subject: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  domain: string | null;
}

interface StudyScheduleProps {
  userId: string;
}

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export const StudySchedule = ({ userId }: StudyScheduleProps) => {
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchSchedule = async () => {
      const { data, error } = await supabase
        .from('study_schedules')
        .select('*')
        .eq('user_id', userId)
        .order('day_of_week', { ascending: true })
        .order('start_time', { ascending: true });

      if (!error && data) {
        setSchedule(data);
      }
      setIsLoading(false);
    };

    fetchSchedule();
  }, [userId]);

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minutes} ${ampm}`;
  };

  const todayIndex = new Date().getDay() === 0 ? 6 : new Date().getDay() - 1;
  const todaySchedule = schedule.filter(s => s.day_of_week === todayIndex);

  if (isLoading) {
    return (
      <div className="glass rounded-xl p-6 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  if (schedule.length === 0) {
    return (
      <div className="glass rounded-xl p-6 text-center">
        <Calendar className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
        <p className="text-muted-foreground">No study schedule yet</p>
        <p className="text-sm text-muted-foreground mt-1">Complete onboarding to get your personalized schedule</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Today's Schedule */}
      <div className="glass rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <Calendar className="w-5 h-5 text-primary" />
          <h3 className="font-semibold">Today's Schedule</h3>
          <span className="text-sm text-muted-foreground ml-auto">{DAYS[todayIndex]}</span>
        </div>
        
        {todaySchedule.length === 0 ? (
          <p className="text-muted-foreground text-sm">No classes today!</p>
        ) : (
          <div className="space-y-3">
            {todaySchedule.map((item) => (
              <div key={item.id} className="flex items-center gap-4 p-3 rounded-lg bg-muted/50">
                <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{item.subject}</p>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    {formatTime(item.start_time)} - {formatTime(item.end_time)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Weekly Overview */}
      <div className="glass rounded-xl p-6">
        <h3 className="font-semibold mb-4">Weekly Overview</h3>
        <div className="grid gap-2">
          {DAYS.slice(0, 6).map((day, index) => {
            const daySchedule = schedule.filter(s => s.day_of_week === index);
            return (
              <div 
                key={day} 
                className={`flex items-center gap-3 p-3 rounded-lg ${
                  index === todayIndex ? 'bg-primary/10 border border-primary/20' : 'bg-muted/30'
                }`}
              >
                <span className={`w-20 text-sm font-medium ${
                  index === todayIndex ? 'text-primary' : 'text-muted-foreground'
                }`}>
                  {day.slice(0, 3)}
                </span>
                <div className="flex-1 flex flex-wrap gap-2">
                  {daySchedule.length === 0 ? (
                    <span className="text-xs text-muted-foreground">Free day</span>
                  ) : (
                    daySchedule.map((item) => (
                      <span 
                        key={item.id} 
                        className="px-2 py-1 rounded-full bg-primary/20 text-primary text-xs"
                      >
                        {item.subject}
                      </span>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};