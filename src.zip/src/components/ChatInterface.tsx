import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Bot, Loader2, Sparkles, Volume2, Lightbulb, BookOpen, FileQuestion, GraduationCap } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { useChatHistory } from "@/hooks/useChatHistory";
import { ChatSidebar } from "./ChatSidebar";
import { ChatMessage } from "./chat/ChatMessage";
import { VoiceInput } from "./voice/VoiceInput";
import { supabase } from "@/integrations/supabase/client";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

const domainNames: Record<string, string> = {
  tech_engineering: "Technology & Engineering",
  business_management: "Business & Management",
  sciences: "Sciences",
  arts_humanities: "Arts & Humanities",
  other: "General Studies",
};

const ChatInterface = () => {
  const { user } = useAuth();
  const [userDomain, setUserDomain] = useState<string | null>(null);
  const {
    conversations,
    currentConversationId,
    messages: savedMessages,
    isLoading: historyLoading,
    createConversation,
    saveMessage,
    deleteConversation,
    loadConversation,
    startNewChat,
  } = useChatHistory(user?.id);

  // Fetch user's domain
  useEffect(() => {
    const fetchUserDomain = async () => {
      if (!user?.id) return;
      const { data } = await supabase
        .from("profiles")
        .select("domain")
        .eq("user_id", user.id)
        .single();
      if (data?.domain) {
        setUserDomain(data.domain);
      }
    };
    fetchUserDomain();
  }, [user?.id]);

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [enableVoiceResponse, setEnableVoiceResponse] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Sync saved messages with local state
  useEffect(() => {
    if (savedMessages.length > 0) {
      setMessages(savedMessages);
    } else if (!currentConversationId) {
      setMessages([
        {
          id: "welcome",
          role: "assistant",
          content: "Hello! I'm your AI study companion. I'm here to help you learn, understand complex topics, and answer any questions you have. What would you like to explore today?",
          timestamp: new Date(),
        },
      ]);
    }
  }, [savedMessages, currentConversationId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    let conversationId = currentConversationId;

    // Create new conversation if needed
    if (!conversationId && user) {
      conversationId = await createConversation(userMessage.content);
    }

    // Save user message
    if (conversationId && user) {
      await saveMessage(conversationId, "user", userMessage.content);
    }

    try {
      const response = await fetch(
        "https://zzxzmqfqmgdovysxphhu.supabase.co/functions/v1/ai-chat",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            messages: [...messages, userMessage].map((m) => ({
              role: m.role,
              content: m.content,
            })),
            domain: userDomain,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to get response");
      }

      const data = await response.json();

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.response || "I apologize, but I couldn't generate a response. Please try again.",
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);

      // Save assistant message
      if (conversationId && user) {
        await saveMessage(conversationId, "assistant", assistantMessage.content);
      }

      // Speak response if voice is enabled
      if (enableVoiceResponse && (window as any).__speakResponse) {
        (window as any).__speakResponse(assistantMessage.content);
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to get response. Please try again.");

      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "I'm sorry, I encountered an error. Please try again in a moment.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleVoiceTranscript = (transcript: string) => {
    setInput(transcript);
    // Optionally auto-send the message
    setTimeout(() => {
      sendMessage();
    }, 100);
  };

  const handleNewChat = () => {
    startNewChat();
    setMessages([
      {
        id: "welcome",
        role: "assistant",
        content: "Hello! I'm your AI study companion. I'm here to help you learn, understand complex topics, and answer any questions you have. What would you like to explore today?",
        timestamp: new Date(),
      },
    ]);
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] max-w-6xl mx-auto">
      {/* Sidebar */}
      {user && (
        <ChatSidebar
          conversations={conversations}
          currentConversationId={currentConversationId}
          onNewChat={handleNewChat}
          onSelectConversation={loadConversation}
          onDeleteConversation={deleteConversation}
        />
      )}

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Chat header */}
        <div className="bento-card !rounded-b-none !border-b-0 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center animate-pulse-glow"
                style={{ background: 'linear-gradient(135deg, hsl(var(--primary) / 0.2) 0%, hsl(var(--secondary) / 0.15) 100%)' }}>
                <Sparkles className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="font-semibold">AI Study Assistant</h2>
                <p className="text-xs text-muted-foreground">
                  {isLoading ? (
                    <span className="text-primary">Thinking...</span>
                  ) : userDomain ? `Specialized in ${domainNames[userDomain] || 'General Studies'}` : 'Start a new conversation'}
                </p>
              </div>
            </div>
            {/* Quick actions */}
            <div className="hidden md:flex gap-1.5">
              {[
                { label: 'Summarize', icon: BookOpen, prompt: 'Summarize the key points of our conversation so far in a concise format.' },
                { label: 'Quiz Me', icon: FileQuestion, prompt: 'Create a quick 5-question quiz based on what we\'ve discussed to test my understanding.' },
                { label: 'Explain', icon: Lightbulb, prompt: 'Explain the last topic we discussed in simpler terms with examples.' },
                { label: 'Study Tips', icon: GraduationCap, prompt: 'Give me practical study tips and memory techniques for the topics we\'ve been discussing.' },
              ].map(action => (
                <button
                  key={action.label}
                  onClick={() => { setInput(action.prompt); }}
                  className="px-3 py-1.5 rounded-lg text-[11px] font-medium text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all flex items-center gap-1.5 border border-transparent hover:border-primary/20"
                  disabled={isLoading}
                >
                  <action.icon className="w-3 h-3" />
                  {action.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea ref={scrollRef} className="flex-1 glass border-x border-border/50">
          <div className="p-4 space-y-6">
            {historyLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-primary" />
              </div>
            ) : (
              messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  id={message.id}
                  role={message.role}
                  content={message.content}
                  timestamp={message.timestamp}
                  domain={userDomain}
                />
              ))
            )}

            {isLoading && (
              <div className="flex gap-3 animate-slide-up">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{ background: 'hsl(var(--primary) / 0.15)' }}>
                  <Bot className="w-4 h-4 text-primary" />
                </div>
                <div className="bento-card !p-0 !rounded-xl">
                  <div className="typing-indicator">
                    <span /><span /><span />
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="glass rounded-b-2xl p-4 border-t border-border/50">
          <div className="flex gap-3">
            <VoiceInput
              onTranscript={handleVoiceTranscript}
              onSpeakResponse={enableVoiceResponse ? () => { } : undefined}
              isProcessing={isLoading}
            />
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask anything... (Press Enter to send, or use voice)"
              className="min-h-[50px] max-h-[150px] resize-none bg-muted/50 border-border/50 flex-1"
              disabled={isLoading}
            />
            <div className="flex flex-col gap-1">
              <Button
                onClick={sendMessage}
                disabled={!input.trim() || isLoading}
                size="icon"
                className="h-[50px] w-[50px] shrink-0 text-white shadow-lg shadow-primary/20"
                style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </Button>
            </div>
          </div>
          <div className="flex items-center justify-between mt-2">
            <button
              onClick={() => setEnableVoiceResponse(!enableVoiceResponse)}
              className={`flex items-center gap-1 text-xs transition-colors ${enableVoiceResponse ? "text-primary" : "text-muted-foreground hover:text-foreground"
                }`}
            >
              <Volume2 className="w-3 h-3" />
              Voice responses {enableVoiceResponse ? "ON" : "OFF"}
            </button>
            <p className="text-xs text-muted-foreground">
              AI can make mistakes. Consider checking important information.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;