import { Button } from "@/components/ui/button";
import { Sparkles, ArrowRight, Brain, BookOpen, Lightbulb, Zap, Star } from "lucide-react";
import { Link } from "react-router-dom";

const floatingCards = [
  { icon: Brain, label: "Smart AI", value: "GPT-4", glowBg: "hsl(160 84% 39% / 0.12)", border: "hsl(160 84% 39% / 0.35)", delay: "0s", pos: "top-24 left-8", href: "/chat" },
  { icon: BookOpen, label: "Topics", value: "50+", glowBg: "hsl(38 92% 50% / 0.12)", border: "hsl(38 92% 50% / 0.35)", delay: "2s", pos: "top-48 right-8", href: "/tools" },
  { icon: Zap, label: "Response", value: "< 1s", glowBg: "hsl(350 89% 60% / 0.12)", border: "hsl(350 89% 60% / 0.35)", delay: "4s", pos: "bottom-48 left-8", href: "/chat" },
  { icon: Star, label: "Rating", value: "4.9★", glowBg: "hsl(38 92% 50% / 0.12)", border: "hsl(38 92% 50% / 0.35)", delay: "1s", pos: "bottom-24 right-8", href: "/leaderboard" },
];

const stats = [
  { value: "10K+", label: "Active Learners", href: "/leaderboard" },
  { value: "1M+", label: "Questions Answered", href: "/chat" },
  { value: "50+", label: "Subjects Covered", href: "/tools" },
];

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden px-4 pt-20">
      {/* Multi-layer background */}
      <div
        className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse 80% 60% at 50% -10%, hsl(var(--primary) / 0.14) 0%, transparent 70%)' }}
      />
      <div
        className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse 60% 50% at 80% 80%, hsl(var(--secondary) / 0.08) 0%, transparent 60%)' }}
      />
      <div
        className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse 40% 40% at 20% 70%, hsl(var(--accent) / 0.06) 0%, transparent 60%)' }}
      />

      {/* Subtle grid */}
      <div
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: 'linear-gradient(hsl(var(--foreground)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--foreground)) 1px, transparent 1px)',
          backgroundSize: '80px 80px',
        }}
      />

      {/* Floating cards — desktop only */}
      {floatingCards.map(({ icon: Icon, label, value, glowBg, border, delay, pos, href }) => (
        <Link
          key={label}
          to={href}
          className={`absolute hidden lg:flex ${pos} float-animation items-center gap-3 px-4 py-3 rounded-2xl backdrop-blur-xl border hover:scale-105 transition-transform duration-300`}
          style={{
            animationDelay: delay,
            background: glowBg,
            borderColor: border,
          }}
        >
          <div className="w-8 h-8 rounded-lg bg-white/10 dark:bg-white/10 flex items-center justify-center">
            <Icon className="w-4 h-4" style={{ color: border.replace(' / 0.35)', ' / 0.9)') }} />
          </div>
          <div>
            <div className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">{label}</div>
            <div className="text-sm font-bold text-foreground">{value}</div>
          </div>
        </Link>
      ))}

      {/* Main content */}
      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 mb-8 animate-fade-in">
          <div
            className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium border border-primary/30"
            style={{ background: 'hsl(var(--primary) / 0.08)' }}
          >
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <span className="text-primary/90">AI-Powered Learning Platform</span>
            <div className="w-px h-3.5 bg-primary/30" />
            <span className="text-primary/60 text-xs">v3.0</span>
          </div>
        </div>

        {/* Headline */}
        <h1
          className="text-5xl md:text-7xl font-extrabold mb-6 leading-[1.08] tracking-tight text-foreground animate-fade-in"
          style={{ animationDelay: '0.1s' }}
        >
          Your Personal
          <span
            className="block mt-1"
            style={{
              background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 50%, hsl(var(--accent)) 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            AI Study Companion
          </span>
        </h1>

        {/* Subheadline */}
        <p
          className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed font-normal animate-fade-in"
          style={{ animationDelay: '0.2s' }}
        >
          Transform how you learn with an intelligent AI that understands your goals,
          answers complex questions, and personalizes your entire study journey.
        </p>

        {/* CTA Buttons */}
        <div
          className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in"
          style={{ animationDelay: '0.3s' }}
        >
          <Link to="/chat">
            <Button
              size="lg"
              className="text-base px-8 py-6 h-auto rounded-xl font-semibold group shadow-2xl shadow-primary/25 border-0 text-white"
              style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
            >
              Start Learning Free
              <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
            </Button>
          </Link>
          <Link to="/tools">
            <Button
              variant="outline"
              size="lg"
              className="text-base px-8 py-6 h-auto rounded-xl font-semibold hover:bg-muted transition-all"
            >
              <Lightbulb className="mr-2 w-4 h-4 text-secondary" />
              Explore Tools
            </Button>
          </Link>
        </div>

        {/* Social proof */}
        <div
          className="mt-8 animate-fade-in flex items-center justify-center gap-3"
          style={{ animationDelay: '0.4s' }}
        >
          <div className="flex -space-x-2">
            {['#10b981', '#f59e0b', '#f43f5e', '#14b8a6', '#06b6d4'].map((color, i) => (
              <div
                key={i}
                className="w-7 h-7 rounded-full border-2 border-background flex items-center justify-center text-xs font-bold text-white"
                style={{ background: color }}
              >
                {String.fromCharCode(65 + i)}
              </div>
            ))}
          </div>
          <Link to="/leaderboard" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Trusted by <span className="text-foreground font-semibold">10,000+</span> students worldwide →
          </Link>
        </div>

        {/* Stats */}
        <div
          className="grid grid-cols-3 gap-px mt-16 rounded-2xl overflow-hidden border border-border animate-fade-in"
          style={{ animationDelay: '0.5s', background: 'hsl(var(--border))' }}
        >
          {stats.map(({ value, label, href }) => (
            <Link
              key={label}
              to={href}
              className="py-6 px-4 text-center hover:bg-muted transition-colors duration-200 group"
              style={{ background: 'hsl(var(--card))' }}
            >
              <div
                className="text-2xl md:text-3xl font-extrabold mb-1 group-hover:scale-105 transition-transform duration-200"
                style={{
                  background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                }}
              >
                {value}
              </div>
              <div className="text-xs text-muted-foreground font-medium">{label}</div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
