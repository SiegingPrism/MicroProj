import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar, Loader2, Plus, Sparkles, Trash2, Clock } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

interface ScheduleItem {
  day: number;
  subject: string;
  startTime: string;
  endTime: string;
  priority: "high" | "medium" | "low";
  tips?: string;
}

interface Preferences {
  preferredTime: "morning" | "afternoon" | "evening";
  sessionLength: number;
}

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const PRIORITY_COLORS = {
  high: "bg-red-500/20 text-red-500 border-red-500/30",
  medium: "bg-yellow-500/20 text-yellow-500 border-yellow-500/30",
  low: "bg-green-500/20 text-green-500 border-green-500/30",
};

export const StudyScheduler = () => {
  const { user } = useAuth();
  const [subjects, setSubjects] = useState<string[]>([]);
  const [newSubject, setNewSubject] = useState("");
  const [preferences, setPreferences] = useState<Preferences>({
    preferredTime: "morning",
    sessionLength: 60,
  });
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const [recommendations, setRecommendations] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [userDomain, setUserDomain] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      fetchUserDomain();
      fetchExistingSchedule();
    }
  }, [user]);

  const fetchUserDomain = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("profiles")
      .select("domain")
      .eq("user_id", user.id)
      .single();
    if (data?.domain) {
      setUserDomain(data.domain);
    }
  };

  const fetchExistingSchedule = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("study_schedules")
      .select("*")
      .eq("user_id", user.id)
      .order("day_of_week", { ascending: true });

    if (data && data.length > 0) {
      const scheduleItems: ScheduleItem[] = data.map((item) => ({
        day: item.day_of_week,
        subject: item.subject,
        startTime: item.start_time,
        endTime: item.end_time,
        priority: "medium" as const,
      }));
      setSchedule(scheduleItems);
      
      // Extract unique subjects
      const uniqueSubjects = [...new Set(data.map((item) => item.subject))];
      setSubjects(uniqueSubjects);
    }
  };

  const addSubject = () => {
    if (newSubject.trim() && !subjects.includes(newSubject.trim())) {
      setSubjects([...subjects, newSubject.trim()]);
      setNewSubject("");
    }
  };

  const removeSubject = (subject: string) => {
    setSubjects(subjects.filter((s) => s !== subject));
  };

  const generateSchedule = async () => {
    if (subjects.length === 0) {
      toast.error("Please add at least one subject");
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/study-scheduler`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
            "Authorization": `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({
            subjects,
            preferences,
            existingSchedule: schedule,
            domain: userDomain,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to generate schedule");
      }

      const data = await response.json();
      setSchedule(data.schedule || []);
      setRecommendations(data.recommendations || []);

      // Save schedule to database
      if (user && data.schedule) {
        // Clear existing schedule
        await supabase.from("study_schedules").delete().eq("user_id", user.id);

        // Insert new schedule
        const schedulesToInsert = data.schedule.map((item: ScheduleItem) => ({
          user_id: user.id,
          subject: item.subject,
          day_of_week: item.day,
          start_time: item.startTime,
          end_time: item.endTime,
          domain: userDomain,
        }));

        await supabase.from("study_schedules").insert(schedulesToInsert);
      }

      toast.success("Schedule generated successfully!");
    } catch (error) {
      console.error("Error generating schedule:", error);
      toast.error("Failed to generate schedule. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const groupedSchedule = schedule.reduce((acc, item) => {
    if (!acc[item.day]) acc[item.day] = [];
    acc[item.day].push(item);
    return acc;
  }, {} as Record<number, ScheduleItem[]>);

  return (
    <Card className="glass border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary" />
          AI Study Scheduler
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Subject Input */}
        <div className="space-y-3">
          <label className="text-sm font-medium">Your Subjects</label>
          <div className="flex gap-2">
            <Input
              placeholder="Add a subject..."
              value={newSubject}
              onChange={(e) => setNewSubject(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addSubject()}
            />
            <Button onClick={addSubject} size="icon">
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {subjects.map((subject) => (
              <Badge
                key={subject}
                variant="secondary"
                className="gap-1 px-3 py-1"
              >
                {subject}
                <button
                  onClick={() => removeSubject(subject)}
                  className="ml-1 hover:text-destructive"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>

        {/* Preferences */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Preferred Time</label>
            <Select
              value={preferences.preferredTime}
              onValueChange={(value: "morning" | "afternoon" | "evening") =>
                setPreferences({ ...preferences, preferredTime: value })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="morning">Morning (6AM-12PM)</SelectItem>
                <SelectItem value="afternoon">Afternoon (12PM-6PM)</SelectItem>
                <SelectItem value="evening">Evening (6PM-10PM)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Session Length</label>
            <Select
              value={preferences.sessionLength.toString()}
              onValueChange={(value) =>
                setPreferences({ ...preferences, sessionLength: parseInt(value) })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30">30 minutes</SelectItem>
                <SelectItem value="45">45 minutes</SelectItem>
                <SelectItem value="60">1 hour</SelectItem>
                <SelectItem value="90">1.5 hours</SelectItem>
                <SelectItem value="120">2 hours</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Generate Button */}
        <Button
          onClick={generateSchedule}
          disabled={isLoading || subjects.length === 0}
          className="w-full gap-2"
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4" />
          )}
          Generate Optimal Schedule
        </Button>

        {/* Schedule Display */}
        {schedule.length > 0 && (
          <div className="space-y-4">
            <h3 className="font-medium">Your Weekly Schedule</h3>
            <div className="space-y-3">
              {DAYS.map((day, dayIndex) => {
                const daySchedule = groupedSchedule[dayIndex] || [];
                if (daySchedule.length === 0) return null;

                return (
                  <div key={day} className="p-3 rounded-xl bg-muted/50">
                    <p className="font-medium text-sm mb-2">{day}</p>
                    <div className="space-y-2">
                      {daySchedule.map((item, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between p-2 rounded-lg bg-background/50"
                        >
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm">
                              {item.startTime} - {item.endTime}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">
                              {item.subject}
                            </span>
                            <Badge
                              variant="outline"
                              className={PRIORITY_COLORS[item.priority]}
                            >
                              {item.priority}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Recommendations */}
        {recommendations.length > 0 && (
          <div className="space-y-2 p-4 rounded-xl bg-primary/5 border border-primary/20">
            <p className="font-medium text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              AI Recommendations
            </p>
            <ul className="space-y-1">
              {recommendations.map((rec, idx) => (
                <li key={idx} className="text-sm text-muted-foreground">
                  • {rec}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default StudyScheduler;
