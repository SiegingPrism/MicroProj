import { useState, useRef } from 'react';
import { Plus, Trash2, Search, FileText, Clock, Save, X, ChevronLeft, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

interface Note {
    id: string;
    title: string;
    content: string;
    createdAt: number;
    updatedAt: number;
    color: string;
}

const STORAGE_KEY = 'studyai_notes';
const COLORS = [
    'hsl(160 84% 39% / 0.1)', // emerald
    'hsl(38 92% 50% / 0.1)',  // amber
    'hsl(350 89% 60% / 0.1)', // rose
    'hsl(200 90% 50% / 0.1)', // sky
    'hsl(280 70% 50% / 0.1)', // purple
    'hsl(0 0% 50% / 0.1)',    // gray
];

const loadNotes = (): Note[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch { return []; }
};

const saveNotes = (notes: Note[]) =>
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));

const generateId = () => Math.random().toString(36).substring(2, 15);

const formatDate = (ts: number) => {
    const d = new Date(ts);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

export default function NotebookSystem() {
    const [notes, setNotes] = useState<Note[]>(loadNotes);
    const [activeNote, setActiveNote] = useState<Note | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [editTitle, setEditTitle] = useState('');
    const [editContent, setEditContent] = useState('');
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    const persist = (updated: Note[]) => {
        setNotes(updated);
        saveNotes(updated);
    };

    const createNote = () => {
        const note: Note = {
            id: generateId(),
            title: 'Untitled Note',
            content: '',
            createdAt: Date.now(),
            updatedAt: Date.now(),
            color: COLORS[Math.floor(Math.random() * COLORS.length)],
        };
        persist([note, ...notes]);
        openNote(note);
        toast.success('New note created');
    };

    const openNote = (note: Note) => {
        setActiveNote(note);
        setEditTitle(note.title);
        setEditContent(note.content);
        setTimeout(() => textareaRef.current?.focus(), 50);
    };

    const saveNote = () => {
        if (!activeNote) return;
        const updated = notes.map(n =>
            n.id === activeNote.id
                ? { ...n, title: editTitle.trim() || 'Untitled', content: editContent, updatedAt: Date.now() }
                : n
        );
        persist(updated);
        setActiveNote({ ...activeNote, title: editTitle.trim() || 'Untitled', content: editContent, updatedAt: Date.now() });
        toast.success('Note saved');
    };

    const deleteNote = (id: string) => {
        if (!confirm('Delete this note?')) return;
        persist(notes.filter(n => n.id !== id));
        if (activeNote?.id === id) setActiveNote(null);
        toast.success('Note deleted');
    };

    const filtered = notes.filter(n =>
        n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.content.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const wordCount = editContent.split(/\s+/).filter(w => w.length > 0).length;

    // ─── Note Editor View ───────
    if (activeNote) {
        return (
            <div className="space-y-4">
                {/* Toolbar */}
                <div className="flex items-center gap-2 flex-wrap">
                    <Button variant="ghost" size="sm" onClick={() => { saveNote(); setActiveNote(null); }}>
                        <ChevronLeft className="w-4 h-4 mr-1" /> Back
                    </Button>
                    <div className="flex-1" />
                    <span className="text-xs text-muted-foreground">{wordCount} words</span>
                    <span className="text-xs text-muted-foreground">• {formatDate(activeNote.updatedAt)}</span>
                    <Button
                        size="sm"
                        onClick={saveNote}
                        className="text-white gap-1.5"
                        style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
                    >
                        <Save className="w-3.5 h-3.5" /> Save
                    </Button>
                </div>

                {/* Title */}
                <input
                    value={editTitle}
                    onChange={e => setEditTitle(e.target.value)}
                    placeholder="Note title..."
                    className="w-full text-3xl font-bold bg-transparent border-none outline-none placeholder:text-muted-foreground/40"
                />

                {/* Content editor */}
                <div className="bento-card min-h-[400px] noise-overlay !p-0">
                    <textarea
                        ref={textareaRef}
                        value={editContent}
                        onChange={e => setEditContent(e.target.value)}
                        placeholder="Start writing your notes here...

Tips:
• Use this space to capture lecture notes
• Write summaries of chapters you've studied
• Draft essay outlines and ideas
• Keep track of important formulas and concepts"
                        className="w-full h-full min-h-[400px] bg-transparent border-none outline-none resize-none p-6 text-sm leading-relaxed placeholder:text-muted-foreground/30 font-mono"
                    />
                </div>
            </div>
        );
    }

    // ─── Notes List View ───────
    return (
        <div className="space-y-6">
            {/* Header with search */}
            <div className="flex items-center gap-3 flex-wrap">
                <div className="relative flex-1 min-w-[200px]">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                    <Input
                        placeholder="Search notes..."
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        className="pl-9"
                    />
                </div>
                <Button
                    onClick={createNote}
                    className="text-white gap-1.5 shrink-0"
                    style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
                >
                    <Plus className="w-4 h-4" /> New Note
                </Button>
            </div>

            {/* Notes grid */}
            {filtered.length === 0 ? (
                <div className="bento-card text-center py-16">
                    <FileText className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-xl font-bold mb-2">
                        {notes.length === 0 ? 'No notes yet' : 'No matching notes'}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-4">
                        {notes.length === 0
                            ? 'Create your first note to start capturing ideas!'
                            : 'Try a different search term'}
                    </p>
                    {notes.length === 0 && (
                        <Button
                            onClick={createNote}
                            className="text-white gap-1.5"
                            style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
                        >
                            <Plus className="w-4 h-4" /> Create Note
                        </Button>
                    )}
                </div>
            ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filtered.map(note => (
                        <div
                            key={note.id}
                            className="bento-card group cursor-pointer hover:!border-primary/30 transition-all"
                            style={{ borderLeftWidth: '3px', borderLeftColor: note.color.replace('0.1', '0.5') }}
                            onClick={() => openNote(note)}
                        >
                            <div className="flex items-start justify-between mb-2">
                                <h3 className="font-bold text-sm truncate flex-1">{note.title}</h3>
                                <button
                                    onClick={e => { e.stopPropagation(); deleteNote(note.id); }}
                                    className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive shrink-0 ml-2"
                                >
                                    <Trash2 className="w-3.5 h-3.5" />
                                </button>
                            </div>
                            <p className="text-xs text-muted-foreground line-clamp-3 mb-3 leading-relaxed">
                                {note.content || 'Empty note'}
                            </p>
                            <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                                <Clock className="w-3 h-3" />
                                {formatDate(note.updatedAt)}
                                <span className="ml-auto">{note.content.split(/\s+/).filter(w => w.length > 0).length} words</span>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}
