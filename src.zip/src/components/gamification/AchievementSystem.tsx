import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Trophy, Star, Flame, Zap, BookOpen, Target, Clock, Users, Award } from 'lucide-react';
import { toast } from 'sonner';
import { Progress } from '@/components/ui/progress';
import { ConfettiCelebration } from './ConfettiCelebration';

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  requirement_type: string;
  requirement_value: number;
}

interface UserAchievement {
  achievement_id: string;
  earned_at: string;
}

interface UserStats {
  totalStudyMinutes: number;
  topicsCompleted: number;
  currentStreak: number;
  quizzesTaken: number;
  focusSessions: number;
  flashcardsReviewed: number;
}

const iconMap: Record<string, React.ElementType> = {
  trophy: Trophy,
  star: Star,
  flame: Flame,
  zap: Zap,
  book: BookOpen,
  target: Target,
  clock: Clock,
  users: Users,
  award: Award,
};

export const AchievementSystem = () => {
  const { user } = useAuth();
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([]);
  const [stats, setStats] = useState<UserStats>({
    totalStudyMinutes: 0,
    topicsCompleted: 0,
    currentStreak: 0,
    quizzesTaken: 0,
    focusSessions: 0,
    flashcardsReviewed: 0,
  });
  const [xp, setXp] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  const [newAchievement, setNewAchievement] = useState<Achievement | null>(null);

  const level = Math.floor(xp / 500) + 1;
  const xpInLevel = xp % 500;
  const xpForNextLevel = 500;

  useEffect(() => {
    if (!user) return;
    fetchData();
  }, [user]);

  const fetchData = async () => {
    if (!user) return;

    const [
      { data: achievementsData },
      { data: userAchievementsData },
      { data: sessions },
      topicsResult,
      quizzesResult,
      focusResult,
      flashcardsResult,
    ] = await Promise.all([
      supabase.from('achievements').select('*'),
      supabase.from('user_achievements').select('*').eq('user_id', user.id),
      supabase.from('study_sessions').select('duration_minutes, started_at').eq('user_id', user.id),
      supabase.from('completed_topics').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
      supabase.from('quiz_results').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
      supabase.from('focus_sessions').select('id', { count: 'exact', head: true }).eq('user_id', user.id).eq('completed', true),
      supabase.from('flashcards').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
    ]);

    setAchievements(achievementsData || []);
    setUserAchievements(userAchievementsData || []);

    const totalMinutes = sessions?.reduce((acc, s) => acc + (s.duration_minutes || 0), 0) || 0;

    // Calculate streak
    const uniqueDays = [...new Set((sessions || []).map(s => new Date(s.started_at).toDateString()))];
    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    for (let i = 0; i < uniqueDays.length; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(checkDate.getDate() - i);
      if (uniqueDays.includes(checkDate.toDateString())) {
        streak++;
      } else if (i > 0) break;
    }

    const newStats: UserStats = {
      totalStudyMinutes: totalMinutes,
      topicsCompleted: topicsResult.count || 0,
      currentStreak: streak,
      quizzesTaken: quizzesResult.count || 0,
      focusSessions: focusResult.count || 0,
      flashcardsReviewed: flashcardsResult.count || 0,
    };

    setStats(newStats);

    // Calculate XP
    const totalXp = totalMinutes * 2 + (newStats.topicsCompleted * 50) + (newStats.quizzesTaken * 30) + (newStats.focusSessions * 20);
    setXp(totalXp);

    // Check for new achievements
    checkNewAchievements(achievementsData || [], userAchievementsData || [], newStats);
  };

  const checkNewAchievements = async (
    allAchievements: Achievement[],
    earned: UserAchievement[],
    currentStats: UserStats
  ) => {
    if (!user) return;
    const earnedIds = new Set(earned.map(a => a.achievement_id));

    for (const achievement of allAchievements) {
      if (earnedIds.has(achievement.id)) continue;

      let met = false;
      switch (achievement.requirement_type) {
        case 'study_minutes':
          met = currentStats.totalStudyMinutes >= achievement.requirement_value;
          break;
        case 'topics_completed':
          met = currentStats.topicsCompleted >= achievement.requirement_value;
          break;
        case 'streak_days':
          met = currentStats.currentStreak >= achievement.requirement_value;
          break;
        case 'quizzes_taken':
          met = currentStats.quizzesTaken >= achievement.requirement_value;
          break;
        case 'focus_sessions':
          met = currentStats.focusSessions >= achievement.requirement_value;
          break;
      }

      if (met) {
        const { error } = await supabase.from('user_achievements').insert({
          user_id: user.id,
          achievement_id: achievement.id,
        });

        if (!error) {
          setNewAchievement(achievement);
          setShowConfetti(true);
          toast.success(`🏆 Achievement Unlocked: ${achievement.name}!`);
          setTimeout(() => {
            setShowConfetti(false);
            setNewAchievement(null);
          }, 4000);
          setUserAchievements(prev => [...prev, { achievement_id: achievement.id, earned_at: new Date().toISOString() }]);
        }
      }
    }
  };

  const earnedIds = new Set(userAchievements.map(a => a.achievement_id));

  const getProgress = (achievement: Achievement) => {
    switch (achievement.requirement_type) {
      case 'study_minutes':
        return Math.min(100, (stats.totalStudyMinutes / achievement.requirement_value) * 100);
      case 'topics_completed':
        return Math.min(100, (stats.topicsCompleted / achievement.requirement_value) * 100);
      case 'streak_days':
        return Math.min(100, (stats.currentStreak / achievement.requirement_value) * 100);
      case 'quizzes_taken':
        return Math.min(100, (stats.quizzesTaken / achievement.requirement_value) * 100);
      case 'focus_sessions':
        return Math.min(100, (stats.focusSessions / achievement.requirement_value) * 100);
      default:
        return 0;
    }
  };

  return (
    <>
      {showConfetti && <ConfettiCelebration />}

      {/* New Achievement Banner */}
      {newAchievement && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 animate-fade-in">
          <div className="glass-morphism rounded-2xl px-8 py-4 flex items-center gap-4 glow-intense animated-border">
            <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center animate-bounce-soft">
              <Trophy className="w-8 h-8 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Achievement Unlocked!</p>
              <p className="font-bold text-lg gradient-text">{newAchievement.name}</p>
              <p className="text-xs text-muted-foreground">{newAchievement.description}</p>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-6">
        {/* XP & Level */}
        <div className="glass-morphism rounded-2xl p-6 animated-border">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <span className="text-lg font-bold text-primary-foreground">{level}</span>
              </div>
              <div>
                <p className="font-bold text-lg">Level {level}</p>
                <p className="text-xs text-muted-foreground">{xp} total XP</p>
              </div>
            </div>
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-destructive" />
            <span className="font-bold text-destructive">{stats.currentStreak} day streak</span>
          </div>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{xpInLevel} / {xpForNextLevel} XP</span>
              <span>Level {level + 1}</span>
            </div>
            <Progress value={(xpInLevel / xpForNextLevel) * 100} className="h-3" />
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3">
          <div className="glass rounded-xl p-4 text-center hover-lift">
            <Clock className="w-5 h-5 mx-auto mb-1 text-primary" />
            <p className="text-xl font-bold">{Math.round(stats.totalStudyMinutes / 60)}h</p>
            <p className="text-xs text-muted-foreground">Study Time</p>
          </div>
          <div className="glass rounded-xl p-4 text-center hover-lift">
            <Target className="w-5 h-5 mx-auto mb-1 text-secondary" />
            <p className="text-xl font-bold">{stats.quizzesTaken}</p>
            <p className="text-xs text-muted-foreground">Quizzes</p>
          </div>
          <div className="glass rounded-xl p-4 text-center hover-lift">
            <Zap className="w-5 h-5 mx-auto mb-1 text-accent" />
            <p className="text-xl font-bold">{stats.focusSessions}</p>
            <p className="text-xs text-muted-foreground">Focus Sessions</p>
          </div>
        </div>

        {/* Achievements */}
        <div className="glass-morphism rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="w-5 h-5 text-primary" />
            <h3 className="font-bold">Achievements</h3>
            <span className="text-xs text-muted-foreground ml-auto">
              {userAchievements.length}/{achievements.length} unlocked
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {achievements.map((achievement) => {
              const isEarned = earnedIds.has(achievement.id);
              const progress = getProgress(achievement);
              const IconComp = iconMap[achievement.icon] || Trophy;

              return (
                <div
                  key={achievement.id}
                  className={`p-4 rounded-xl border transition-all duration-300 ${
                    isEarned
                      ? 'bg-primary/10 border-primary/30 glow'
                      : 'bg-muted/20 border-border/50 opacity-70'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      isEarned ? 'bg-primary/20' : 'bg-muted/50'
                    }`}>
                      <IconComp className={`w-5 h-5 ${isEarned ? 'text-primary' : 'text-muted-foreground'}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`font-medium text-sm ${isEarned ? '' : 'text-muted-foreground'}`}>
                        {achievement.name}
                      </p>
                      <p className="text-xs text-muted-foreground truncate">{achievement.description}</p>
                      {!isEarned && (
                        <div className="mt-2">
                          <Progress value={progress} className="h-1.5" />
                          <p className="text-xs text-muted-foreground mt-1">{Math.round(progress)}%</p>
                        </div>
                      )}
                      {isEarned && (
                        <p className="text-xs text-primary mt-1">✓ Unlocked</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
};
