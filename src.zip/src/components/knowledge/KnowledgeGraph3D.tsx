import { useRef, useState, useMemo, useEffect, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Text, Float } from '@react-three/drei';
import * as THREE from 'three';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Network, RotateCcw, ZoomIn, ZoomOut } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface TopicNode {
  id: string;
  label: string;
  domain?: string;
  completed: boolean;
  position: [number, number, number];
  connections: string[];
}

const DOMAIN_COLORS: Record<string, string> = {
  tech_engineering: '#3b82f6',
  business_management: '#f59e0b',
  sciences: '#22c55e',
  arts_humanities: '#a855f7',
  other: '#ec4899',
};

function TopicSphere({ node, isSelected, onClick }: { node: TopicNode; isSelected: boolean; onClick: () => void }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const glowRef = useRef<THREE.Mesh>(null);
  const color = DOMAIN_COLORS[node.domain || 'other'] || '#ec4899';
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (meshRef.current) {
      const scale = isSelected ? 1.4 : hovered ? 1.2 : 1;
      meshRef.current.scale.lerp(new THREE.Vector3(scale, scale, scale), 0.1);
    }
    if (glowRef.current) {
      const pulse = Math.sin(state.clock.elapsedTime * 2) * 0.1 + 1.5;
      glowRef.current.scale.set(pulse, pulse, pulse);
      (glowRef.current.material as THREE.MeshBasicMaterial).opacity = isSelected ? 0.3 : hovered ? 0.2 : 0.1;
    }
  });

  return (
    <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.3}>
      <group position={node.position}>
        {/* Glow sphere */}
        <mesh ref={glowRef}>
          <sphereGeometry args={[0.5, 16, 16]} />
          <meshBasicMaterial color={color} transparent opacity={0.1} />
        </mesh>
        {/* Main sphere */}
        <mesh
          ref={meshRef}
          onClick={(e) => { e.stopPropagation(); onClick(); }}
          onPointerOver={() => setHovered(true)}
          onPointerOut={() => setHovered(false)}
        >
          <sphereGeometry args={[0.3, 32, 32]} />
          <meshStandardMaterial
            color={color}
            emissive={color}
            emissiveIntensity={node.completed ? 0.8 : 0.3}
            roughness={0.2}
            metalness={0.8}
          />
        </mesh>
        {/* Label */}
        <Text
          position={[0, 0.55, 0]}
          fontSize={0.15}
          color="white"
          anchorX="center"
          anchorY="bottom"
          maxWidth={2}
        >
          {node.label}
        </Text>
        {/* Completed ring */}
        {node.completed && (
          <mesh rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.45, 0.03, 8, 32]} />
            <meshStandardMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.5} />
          </mesh>
        )}
      </group>
    </Float>
  );
}

function ConnectionLine({ start, end, color }: { start: [number, number, number]; end: [number, number, number]; color: string }) {
  const ref = useRef<THREE.Line>(null);
  const points = useMemo(() => {
    const curve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(...start),
      new THREE.Vector3(
        (start[0] + end[0]) / 2,
        (start[1] + end[1]) / 2 + 0.5,
        (start[2] + end[2]) / 2
      ),
      new THREE.Vector3(...end)
    );
    return curve.getPoints(20);
  }, [start, end]);

  const geometry = useMemo(() => new THREE.BufferGeometry().setFromPoints(points), [points]);
  const material = useMemo(() => new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.3 }), [color]);

  return (
    <primitive object={new THREE.Line(geometry, material)} />
  );
}

function ParticleField() {
  const count = 100;
  const ref = useRef<THREE.Points>(null);

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 20;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 20;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 20;
    }
    return pos;
  }, []);

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * 0.02;
    }
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.03} color="#6366f1" transparent opacity={0.4} sizeAttenuation />
    </points>
  );
}

function Scene({ nodes, selectedNode, onSelectNode }: { nodes: TopicNode[]; selectedNode: string | null; onSelectNode: (id: string | null) => void }) {
  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#6366f1" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#ec4899" />
      <ParticleField />
      {nodes.map((node) =>
        node.connections.map((connId) => {
          const target = nodes.find((n) => n.id === connId);
          if (!target) return null;
          return (
            <ConnectionLine
              key={`${node.id}-${connId}`}
              start={node.position}
              end={target.position}
              color={DOMAIN_COLORS[node.domain || 'other']}
            />
          );
        })
      )}
      {nodes.map((node) => (
        <TopicSphere
          key={node.id}
          node={node}
          isSelected={selectedNode === node.id}
          onClick={() => onSelectNode(selectedNode === node.id ? null : node.id)}
        />
      ))}
      <OrbitControls enablePan enableZoom enableRotate autoRotate autoRotateSpeed={0.5} />
    </>
  );
}

export default function KnowledgeGraph3D() {
  const { user } = useAuth();
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [nodes, setNodes] = useState<TopicNode[]>([]);

  useEffect(() => {
    if (!user) return;
    const fetchTopics = async () => {
      const { data: completed } = await supabase
        .from('completed_topics')
        .select('topic, domain')
        .eq('user_id', user.id);

      const { data: quizzes } = await supabase
        .from('quiz_results')
        .select('topic')
        .eq('user_id', user.id);

      const { data: profile } = await supabase
        .from('profiles')
        .select('domain, interests')
        .eq('user_id', user.id)
        .maybeSingle();

      const allTopics = new Map<string, { domain?: string; completed: boolean }>();
      completed?.forEach((t) => allTopics.set(t.topic, { domain: t.domain || profile?.domain || undefined, completed: true }));
      quizzes?.forEach((q) => { if (!allTopics.has(q.topic)) allTopics.set(q.topic, { domain: profile?.domain || undefined, completed: false }); });
      profile?.interests?.forEach((i: string) => { if (!allTopics.has(i)) allTopics.set(i, { domain: profile?.domain || undefined, completed: false }); });

      if (allTopics.size === 0) {
        // Add sample nodes
        const samples = ['Machine Learning', 'Data Structures', 'Web Dev', 'Algorithms', 'Databases', 'Networking'];
        samples.forEach((s) => allTopics.set(s, { domain: profile?.domain || 'tech_engineering', completed: false }));
      }

      const topicArray = Array.from(allTopics.entries());
      const radius = Math.max(3, topicArray.length * 0.5);
      const generated: TopicNode[] = topicArray.map(([label, info], i) => {
        const angle = (i / topicArray.length) * Math.PI * 2;
        const layer = Math.floor(i / 6);
        return {
          id: `node-${i}`,
          label,
          domain: info.domain,
          completed: info.completed,
          position: [
            Math.cos(angle) * (radius - layer),
            (Math.random() - 0.5) * 3,
            Math.sin(angle) * (radius - layer),
          ] as [number, number, number],
          connections: topicArray
            .filter((_, j) => j !== i && Math.abs(j - i) <= 2)
            .map((_, j) => `node-${j}`),
        };
      });
      setNodes(generated);
    };
    fetchTopics();
  }, [user]);

  const selected = nodes.find((n) => n.id === selectedNode);

  return (
    <Card className="glass-morphism border-primary/20 overflow-hidden">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <Network className="w-5 h-5 text-primary" />
          3D Knowledge Graph
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0 relative">
        <div className="h-[500px] w-full">
          <Canvas camera={{ position: [0, 3, 8], fov: 60 }}>
            <Suspense fallback={null}>
              <Scene nodes={nodes} selectedNode={selectedNode} onSelectNode={setSelectedNode} />
            </Suspense>
          </Canvas>
        </div>
        {selected && (
          <div className="absolute bottom-4 left-4 right-4 glass-morphism rounded-xl p-4 animate-fade-in">
            <h3 className="font-semibold text-lg">{selected.label}</h3>
            <p className="text-sm text-muted-foreground">
              {selected.completed ? '✅ Completed' : '📖 In Progress'} • {selected.connections.length} connections
            </p>
          </div>
        )}
        <div className="absolute top-4 right-4 flex gap-2">
          <Button size="icon" variant="secondary" className="glass-morphism w-8 h-8" onClick={() => setSelectedNode(null)}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
