import { useState, useEffect, useCallback } from 'react';
import { BookOpen, RotateCcw, ThumbsUp, ThumbsDown, Zap, Brain, Clock, ChevronRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface SRSCard {
    id: string;
    front: string;
    back: string;
    easeFactor: number;   // SM-2 ease factor (≥1.3)
    interval: number;     // days until next review
    repetition: number;   // number of successful reviews
    nextReview: string;   // ISO date string
    lastReview?: string;
}

const STORAGE_KEY = 'studyai_srs_cards';

const DEMO_CARDS: Omit<SRSCard, 'id' | 'easeFactor' | 'interval' | 'repetition' | 'nextReview'>[] = [
    { front: 'What is the time complexity of binary search?', back: 'O(log n) — divides search space in half each step' },
    { front: 'Define photosynthesis', back: '6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂' },
    { front: "What is Newton's Second Law?", back: 'F = ma (Force equals mass times acceleration)' },
    { front: 'What is the Pythagorean theorem?', back: 'a² + b² = c² (for right triangles)' },
    { front: 'What does HTTP stand for?', back: 'HyperText Transfer Protocol' },
    { front: 'What is mitochondria?', back: 'The powerhouse of the cell — produces ATP via cellular respiration' },
    { front: 'Chemical formula for water?', back: 'H₂O — two hydrogen atoms bonded to one oxygen' },
    { front: 'What is GDP?', back: 'Gross Domestic Product — total value of goods & services produced in a country' },
];

const loadCards = (): SRSCard[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch { return []; }
};

const saveCards = (cards: SRSCard[]) => localStorage.setItem(STORAGE_KEY, JSON.stringify(cards));

const today = () => new Date().toISOString().split('T')[0];

// SM-2 Algorithm
const sm2 = (card: SRSCard, quality: number): SRSCard => {
    // quality: 0-5 (0-2 = fail, 3-5 = pass)
    let { easeFactor, interval, repetition } = card;

    if (quality < 3) {
        repetition = 0;
        interval = 1;
    } else {
        if (repetition === 0) interval = 1;
        else if (repetition === 1) interval = 6;
        else interval = Math.round(interval * easeFactor);
        repetition++;
    }

    easeFactor = Math.max(1.3, easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)));

    const next = new Date();
    next.setDate(next.getDate() + interval);

    return {
        ...card,
        easeFactor,
        interval,
        repetition,
        nextReview: next.toISOString().split('T')[0],
        lastReview: today(),
    };
};

const QUALITY_OPTIONS = [
    { label: 'Again', quality: 1, icon: RotateCcw, color: 'text-red-400', bg: 'bg-red-500/15 hover:bg-red-500/25 border-red-500/25' },
    { label: 'Hard', quality: 2, icon: ThumbsDown, color: 'text-orange-400', bg: 'bg-orange-500/15 hover:bg-orange-500/25 border-orange-500/25' },
    { label: 'Good', quality: 3, icon: ThumbsUp, color: 'text-emerald-400', bg: 'bg-emerald-500/15 hover:bg-emerald-500/25 border-emerald-500/25' },
    { label: 'Easy', quality: 5, icon: Zap, color: 'text-primary', bg: 'bg-primary/15 hover:bg-primary/25 border-primary/25' },
];

const SpacedRepetition = () => {
    const [cards, setCards] = useState<SRSCard[]>(loadCards);
    const [currentIdx, setCurrentIdx] = useState(0);
    const [showBack, setShowBack] = useState(false);
    const [sessionComplete, setSessionComplete] = useState(false);
    const [reviewed, setReviewed] = useState(0);

    // Seed demo cards
    useEffect(() => {
        if (cards.length === 0) {
            const seeded = DEMO_CARDS.map((c, i) => ({
                ...c,
                id: `srs-${i}-${Date.now().toString(36)}`,
                easeFactor: 2.5,
                interval: 0,
                repetition: 0,
                nextReview: today(),
            }));
            setCards(seeded);
            saveCards(seeded);
        }
    }, []);

    const dueCards = cards.filter(c => c.nextReview <= today());
    const currentCard = dueCards[currentIdx];

    useEffect(() => { saveCards(cards); }, [cards]);

    const handleRate = useCallback((quality: number) => {
        if (!currentCard) return;
        const updated = sm2(currentCard, quality);
        setCards(prev => prev.map(c => c.id === updated.id ? updated : c));
        setReviewed(r => r + 1);
        setShowBack(false);

        // Move to next card
        const remaining = dueCards.filter(c => c.id !== currentCard.id && c.nextReview <= today());
        if (remaining.length === 0 || currentIdx >= dueCards.length - 1) {
            setSessionComplete(true);
        } else {
            setCurrentIdx(prev => Math.min(prev, remaining.length - 1));
        }
    }, [currentCard, currentIdx, dueCards]);

    const resetSession = () => {
        setCurrentIdx(0);
        setShowBack(false);
        setSessionComplete(false);
        setReviewed(0);
    };

    const upcomingCount = cards.filter(c => c.nextReview > today()).length;

    return (
        <div className="glass-morphism rounded-2xl overflow-hidden">
            {/* Header */}
            <div className="px-5 py-4 border-b border-border/30">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Brain className="w-5 h-5 text-primary" />
                        <h3 className="font-bold text-lg"><span className="gradient-text">Spaced Repetition</span></h3>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="text-xs px-2.5 py-1 rounded-full bg-primary/15 text-primary font-medium">
                            {dueCards.length} due
                        </span>
                        <span className="text-xs px-2.5 py-1 rounded-full bg-muted/50 text-muted-foreground font-medium">
                            {upcomingCount} upcoming
                        </span>
                    </div>
                </div>
                {dueCards.length > 0 && !sessionComplete && (
                    <div className="mt-3">
                        <div className="flex justify-between text-xs text-muted-foreground mb-1">
                            <span>Progress</span>
                            <span>{reviewed}/{dueCards.length}</span>
                        </div>
                        <Progress value={(reviewed / Math.max(dueCards.length, 1)) * 100} className="h-1.5" />
                    </div>
                )}
            </div>

            {/* Card Area */}
            <div className="p-5">
                {sessionComplete ? (
                    <div className="text-center py-8 animate-fade-in">
                        <Sparkles className="w-12 h-12 mx-auto mb-3 text-primary animate-bounce-soft" />
                        <h4 className="text-xl font-bold mb-2">Session Complete! 🎉</h4>
                        <p className="text-muted-foreground text-sm mb-1">You reviewed {reviewed} cards</p>
                        <p className="text-xs text-muted-foreground mb-6">
                            {upcomingCount > 0 ? `${upcomingCount} cards scheduled for later` : 'All cards reviewed!'}
                        </p>
                        <Button onClick={resetSession} variant="outline" className="gap-2">
                            <RotateCcw className="w-4 h-4" /> Review Again
                        </Button>
                    </div>
                ) : dueCards.length === 0 ? (
                    <div className="text-center py-8">
                        <BookOpen className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
                        <h4 className="font-bold mb-1">All caught up!</h4>
                        <p className="text-sm text-muted-foreground">No cards due for review right now</p>
                        <div className="flex items-center justify-center gap-2 mt-3 text-xs text-muted-foreground">
                            <Clock className="w-3.5 h-3.5" />
                            <span>{cards.length} total cards in deck</span>
                        </div>
                    </div>
                ) : currentCard ? (
                    <div className="space-y-4">
                        {/* Flashcard */}
                        <div
                            className={cn(
                                'min-h-[180px] rounded-xl p-6 flex items-center justify-center text-center cursor-pointer',
                                'transition-all duration-500 relative overflow-hidden',
                                showBack
                                    ? 'bg-primary/5 border-2 border-primary/20'
                                    : 'bg-muted/20 border-2 border-border/30 hover:border-primary/20'
                            )}
                            onClick={() => setShowBack(!showBack)}
                        >
                            <div>
                                <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium mb-3 block">
                                    {showBack ? '💡 Answer' : '❓ Question'} — Card {currentIdx + 1}/{dueCards.length}
                                </span>
                                <p className={cn('text-lg font-medium', showBack && 'text-primary')}>
                                    {showBack ? currentCard.back : currentCard.front}
                                </p>
                                {!showBack && (
                                    <p className="text-xs text-muted-foreground mt-4 flex items-center justify-center gap-1">
                                        Tap to reveal <ChevronRight className="w-3 h-3" />
                                    </p>
                                )}
                            </div>
                        </div>

                        {/* Rating Buttons */}
                        {showBack && (
                            <div className="grid grid-cols-4 gap-2 animate-fade-in">
                                {QUALITY_OPTIONS.map(opt => {
                                    const Icon = opt.icon;
                                    return (
                                        <button
                                            key={opt.label}
                                            onClick={() => handleRate(opt.quality)}
                                            className={cn(
                                                'flex flex-col items-center gap-1 py-3 px-2 rounded-xl border transition-all duration-200',
                                                opt.bg
                                            )}
                                        >
                                            <Icon className={cn('w-5 h-5', opt.color)} />
                                            <span className={cn('text-xs font-medium', opt.color)}>{opt.label}</span>
                                        </button>
                                    );
                                })}
                            </div>
                        )}

                        {/* Card Stats */}
                        <div className="flex items-center justify-center gap-4 text-[10px] text-muted-foreground">
                            <span>Ease: {currentCard.easeFactor.toFixed(1)}</span>
                            <span>Interval: {currentCard.interval}d</span>
                            <span>Reviews: {currentCard.repetition}</span>
                        </div>
                    </div>
                ) : null}
            </div>
        </div>
    );
};

export default SpacedRepetition;
