import { useState, useCallback } from 'react';
import { Plus, Trash2, RotateCcw, ChevronLeft, ChevronRight, Sparkles, BookOpen, Brain } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

interface Flashcard {
    id: string;
    front: string;
    back: string;
    lastReview: number | null;
    interval: number; // days until next review
    ease: number; // SM-2 ease factor
    repetitions: number;
}

interface FlashcardDeck {
    id: string;
    name: string;
    cards: Flashcard[];
    createdAt: number;
}

// SM-2 spaced repetition algorithm
const calculateNextReview = (card: Flashcard, quality: number): Flashcard => {
    let { interval, ease, repetitions } = card;

    if (quality >= 3) {
        if (repetitions === 0) interval = 1;
        else if (repetitions === 1) interval = 6;
        else interval = Math.round(interval * ease);
        repetitions += 1;
    } else {
        repetitions = 0;
        interval = 1;
    }

    ease = Math.max(1.3, ease + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)));

    return {
        ...card,
        interval,
        ease,
        repetitions,
        lastReview: Date.now(),
    };
};

const generateId = () => Math.random().toString(36).substring(2, 15);

const STORAGE_KEY = 'studyai_flashcard_decks';

const loadDecks = (): FlashcardDeck[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch {
        return [];
    }
};

const saveDecks = (decks: FlashcardDeck[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(decks));
};

type View = 'decks' | 'study' | 'create';

export default function FlashcardSystem() {
    const [decks, setDecks] = useState<FlashcardDeck[]>(loadDecks);
    const [view, setView] = useState<View>('decks');
    const [activeDeck, setActiveDeck] = useState<FlashcardDeck | null>(null);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isFlipped, setIsFlipped] = useState(false);
    const [newDeckName, setNewDeckName] = useState('');
    const [newFront, setNewFront] = useState('');
    const [newBack, setNewBack] = useState('');
    const [editingDeck, setEditingDeck] = useState<FlashcardDeck | null>(null);
    const [sessionComplete, setSessionComplete] = useState(false);

    const persistDecks = useCallback((updated: FlashcardDeck[]) => {
        setDecks(updated);
        saveDecks(updated);
    }, []);

    // Create deck
    const handleCreateDeck = () => {
        if (!newDeckName.trim()) {
            toast.error('Please enter a deck name');
            return;
        }
        const deck: FlashcardDeck = { id: generateId(), name: newDeckName.trim(), cards: [], createdAt: Date.now() };
        persistDecks([...decks, deck]);
        setEditingDeck(deck);
        setNewDeckName('');
        toast.success(`Deck "${deck.name}" created!`);
    };

    // Add card to deck
    const handleAddCard = () => {
        if (!newFront.trim() || !newBack.trim() || !editingDeck) {
            toast.error('Both sides of the card are required');
            return;
        }
        const card: Flashcard = {
            id: generateId(),
            front: newFront.trim(),
            back: newBack.trim(),
            lastReview: null,
            interval: 0,
            ease: 2.5,
            repetitions: 0,
        };
        const updated = decks.map(d => d.id === editingDeck.id ? { ...d, cards: [...d.cards, card] } : d);
        const updatedDeck = updated.find(d => d.id === editingDeck.id)!;
        setEditingDeck(updatedDeck);
        persistDecks(updated);
        setNewFront('');
        setNewBack('');
        toast.success('Card added!');
    };

    // Delete card
    const handleDeleteCard = (cardId: string) => {
        if (!editingDeck) return;
        const updated = decks.map(d =>
            d.id === editingDeck.id ? { ...d, cards: d.cards.filter(c => c.id !== cardId) } : d
        );
        const updatedDeck = updated.find(d => d.id === editingDeck.id)!;
        setEditingDeck(updatedDeck);
        persistDecks(updated);
    };

    // Delete deck
    const handleDeleteDeck = (deckId: string) => {
        if (!confirm('Delete this deck? This cannot be undone.')) return;
        persistDecks(decks.filter(d => d.id !== deckId));
        if (editingDeck?.id === deckId) setEditingDeck(null);
        toast.success('Deck deleted');
    };

    // Start study session
    const startStudy = (deck: FlashcardDeck) => {
        if (deck.cards.length === 0) {
            toast.error('This deck has no cards. Add some first!');
            return;
        }
        setActiveDeck(deck);
        setCurrentIndex(0);
        setIsFlipped(false);
        setSessionComplete(false);
        setView('study');
    };

    // Rate card difficulty (SM-2 quality: 1=Again, 3=Good, 5=Easy)
    const rateCard = (quality: number) => {
        if (!activeDeck) return;
        const card = activeDeck.cards[currentIndex];
        const updatedCard = calculateNextReview(card, quality);
        const updatedDeck = {
            ...activeDeck,
            cards: activeDeck.cards.map(c => c.id === card.id ? updatedCard : c),
        };
        const updated = decks.map(d => d.id === updatedDeck.id ? updatedDeck : d);
        setActiveDeck(updatedDeck);
        persistDecks(updated);

        // Move to next card
        if (currentIndex < activeDeck.cards.length - 1) {
            setCurrentIndex(currentIndex + 1);
            setIsFlipped(false);
        } else {
            setSessionComplete(true);
        }
    };

    const getDueCards = (deck: FlashcardDeck) => {
        const now = Date.now();
        return deck.cards.filter(c => {
            if (!c.lastReview) return true;
            const nextReview = c.lastReview + c.interval * 86400000;
            return now >= nextReview;
        }).length;
    };

    // ─── Decks View ────────────────────
    if (view === 'decks') {
        return (
            <div className="space-y-8">
                {/* Create new deck */}
                <div className="bento-card noise-overlay">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/60 to-secondary/60" />
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center">
                            <Plus className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                            <h3 className="font-bold text-lg">Create New Deck</h3>
                            <p className="text-sm text-muted-foreground">Organize your flashcards by topic</p>
                        </div>
                    </div>
                    <div className="flex gap-3">
                        <Input
                            placeholder="e.g. Biology Chapter 5, JavaScript Basics..."
                            value={newDeckName}
                            onChange={e => setNewDeckName(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && handleCreateDeck()}
                            className="flex-1"
                        />
                        <Button
                            onClick={handleCreateDeck}
                            className="text-white shrink-0"
                            style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
                        >
                            <Plus className="w-4 h-4 mr-1" /> Create
                        </Button>
                    </div>
                </div>

                {/* Deck list */}
                {decks.length === 0 ? (
                    <div className="bento-card text-center py-16">
                        <BookOpen className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                        <h3 className="text-xl font-bold mb-2">No decks yet</h3>
                        <p className="text-muted-foreground text-sm">Create your first flashcard deck above to start studying!</p>
                    </div>
                ) : (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {decks.map(deck => {
                            const dueCount = getDueCards(deck);
                            return (
                                <div key={deck.id} className="bento-card group">
                                    <div className="flex items-start justify-between mb-3">
                                        <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center">
                                            <Brain className="w-4 h-4 text-primary" />
                                        </div>
                                        <button
                                            onClick={() => handleDeleteDeck(deck.id)}
                                            className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                    <h3 className="font-bold text-lg mb-1 truncate">{deck.name}</h3>
                                    <p className="text-sm text-muted-foreground mb-4">
                                        {deck.cards.length} card{deck.cards.length !== 1 ? 's' : ''}
                                        {dueCount > 0 && (
                                            <span className="ml-2 text-amber-400 font-medium">• {dueCount} due</span>
                                        )}
                                    </p>
                                    <div className="flex gap-2">
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            className="flex-1 text-xs"
                                            onClick={() => {
                                                setEditingDeck(deck);
                                                setView('create');
                                            }}
                                        >
                                            Edit Cards
                                        </Button>
                                        <Button
                                            size="sm"
                                            className="flex-1 text-xs text-white"
                                            style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
                                            onClick={() => startStudy(deck)}
                                        >
                                            Study Now
                                        </Button>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        );
    }

    // ─── Create / Edit Cards View ──────
    if (view === 'create' && editingDeck) {
        return (
            <div className="space-y-6">
                <div className="flex items-center gap-3">
                    <Button variant="ghost" size="icon" onClick={() => { setView('decks'); setEditingDeck(null); }}>
                        <ChevronLeft className="w-5 h-5" />
                    </Button>
                    <div>
                        <h2 className="text-xl font-bold">{editingDeck.name}</h2>
                        <p className="text-sm text-muted-foreground">{editingDeck.cards.length} cards</p>
                    </div>
                </div>

                {/* Add card form */}
                <div className="bento-card noise-overlay">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-secondary/60 to-accent/60" />
                    <h3 className="font-bold mb-4 flex items-center gap-2">
                        <Plus className="w-4 h-4 text-primary" /> Add New Card
                    </h3>
                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-2 block">Front (Question)</label>
                            <Input
                                placeholder="What is photosynthesis?"
                                value={newFront}
                                onChange={e => setNewFront(e.target.value)}
                            />
                        </div>
                        <div>
                            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-2 block">Back (Answer)</label>
                            <Input
                                placeholder="The process by which plants convert..."
                                value={newBack}
                                onChange={e => setNewBack(e.target.value)}
                                onKeyDown={e => e.key === 'Enter' && handleAddCard()}
                            />
                        </div>
                    </div>
                    <Button
                        onClick={handleAddCard}
                        className="text-white"
                        style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
                    >
                        <Plus className="w-4 h-4 mr-1" /> Add Card
                    </Button>
                </div>

                {/* Card list */}
                {editingDeck.cards.length === 0 ? (
                    <div className="bento-card text-center py-12">
                        <p className="text-muted-foreground">No cards yet. Add your first card above!</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {editingDeck.cards.map((card, idx) => (
                            <div key={card.id} className="bento-card flex items-center gap-4 group">
                                <span className="text-sm font-bold text-muted-foreground w-6 text-center">{idx + 1}</span>
                                <div className="flex-1 min-w-0">
                                    <p className="font-medium text-sm truncate">{card.front}</p>
                                    <p className="text-xs text-muted-foreground truncate">{card.back}</p>
                                </div>
                                <button
                                    onClick={() => handleDeleteCard(card.id)}
                                    className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive shrink-0"
                                >
                                    <Trash2 className="w-4 h-4" />
                                </button>
                            </div>
                        ))}
                    </div>
                )}

                <div className="flex gap-3">
                    <Button variant="outline" onClick={() => { setView('decks'); setEditingDeck(null); }}>
                        ← Back to Decks
                    </Button>
                    <Button
                        className="text-white"
                        style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
                        onClick={() => startStudy(editingDeck)}
                        disabled={editingDeck.cards.length === 0}
                    >
                        <Sparkles className="w-4 h-4 mr-1" /> Start Studying
                    </Button>
                </div>
            </div>
        );
    }

    // ─── Study View ────────────────────
    if (view === 'study' && activeDeck) {
        if (sessionComplete) {
            return (
                <div className="flex items-center justify-center min-h-[60vh]">
                    <div className="bento-card text-center max-w-md w-full noise-overlay">
                        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-primary via-secondary to-accent" />
                        <div className="w-16 h-16 rounded-2xl bg-primary/15 flex items-center justify-center mx-auto mb-4">
                            <Sparkles className="w-8 h-8 text-primary" />
                        </div>
                        <h2 className="text-2xl font-bold mb-2">Session Complete! 🎉</h2>
                        <p className="text-muted-foreground text-sm mb-6">
                            You reviewed all {activeDeck.cards.length} cards in "{activeDeck.name}".
                        </p>
                        <div className="flex gap-3 justify-center">
                            <Button variant="outline" onClick={() => setView('decks')}>
                                ← Back to Decks
                            </Button>
                            <Button
                                className="text-white"
                                style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }}
                                onClick={() => {
                                    setCurrentIndex(0);
                                    setIsFlipped(false);
                                    setSessionComplete(false);
                                }}
                            >
                                <RotateCcw className="w-4 h-4 mr-1" /> Study Again
                            </Button>
                        </div>
                    </div>
                </div>
            );
        }

        const card = activeDeck.cards[currentIndex];
        const progress = ((currentIndex + 1) / activeDeck.cards.length) * 100;

        return (
            <div className="max-w-2xl mx-auto space-y-6">
                {/* Header */}
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <Button variant="ghost" size="icon" onClick={() => setView('decks')}>
                            <ChevronLeft className="w-5 h-5" />
                        </Button>
                        <div>
                            <h2 className="font-bold">{activeDeck.name}</h2>
                            <p className="text-xs text-muted-foreground">{currentIndex + 1} / {activeDeck.cards.length}</p>
                        </div>
                    </div>
                    <div className="text-sm text-muted-foreground font-medium">{Math.round(progress)}%</div>
                </div>

                {/* Progress bar */}
                <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                            width: `${progress}%`,
                            background: 'linear-gradient(90deg, hsl(var(--primary)), hsl(var(--secondary)))',
                        }}
                    />
                </div>

                {/* Flashcard with flip animation */}
                <div
                    className="relative cursor-pointer select-none"
                    style={{ perspective: '1200px' }}
                    onClick={() => setIsFlipped(!isFlipped)}
                >
                    <div
                        className="transition-all duration-500 relative"
                        style={{
                            transformStyle: 'preserve-3d',
                            transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
                        }}
                    >
                        {/* Front */}
                        <div
                            className="bento-card min-h-[280px] flex flex-col items-center justify-center text-center noise-overlay"
                            style={{ backfaceVisibility: 'hidden' }}
                        >
                            <div className="absolute top-4 left-4">
                                <span className="text-[10px] font-semibold bg-primary/15 text-primary border border-primary/25 px-2 py-0.5 rounded-full">
                                    Question
                                </span>
                            </div>
                            <p className="text-xl md:text-2xl font-bold px-8 leading-relaxed">{card.front}</p>
                            <p className="text-xs text-muted-foreground mt-6">Tap to reveal answer</p>
                        </div>

                        {/* Back */}
                        <div
                            className="bento-card min-h-[280px] flex flex-col items-center justify-center text-center absolute inset-0 noise-overlay"
                            style={{
                                backfaceVisibility: 'hidden',
                                transform: 'rotateY(180deg)',
                                background: 'linear-gradient(160deg, hsl(var(--card)) 0%, hsl(var(--primary) / 0.05) 100%)',
                            }}
                        >
                            <div className="absolute top-4 left-4">
                                <span className="text-[10px] font-semibold bg-secondary/15 text-secondary border border-secondary/25 px-2 py-0.5 rounded-full">
                                    Answer
                                </span>
                            </div>
                            <p className="text-lg md:text-xl font-medium px-8 leading-relaxed text-foreground/90">{card.back}</p>
                        </div>
                    </div>
                </div>

                {/* Difficulty rating buttons */}
                {isFlipped && (
                    <div className="flex gap-3 justify-center animate-fade-in">
                        <p className="text-xs text-muted-foreground self-center mr-2">How well did you know it?</p>
                        <Button
                            variant="outline"
                            size="sm"
                            className="border-rose-500/30 text-rose-400 hover:bg-rose-500/10 hover:text-rose-400"
                            onClick={() => rateCard(1)}
                        >
                            Again
                        </Button>
                        <Button
                            variant="outline"
                            size="sm"
                            className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10 hover:text-amber-400"
                            onClick={() => rateCard(3)}
                        >
                            Good
                        </Button>
                        <Button
                            variant="outline"
                            size="sm"
                            className="border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10 hover:text-emerald-400"
                            onClick={() => rateCard(5)}
                        >
                            Easy
                        </Button>
                    </div>
                )}

                {/* Navigation */}
                <div className="flex justify-between">
                    <Button
                        variant="ghost"
                        size="sm"
                        disabled={currentIndex === 0}
                        onClick={() => { setCurrentIndex(currentIndex - 1); setIsFlipped(false); }}
                    >
                        <ChevronLeft className="w-4 h-4 mr-1" /> Previous
                    </Button>
                    <Button
                        variant="ghost"
                        size="sm"
                        disabled={currentIndex === activeDeck.cards.length - 1}
                        onClick={() => { setCurrentIndex(currentIndex + 1); setIsFlipped(false); }}
                    >
                        Next <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                </div>
            </div>
        );
    }

    return null;
}
