import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Users, Send, Plus, LogOut, Trophy, MessageCircle, 
  Circle, Loader2, DoorOpen 
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

interface Room {
  id: string;
  name: string;
  description: string | null;
  domain: string | null;
  created_by: string;
  is_active: boolean;
}

interface Participant {
  id: string;
  user_id: string;
  display_name: string;
  is_online: boolean;
  study_minutes: number;
}

interface RoomMessage {
  id: string;
  user_id: string;
  display_name: string;
  content: string;
  is_ai_response: boolean;
  created_at: string;
}

export default function StudyRoom() {
  const { user } = useAuth();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [currentRoom, setCurrentRoom] = useState<Room | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [messages, setMessages] = useState<RoomMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [newRoomName, setNewRoomName] = useState('');
  const [newRoomDesc, setNewRoomDesc] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [loading, setLoading] = useState(false);
  const [displayName, setDisplayName] = useState('Student');
  const scrollRef = useRef<HTMLDivElement>(null);

  // Fetch user profile for display name
  useEffect(() => {
    if (!user) return;
    supabase.from('profiles').select('full_name').eq('user_id', user.id).maybeSingle()
      .then(({ data }) => { if (data?.full_name) setDisplayName(data.full_name); });
  }, [user]);

  // Fetch rooms
  useEffect(() => {
    const fetchRooms = async () => {
      const { data } = await supabase.from('study_rooms').select('*').eq('is_active', true).order('created_at', { ascending: false });
      if (data) setRooms(data);
    };
    fetchRooms();
  }, []);

  // Real-time participants & messages
  useEffect(() => {
    if (!currentRoom) return;

    const fetchData = async () => {
      const [{ data: parts }, { data: msgs }] = await Promise.all([
        supabase.from('study_room_participants').select('*').eq('room_id', currentRoom.id),
        supabase.from('study_room_messages').select('*').eq('room_id', currentRoom.id).order('created_at', { ascending: true }).limit(100),
      ]);
      if (parts) setParticipants(parts);
      if (msgs) setMessages(msgs);
    };
    fetchData();

    const channel = supabase.channel(`room-${currentRoom.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'study_room_participants', filter: `room_id=eq.${currentRoom.id}` }, (payload) => {
        if (payload.eventType === 'INSERT') setParticipants(prev => [...prev, payload.new as Participant]);
        if (payload.eventType === 'UPDATE') setParticipants(prev => prev.map(p => p.id === (payload.new as Participant).id ? payload.new as Participant : p));
        if (payload.eventType === 'DELETE') setParticipants(prev => prev.filter(p => p.id !== (payload.old as any).id));
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'study_room_messages', filter: `room_id=eq.${currentRoom.id}` }, (payload) => {
        setMessages(prev => [...prev, payload.new as RoomMessage]);
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [currentRoom]);

  // Auto-scroll messages
  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const createRoom = async () => {
    if (!user || !newRoomName.trim()) return;
    setLoading(true);
    const { data: profile } = await supabase.from('profiles').select('domain').eq('user_id', user.id).maybeSingle();
    const { data, error } = await supabase.from('study_rooms').insert({
      name: newRoomName.trim(),
      description: newRoomDesc.trim() || null,
      domain: profile?.domain || null,
      created_by: user.id,
    }).select().single();
    if (data) {
      setRooms(prev => [data, ...prev]);
      setNewRoomName('');
      setNewRoomDesc('');
      setIsCreating(false);
      joinRoom(data);
    }
    if (error) toast.error('Failed to create room');
    setLoading(false);
  };

  const joinRoom = async (room: Room) => {
    if (!user) return;
    setCurrentRoom(room);
    const { error } = await supabase.from('study_room_participants').upsert({
      room_id: room.id,
      user_id: user.id,
      display_name: displayName,
      is_online: true,
    }, { onConflict: 'room_id,user_id' });
    if (error) console.error('Join error:', error);
  };

  const leaveRoom = async () => {
    if (!user || !currentRoom) return;
    await supabase.from('study_room_participants').delete().eq('room_id', currentRoom.id).eq('user_id', user.id);
    setCurrentRoom(null);
    setMessages([]);
    setParticipants([]);
  };

  const sendMessage = async () => {
    if (!user || !currentRoom || !newMessage.trim()) return;
    await supabase.from('study_room_messages').insert({
      room_id: currentRoom.id,
      user_id: user.id,
      display_name: displayName,
      content: newMessage.trim(),
    });
    setNewMessage('');
  };

  // Room List View
  if (!currentRoom) {
    return (
      <Card className="glass-morphism border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Study Rooms
            </div>
            <Button size="sm" onClick={() => setIsCreating(!isCreating)} className="gap-1">
              <Plus className="w-4 h-4" /> Create Room
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isCreating && (
            <div className="glass-morphism rounded-xl p-4 space-y-3 animate-fade-in">
              <Input placeholder="Room name..." value={newRoomName} onChange={e => setNewRoomName(e.target.value)} />
              <Input placeholder="Description (optional)" value={newRoomDesc} onChange={e => setNewRoomDesc(e.target.value)} />
              <div className="flex gap-2">
                <Button onClick={createRoom} disabled={loading || !newRoomName.trim()} className="flex-1">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create'}
                </Button>
                <Button variant="outline" onClick={() => setIsCreating(false)}>Cancel</Button>
              </div>
            </div>
          )}
          {rooms.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No active study rooms yet.</p>
              <p className="text-sm">Create one to start studying with others!</p>
            </div>
          ) : (
            rooms.map(room => (
              <div key={room.id} className="glass-morphism rounded-xl p-4 hover-lift cursor-pointer transition-all" onClick={() => joinRoom(room)}>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold">{room.name}</h3>
                    {room.description && <p className="text-sm text-muted-foreground">{room.description}</p>}
                  </div>
                  <Button size="sm" variant="outline" className="gap-1">
                    <DoorOpen className="w-4 h-4" /> Join
                  </Button>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    );
  }

  // Room Chat View
  return (
    <Card className="glass-morphism border-primary/20 flex flex-col h-[600px]">
      <CardHeader className="pb-2 border-b border-border/50">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">{currentRoom.name}</CardTitle>
            <p className="text-sm text-muted-foreground">{participants.filter(p => p.is_online).length} online</p>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="destructive" onClick={leaveRoom} className="gap-1">
              <LogOut className="w-4 h-4" /> Leave
            </Button>
          </div>
        </div>
        {/* Participants bar */}
        <div className="flex gap-2 mt-2 flex-wrap">
          {participants.map(p => (
            <Badge key={p.id} variant={p.is_online ? 'default' : 'secondary'} className="gap-1 text-xs">
              <Circle className={`w-2 h-2 ${p.is_online ? 'fill-green-400 text-green-400' : 'fill-muted text-muted'}`} />
              {p.display_name}
              {p.study_minutes > 0 && <span className="ml-1 opacity-70">{p.study_minutes}m</span>}
            </Badge>
          ))}
        </div>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-3">
            {messages.map(msg => (
              <div key={msg.id} className={`flex ${msg.user_id === user?.id ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-xl px-3 py-2 ${
                  msg.is_ai_response ? 'bg-primary/20 border border-primary/30' :
                  msg.user_id === user?.id ? 'bg-primary text-primary-foreground' : 'glass-morphism'
                }`}>
                  {msg.user_id !== user?.id && (
                    <p className="text-xs font-medium mb-1 opacity-70">{msg.display_name}</p>
                  )}
                  <p className="text-sm">{msg.content}</p>
                </div>
              </div>
            ))}
            <div ref={scrollRef} />
          </div>
        </ScrollArea>
        <div className="p-3 border-t border-border/50 flex gap-2">
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={e => setNewMessage(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendMessage()}
          />
          <Button size="icon" onClick={sendMessage} disabled={!newMessage.trim()}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
