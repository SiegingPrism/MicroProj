import { useState } from "react";
import { Bot, User, ImagePlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { GeneratedVisual } from "./GeneratedVisual";
import { toast } from "sonner";

interface VisualData {
  imageUrl?: string;
  topic: string;
  description?: string;
  isLoading?: boolean;
  error?: string;
}

interface ChatMessageProps {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  domain?: string | null;
}

export const ChatMessage = ({ id, role, content, timestamp, domain }: ChatMessageProps) => {
  const [visual, setVisual] = useState<VisualData | null>(null);
  const [isGeneratingVisual, setIsGeneratingVisual] = useState(false);
  const [isRegenerating, setIsRegenerating] = useState(false);

  // Extract a meaningful topic from the message content for visualization
  const extractTopic = (): string => {
    // Skip common conversational phrases and find actual educational content
    const skipPhrases = [
      /^that'?s (an? )?(interesting|great|good|excellent)/i,
      /^hello/i,
      /^hi there/i,
      /^let me explain/i,
      /^i'?d be happy to/i,
      /^certainly/i,
      /^of course/i,
      /^sure/i,
    ];
    
    // Split into sentences and find the first meaningful one
    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 10);
    
    for (const sentence of sentences) {
      const trimmed = sentence.trim();
      const isSkippable = skipPhrases.some(pattern => pattern.test(trimmed));
      if (!isSkippable && trimmed.length > 20) {
        // Look for sentences with educational keywords
        const hasEducationalContent = /\b(is|are|was|were|means|refers|involves|consists|includes|defines|explains|shows|demonstrates|process|concept|structure|function|mechanism|system)\b/i.test(trimmed);
        if (hasEducationalContent) {
          return trimmed.length > 150 ? trimmed.substring(0, 150) : trimmed;
        }
      }
    }
    
    // Fallback: find any sentence with substance (skip first 2 which are often greetings)
    for (let i = Math.min(2, sentences.length - 1); i < sentences.length; i++) {
      const sentence = sentences[i]?.trim();
      if (sentence && sentence.length > 30) {
        return sentence.length > 150 ? sentence.substring(0, 150) : sentence;
      }
    }
    
    // Last resort: use a generic description based on domain
    return domain ? `Educational diagram about ${domain.replace(/_/g, ' ')}` : "Educational concept illustration";
  };

  const generateVisual = async (style: "detailed" | "simplified" | "diagram" | "concept" = "detailed") => {
    const isRegen = visual?.imageUrl !== undefined;
    if (isRegen) {
      setIsRegenerating(true);
    } else {
      setIsGeneratingVisual(true);
      setVisual({ topic: extractTopic(), isLoading: true });
    }

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-visual`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({
            topic: extractTopic(),
            context: content,
            style,
            domain,
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to generate visual");
      }

      const data = await response.json();
      setVisual({
        imageUrl: data.imageUrl,
        topic: data.topic,
        description: data.description,
      });
    } catch (error) {
      console.error("Error generating visual:", error);
      const errorMessage = error instanceof Error ? error.message : "Failed to generate visual";
      
      if (!isRegen) {
        setVisual({
          topic: extractTopic(),
          error: errorMessage,
        });
      } else {
        toast.error(errorMessage);
      }
    } finally {
      setIsGeneratingVisual(false);
      setIsRegenerating(false);
    }
  };

  const handleRegenerate = (style: "detailed" | "simplified" | "diagram" | "concept") => {
    generateVisual(style);
  };

  return (
    <div
      className={`flex gap-3 animate-fade-in ${
        role === "user" ? "flex-row-reverse" : ""
      }`}
    >
      <div
        className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
          role === "user"
            ? "bg-secondary/20"
            : "bg-primary/20"
        }`}
      >
        {role === "user" ? (
          <User className="w-4 h-4 text-secondary" />
        ) : (
          <Bot className="w-4 h-4 text-primary" />
        )}
      </div>
      <div
        className={`flex-1 max-w-[80%] ${
          role === "user" ? "text-right" : ""
        }`}
      >
        <div
          className={`inline-block p-4 rounded-2xl ${
            role === "user"
              ? "bg-secondary/20 text-foreground"
              : "bg-muted/50 text-foreground"
          }`}
        >
          <p className="text-sm whitespace-pre-wrap leading-relaxed text-left">
            {content}
          </p>
        </div>
        
        {/* Generate Visual button for assistant messages */}
        {role === "assistant" && !visual && content.length > 50 && (
          <div className="mt-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-muted-foreground hover:text-foreground"
              onClick={() => generateVisual()}
              disabled={isGeneratingVisual}
            >
              <ImagePlus className="w-3 h-3 mr-1" />
              Generate Visual
            </Button>
          </div>
        )}

        {/* Generated Visual */}
        {visual && (
          <div className="mt-3 text-left">
            <GeneratedVisual
              imageUrl={visual.imageUrl}
              topic={visual.topic}
              description={visual.description}
              isLoading={visual.isLoading}
              error={visual.error}
              onRegenerate={handleRegenerate}
              isRegenerating={isRegenerating}
            />
          </div>
        )}

        <p className="text-xs text-muted-foreground mt-1">
          {timestamp.toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </p>
      </div>
    </div>
  );
};
