import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  RefreshCw, Minimize2, Maximize2, Download, ZoomIn, Sparkles, AlertCircle
} from "lucide-react";
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Dialog, DialogContent, DialogTrigger,
} from "@/components/ui/dialog";
import { ARConceptViewer } from "@/components/visuals/ARConceptViewer";

interface GeneratedVisualProps {
  imageUrl?: string;
  topic: string;
  description?: string;
  isLoading?: boolean;
  error?: string;
  onRegenerate?: (style: "detailed" | "simplified" | "diagram" | "concept") => void;
  isRegenerating?: boolean;
}

export const GeneratedVisual = ({
  imageUrl, topic, description, isLoading = false, error, onRegenerate, isRegenerating = false,
}: GeneratedVisualProps) => {
  const [currentStyle, setCurrentStyle] = useState<"detailed" | "simplified" | "diagram" | "concept">("detailed");
  const [showARViewer, setShowARViewer] = useState(false);

  const handleStyleChange = (style: "detailed" | "simplified" | "diagram" | "concept") => {
    setCurrentStyle(style);
    onRegenerate?.(style);
  };

  const handleDownload = () => {
    if (!imageUrl) return;
    const link = document.createElement("a");
    link.href = imageUrl;
    link.download = `${topic.replace(/\s+/g, "-").toLowerCase()}-visual.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (isLoading) {
    return (
      <Card className="p-4 bg-muted/30 border-border/50 space-y-3">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Sparkles className="w-4 h-4 animate-pulse text-primary" />
          <span>Generating visual for "{topic}"...</span>
        </div>
        <Skeleton className="w-full h-48 rounded-lg" />
        <div className="flex gap-2">
          <Skeleton className="h-8 w-20" />
          <Skeleton className="h-8 w-20" />
          <Skeleton className="h-8 w-20" />
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-4 bg-destructive/10 border-destructive/30">
        <div className="flex items-center gap-2 text-sm text-destructive">
          <AlertCircle className="w-4 h-4" />
          <span>{error}</span>
        </div>
        {onRegenerate && (
          <Button variant="outline" size="sm" className="mt-3" onClick={() => handleStyleChange("detailed")}>
            <RefreshCw className="w-3 h-3 mr-1" /> Try Again
          </Button>
        )}
      </Card>
    );
  }

  if (!imageUrl) return null;

  if (showARViewer) {
    return (
      <div className="space-y-2">
        <ARConceptViewer imageUrl={imageUrl} topic={topic} description={description} />
        <Button variant="outline" size="sm" className="text-xs" onClick={() => setShowARViewer(false)}>
          Switch to Standard View
        </Button>
      </div>
    );
  }

  return (
    <Card className="p-4 bg-muted/30 border-border/50 space-y-3 overflow-hidden">
      <Dialog>
        <DialogTrigger asChild>
          <div className="relative group cursor-zoom-in">
            <img src={imageUrl} alt={`Visual: ${topic}`} className="w-full rounded-lg object-contain max-h-80 bg-background/50" />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors rounded-lg flex items-center justify-center">
              <ZoomIn className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            {isRegenerating && (
              <div className="absolute inset-0 bg-background/80 rounded-lg flex items-center justify-center">
                <div className="flex items-center gap-2 text-sm">
                  <RefreshCw className="w-4 h-4 animate-spin text-primary" />
                  <span>Regenerating...</span>
                </div>
              </div>
            )}
          </div>
        </DialogTrigger>
        <DialogContent className="max-w-4xl max-h-[90vh] p-2">
          <img src={imageUrl} alt={`Visual: ${topic}`} className="w-full h-full object-contain" />
        </DialogContent>
      </Dialog>

      {description && <p className="text-xs text-muted-foreground">{description}</p>}

      <div className="flex flex-wrap gap-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant={currentStyle === "detailed" ? "default" : "outline"} size="sm" onClick={() => handleStyleChange("detailed")} disabled={isRegenerating} className="text-xs">
                <Maximize2 className="w-3 h-3 mr-1" /> Detailed
              </Button>
            </TooltipTrigger>
            <TooltipContent>Rich, detailed illustration</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant={currentStyle === "simplified" ? "default" : "outline"} size="sm" onClick={() => handleStyleChange("simplified")} disabled={isRegenerating} className="text-xs">
                <Minimize2 className="w-3 h-3 mr-1" /> Simplified
              </Button>
            </TooltipTrigger>
            <TooltipContent>Simple, minimalist version</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant={currentStyle === "diagram" ? "default" : "outline"} size="sm" onClick={() => handleStyleChange("diagram")} disabled={isRegenerating} className="text-xs">
                <Sparkles className="w-3 h-3 mr-1" /> Diagram
              </Button>
            </TooltipTrigger>
            <TooltipContent>Technical diagram or flowchart</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="sm" onClick={() => setShowARViewer(true)} disabled={isRegenerating} className="text-xs">
                <Sparkles className="w-3 h-3 mr-1" /> AR View
              </Button>
            </TooltipTrigger>
            <TooltipContent>Interactive 3D-like AR viewer</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="sm" onClick={handleDownload} disabled={isRegenerating} className="text-xs ml-auto">
                <Download className="w-3 h-3" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Download image</TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </Card>
  );
};
