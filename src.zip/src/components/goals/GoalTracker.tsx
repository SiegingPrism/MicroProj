import { useState, useEffect } from 'react';
import { Target, Plus, X, TrendingUp, Clock, BookOpen, Brain, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface Goal {
    id: string;
    title: string;
    target: number;
    current: number;
    unit: string;
    period: 'weekly' | 'monthly';
    icon: string;
    color: string;
    createdAt: string;
}

const STORAGE_KEY = 'studyai_goals';

const PRESET_GOALS: Omit<Goal, 'id' | 'current' | 'createdAt'>[] = [
    { title: 'Study Hours', target: 10, unit: 'hours', period: 'weekly', icon: 'clock', color: 'hsl(200, 80%, 50%)' },
    { title: 'Topics Done', target: 5, unit: 'topics', period: 'weekly', icon: 'book', color: 'hsl(160, 70%, 45%)' },
    { title: 'Quizzes Taken', target: 10, unit: 'quizzes', period: 'monthly', icon: 'brain', color: 'hsl(270, 70%, 55%)' },
    { title: 'Flashcards', target: 50, unit: 'cards', period: 'weekly', icon: 'book', color: 'hsl(340, 65%, 50%)' },
    { title: 'Focus Sessions', target: 15, unit: 'sessions', period: 'monthly', icon: 'target', color: 'hsl(45, 80%, 50%)' },
];

const ICON_MAP: Record<string, React.ElementType> = {
    clock: Clock, book: BookOpen, brain: Brain, target: Target,
};

const loadGoals = (): Goal[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch { return []; }
};

const saveGoals = (goals: Goal[]) => localStorage.setItem(STORAGE_KEY, JSON.stringify(goals));

const CircularProgress = ({ percent, size = 72, strokeWidth = 5, color, children }: {
    percent: number; size?: number; strokeWidth?: number; color: string; children?: React.ReactNode;
}) => {
    const r = (size - strokeWidth) / 2;
    const c = r * 2 * Math.PI;
    const offset = c - (Math.min(percent, 100) / 100) * c;
    return (
        <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
            <svg width={size} height={size} className="-rotate-90">
                <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeWidth={strokeWidth} className="text-muted/30" />
                <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={strokeWidth}
                    strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round" className="transition-all duration-1000 ease-out" />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">{children}</div>
        </div>
    );
};

const GoalTracker = () => {
    const [goals, setGoals] = useState<Goal[]>(loadGoals);
    const [showAdd, setShowAdd] = useState(false);
    const [selPreset, setSelPreset] = useState<number | null>(null);
    const [customTarget, setCustomTarget] = useState('');

    useEffect(() => { saveGoals(goals); }, [goals]);

    useEffect(() => {
        if (goals.length === 0) {
            const defaults = PRESET_GOALS.slice(0, 3).map(p => ({
                ...p, id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
                current: Math.floor(Math.random() * p.target * 0.7), createdAt: new Date().toISOString(),
            }));
            setGoals(defaults);
        }
    }, []);

    const addGoal = () => {
        if (selPreset === null) return;
        const p = PRESET_GOALS[selPreset];
        setGoals(prev => [...prev, {
            ...p, id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
            target: customTarget ? parseInt(customTarget) || p.target : p.target,
            current: 0, createdAt: new Date().toISOString(),
        }]);
        setShowAdd(false); setSelPreset(null); setCustomTarget('');
    };

    const completedGoals = goals.filter(g => g.current >= g.target).length;
    const overallPercent = goals.length > 0
        ? Math.round(goals.reduce((s, g) => s + Math.min(g.current / g.target, 1), 0) / goals.length * 100) : 0;

    return (
        <div className="bento-card noise-overlay">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/60 via-secondary/60 to-accent/60" />
            <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center">
                        <Target className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                        <h3 className="font-bold text-lg">Goals</h3>
                        <p className="text-xs text-muted-foreground">{completedGoals}/{goals.length} achieved</p>
                    </div>
                </div>
                <Button variant="ghost" size="sm" className="gap-1 text-xs hover:bg-primary/10 hover:text-primary"
                    onClick={() => setShowAdd(!showAdd)}>
                    {showAdd ? <X className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                    {showAdd ? 'Cancel' : 'Add'}
                </Button>
            </div>

            {showAdd && (
                <div className="mb-5 p-4 rounded-xl bg-muted/20 border border-border/30 animate-fade-in">
                    <p className="text-sm font-medium mb-3">Choose a goal:</p>
                    <div className="grid grid-cols-2 gap-2 mb-3">
                        {PRESET_GOALS.map((preset, i) => {
                            const Icon = ICON_MAP[preset.icon] || Target;
                            return (
                                <button key={i} onClick={() => setSelPreset(i)}
                                    className={cn('flex items-center gap-2 p-2.5 rounded-lg text-left text-xs transition-all',
                                        selPreset === i ? 'bg-primary/20 ring-1 ring-primary/40' : 'bg-muted/30 hover:bg-muted/50')}>
                                    <Icon className="w-4 h-4" style={{ color: preset.color }} />
                                    <div>
                                        <p className="font-medium">{preset.title}</p>
                                        <p className="text-muted-foreground">{preset.target} {preset.unit}/{preset.period}</p>
                                    </div>
                                </button>
                            );
                        })}
                    </div>
                    {selPreset !== null && (
                        <div className="flex items-center gap-2">
                            <Input type="number" value={customTarget} onChange={e => setCustomTarget(e.target.value)}
                                placeholder={`Target (default: ${PRESET_GOALS[selPreset].target})`} className="bg-muted/30 border-0 h-9 text-sm" />
                            <Button size="sm" className="h-9" onClick={addGoal}>Add</Button>
                        </div>
                    )}
                </div>
            )}

            {goals.length === 0 ? (
                <div className="py-8 text-center">
                    <Target className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-sm text-muted-foreground">No goals set yet</p>
                </div>
            ) : (
                <div className="grid grid-cols-3 gap-4">
                    {goals.map(goal => {
                        const Icon = ICON_MAP[goal.icon] || Target;
                        const pct = Math.round((goal.current / goal.target) * 100);
                        const done = pct >= 100;
                        return (
                            <div key={goal.id} className={cn('flex flex-col items-center text-center group relative p-3 rounded-xl transition-all',
                                done ? 'bg-primary/5' : 'hover:bg-muted/20')}>
                                <button onClick={() => setGoals(prev => prev.filter(g => g.id !== goal.id))}
                                    className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <X className="w-3 h-3 text-muted-foreground hover:text-destructive" />
                                </button>
                                <CircularProgress percent={pct} color={goal.color}>
                                    {done ? <CheckCircle className="w-6 h-6" style={{ color: goal.color }} /> : <span className="text-sm font-bold">{pct}%</span>}
                                </CircularProgress>
                                <p className="text-xs font-semibold mt-2">{goal.title}</p>
                                <p className="text-[10px] text-muted-foreground">{goal.current}/{goal.target} {goal.unit}</p>
                                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-muted/50 text-muted-foreground capitalize mt-1">{goal.period}</span>
                                {!done && (
                                    <Button variant="ghost" size="sm"
                                        className="mt-1 h-6 px-2 text-[10px] opacity-0 group-hover:opacity-100 transition-opacity"
                                        onClick={() => setGoals(prev => prev.map(g => g.id === goal.id ? { ...g, current: Math.min(g.current + 1, g.target) } : g))}>
                                        +1
                                    </Button>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}

            {goals.length > 0 && (
                <div className="mt-5 pt-4 border-t border-border/30">
                    <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-primary" />
                            <span className="text-xs font-medium">Overall</span>
                        </div>
                        <span className="text-xs text-muted-foreground">{overallPercent}%</span>
                    </div>
                    <div className="w-full h-2 bg-muted/30 rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all duration-700"
                            style={{ width: `${overallPercent}%`, background: 'linear-gradient(90deg, hsl(var(--primary)), hsl(var(--secondary)))' }} />
                    </div>
                </div>
            )}
        </div>
    );
};

export default GoalTracker;
