import { useState, useMemo } from 'react';
import { BarChart3, Clock, Target, Flame, BookOpen, Brain, TrendingUp, Sparkles, Download, Quote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const MOTIVATIONAL_QUOTES = [
    { text: "The expert in anything was once a beginner.", author: "Helen Hayes" },
    { text: "Learning is not attained by chance, it must be sought for with ardor.", author: "Abigail Adams" },
    { text: "The beautiful thing about learning is nobody can take it away from you.", author: "B.B. King" },
    { text: "Education is the most powerful weapon.", author: "Nelson Mandela" },
    { text: "The more that you read, the more things you will know.", author: "Dr. Seuss" },
    { text: "An investment in knowledge pays the best interest.", author: "Benjamin Franklin" },
];

interface WeekDay {
    day: string;
    hours: number;
    date: string;
}

const WeeklyReport = () => {
    const [isFlipped, setIsFlipped] = useState(false);

    // Generate mock weekly data
    const weekData = useMemo((): WeekDay[] => {
        const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        const now = new Date();
        const currentDay = now.getDay();
        return days.map((day, i) => {
            const d = new Date(now);
            d.setDate(d.getDate() - ((currentDay + 6 - i) % 7));
            const isPast = d <= now;
            return {
                day,
                hours: isPast ? +(Math.random() * 4 + 0.5).toFixed(1) : 0,
                date: d.toISOString().split('T')[0],
            };
        });
    }, []);

    const totalHours = weekData.reduce((s, d) => s + d.hours, 0);
    const avgHours = totalHours / Math.max(weekData.filter(d => d.hours > 0).length, 1);
    const maxHours = Math.max(...weekData.map(d => d.hours), 1);
    const bestDay = weekData.reduce((best, d) => d.hours > best.hours ? d : best, weekData[0]);

    // Pull streak from localStorage
    const streakData = useMemo(() => {
        try {
            const stored = localStorage.getItem('studyai_streak_data');
            if (stored) {
                const data = JSON.parse(stored);
                return { current: data.currentStreak || 0, longest: data.longestStreak || 0 };
            }
        } catch { }
        return { current: 3, longest: 7 };
    }, []);

    const quote = useMemo(() => {
        const idx = new Date().getDate() % MOTIVATIONAL_QUOTES.length;
        return MOTIVATIONAL_QUOTES[idx];
    }, []);

    // Mock stats
    const topicsCompleted = Math.floor(Math.random() * 5) + 2;
    const quizzesTaken = Math.floor(Math.random() * 6) + 1;
    const flashcardsReviewed = Math.floor(Math.random() * 30) + 10;

    const strengths = ['Data Structures', 'Web Development'];
    const weaknesses = ['Organic Chemistry', 'Statistics'];

    return (
        <div className="glass-morphism rounded-2xl overflow-hidden">
            {/* Header */}
            <div className="px-5 py-4 border-b border-border/30">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-primary" />
                        <h3 className="font-bold text-lg"><span className="gradient-text">Weekly Report</span></h3>
                    </div>
                    <span className="text-xs text-muted-foreground">
                        {new Date(weekData[0].date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} – {new Date(weekData[6].date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </span>
                </div>
            </div>

            <div className="p-5 space-y-5">
                {/* Summary Cards */}
                <div className="grid grid-cols-4 gap-3">
                    {[
                        { label: 'Total Hours', value: totalHours.toFixed(1), icon: Clock, color: 'text-blue-400', bg: 'bg-blue-500/10' },
                        { label: 'Streak', value: `${streakData.current}d`, icon: Flame, color: 'text-orange-400', bg: 'bg-orange-500/10' },
                        { label: 'Topics', value: topicsCompleted.toString(), icon: Target, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
                        { label: 'Quizzes', value: quizzesTaken.toString(), icon: Brain, color: 'text-violet-400', bg: 'bg-violet-500/10' },
                    ].map(stat => (
                        <div key={stat.label} className="text-center p-3 rounded-xl border border-border/20 bg-muted/10">
                            <stat.icon className={cn('w-4 h-4 mx-auto mb-1.5', stat.color)} />
                            <p className="text-xl font-extrabold">{stat.value}</p>
                            <p className="text-[10px] text-muted-foreground">{stat.label}</p>
                        </div>
                    ))}
                </div>

                {/* Bar Chart */}
                <div>
                    <p className="text-xs font-medium text-muted-foreground mb-3">Study Hours by Day</p>
                    <div className="flex items-end gap-2 h-28">
                        {weekData.map(d => (
                            <div key={d.day} className="flex-1 flex flex-col items-center gap-1">
                                <span className="text-[10px] font-medium text-muted-foreground">{d.hours > 0 ? `${d.hours}h` : ''}</span>
                                <div className="w-full rounded-t-md transition-all duration-500 relative group"
                                    style={{
                                        height: `${Math.max((d.hours / maxHours) * 80, 4)}%`,
                                        background: d.day === bestDay.day
                                            ? 'linear-gradient(180deg, hsl(var(--primary)), hsl(var(--secondary)))'
                                            : d.hours > 0 ? 'hsl(var(--primary) / 0.3)' : 'hsl(var(--muted) / 0.3)',
                                    }}
                                />
                                <span className={cn('text-[10px]', d.day === bestDay.day ? 'font-bold text-primary' : 'text-muted-foreground')}>
                                    {d.day}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Strengths & Weaknesses */}
                <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/15">
                        <div className="flex items-center gap-1.5 mb-2">
                            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-xs font-semibold text-emerald-400">Strengths</span>
                        </div>
                        {strengths.map(s => (
                            <p key={s} className="text-xs text-muted-foreground">• {s}</p>
                        ))}
                    </div>
                    <div className="p-3 rounded-xl bg-amber-500/5 border border-amber-500/15">
                        <div className="flex items-center gap-1.5 mb-2">
                            <Target className="w-3.5 h-3.5 text-amber-400" />
                            <span className="text-xs font-semibold text-amber-400">Focus Areas</span>
                        </div>
                        {weaknesses.map(w => (
                            <p key={w} className="text-xs text-muted-foreground">• {w}</p>
                        ))}
                    </div>
                </div>

                {/* More Stats */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-muted/10 border border-border/20">
                    <div className="text-center flex-1">
                        <p className="text-lg font-bold">{flashcardsReviewed}</p>
                        <p className="text-[10px] text-muted-foreground">Cards Reviewed</p>
                    </div>
                    <div className="w-px h-8 bg-border/30" />
                    <div className="text-center flex-1">
                        <p className="text-lg font-bold">{avgHours.toFixed(1)}h</p>
                        <p className="text-[10px] text-muted-foreground">Daily Average</p>
                    </div>
                    <div className="w-px h-8 bg-border/30" />
                    <div className="text-center flex-1">
                        <p className="text-lg font-bold">{bestDay.day}</p>
                        <p className="text-[10px] text-muted-foreground">Best Day</p>
                    </div>
                </div>

                {/* Motivational Quote */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-primary/5 via-secondary/5 to-accent/5 border border-primary/10">
                    <div className="flex items-start gap-3">
                        <Quote className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                        <div>
                            <p className="text-sm italic text-foreground/80">&ldquo;{quote.text}&rdquo;</p>
                            <p className="text-xs text-muted-foreground mt-1">— {quote.author}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default WeeklyReport;
