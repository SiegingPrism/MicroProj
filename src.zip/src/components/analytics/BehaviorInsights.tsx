import { Clock, Target, Sparkles, BookOpen } from 'lucide-react';

interface BehaviorInsightsProps {
  insights: {
    preferredStudyTime: string;
    avgSessionDuration: number;
    consistencyScore: number;
    topicDiversity: number;
  };
}

export const BehaviorInsights = ({ insights }: BehaviorInsightsProps) => {
  const getConsistencyLevel = (score: number) => {
    if (score >= 80) return { label: 'Excellent', color: 'text-primary' };
    if (score >= 60) return { label: 'Good', color: 'text-green-400' };
    if (score >= 40) return { label: 'Fair', color: 'text-amber-400' };
    return { label: 'Needs Work', color: 'text-destructive' };
  };

  const consistency = getConsistencyLevel(insights.consistencyScore);

  return (
    <div className="glass rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-5 h-5 text-purple-400" />
        <h3 className="font-semibold">Study Behavior Analysis</h3>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Preferred Study Time */}
        <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Peak Study Time</span>
          </div>
          <p className="font-semibold text-sm">{insights.preferredStudyTime}</p>
          <p className="text-xs text-muted-foreground mt-1">
            When you're most productive
          </p>
        </div>

        {/* Consistency Score */}
        <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Consistency</span>
          </div>
          <div className="flex items-baseline gap-2">
            <p className="font-semibold text-sm">{insights.consistencyScore}%</p>
            <span className={`text-xs ${consistency.color}`}>{consistency.label}</span>
          </div>
          <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-primary rounded-full transition-all duration-500"
              style={{ width: `${insights.consistencyScore}%` }}
            />
          </div>
        </div>

        {/* Avg Session Duration */}
        <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
          <div className="flex items-center gap-2 mb-2">
            <BookOpen className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Avg Session</span>
          </div>
          <p className="font-semibold text-sm">{insights.avgSessionDuration} min</p>
          <p className="text-xs text-muted-foreground mt-1">
            {insights.avgSessionDuration >= 25 ? 'Great focus time!' : 'Try longer sessions'}
          </p>
        </div>

        {/* Topic Diversity */}
        <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Topics Explored</span>
          </div>
          <p className="font-semibold text-sm">{insights.topicDiversity} topics</p>
          <p className="text-xs text-muted-foreground mt-1">
            {insights.topicDiversity >= 5 ? 'Well-rounded learning' : 'Explore more topics'}
          </p>
        </div>
      </div>
    </div>
  );
};
