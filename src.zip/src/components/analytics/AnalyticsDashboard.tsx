import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart3, Brain, MessageSquare, TrendingUp } from 'lucide-react';
import { StudyPatternChart } from './StudyPatternChart';
import { TopicDistributionChart } from './TopicDistributionChart';
import { LearningInsightsPanel } from './LearningInsightsPanel';
import { QuestionAnalytics } from './QuestionAnalytics';

interface AnalyticsDashboardProps {
  userId: string;
  domain: string | null;
}

interface StudySession {
  id: string;
  started_at: string;
  duration_minutes: number;
  topic: string;
}

export const AnalyticsDashboard = ({ userId, domain }: AnalyticsDashboardProps) => {
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchSessions = async () => {
      const { data } = await supabase
        .from('study_sessions')
        .select('id, started_at, duration_minutes, topic')
        .eq('user_id', userId)
        .order('started_at', { ascending: false })
        .limit(100);

      setSessions(data || []);
      setIsLoading(false);
    };

    fetchSessions();
  }, [userId]);

  if (isLoading) {
    return (
      <div className="glass rounded-xl p-8 animate-pulse">
        <div className="h-8 bg-muted rounded w-1/4 mb-6" />
        <div className="grid md:grid-cols-2 gap-4">
          <div className="h-64 bg-muted rounded" />
          <div className="h-64 bg-muted rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
          <BarChart3 className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h2 className="text-xl font-bold">AI Learning Companion</h2>
          <p className="text-sm text-muted-foreground">Personalized insights and analytics</p>
        </div>
      </div>

      <Tabs defaultValue="insights" className="w-full">
        <TabsList className="grid w-full grid-cols-4 glass">
          <TabsTrigger value="insights" className="gap-2">
            <Brain className="w-4 h-4" />
            <span className="hidden sm:inline">Insights</span>
          </TabsTrigger>
          <TabsTrigger value="patterns" className="gap-2">
            <TrendingUp className="w-4 h-4" />
            <span className="hidden sm:inline">Patterns</span>
          </TabsTrigger>
          <TabsTrigger value="questions" className="gap-2">
            <MessageSquare className="w-4 h-4" />
            <span className="hidden sm:inline">Questions</span>
          </TabsTrigger>
          <TabsTrigger value="progress" className="gap-2">
            <BarChart3 className="w-4 h-4" />
            <span className="hidden sm:inline">Progress</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="mt-6">
          <LearningInsightsPanel userId={userId} domain={domain} />
        </TabsContent>

        <TabsContent value="patterns" className="mt-6">
          <div className="grid md:grid-cols-2 gap-4">
            <StudyPatternChart sessions={sessions} />
            <TopicDistributionChart sessions={sessions} />
          </div>
        </TabsContent>

        <TabsContent value="questions" className="mt-6">
          <QuestionAnalytics userId={userId} />
        </TabsContent>

        <TabsContent value="progress" className="mt-6">
          <div className="glass rounded-xl p-5">
            <h3 className="font-semibold mb-4">Study Sessions History</h3>
            {sessions.length > 0 ? (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {sessions.slice(0, 20).map((session) => (
                  <div 
                    key={session.id} 
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                  >
                    <div>
                      <p className="font-medium text-sm">{session.topic}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(session.started_at).toLocaleDateString('en-US', {
                          weekday: 'short',
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-primary">{session.duration_minutes}m</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                No study sessions recorded yet. Start learning to track your progress!
              </p>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
