import { useState } from 'react';
import { AlertTriangle, Lightbulb, RefreshCw, Image } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface Weakness {
  area: string;
  suggestion: string;
}

interface WeaknessPattern {
  topic: string;
  frequency: number;
  indicators: string[];
  severity: 'low' | 'medium' | 'high';
}

interface WeaknessAnalysisProps {
  weaknesses: Weakness[];
  rawPatterns?: WeaknessPattern[];
  onGenerateVisual?: (topic: string) => void;
}

export const WeaknessAnalysis = ({ weaknesses, rawPatterns, onGenerateVisual }: WeaknessAnalysisProps) => {
  const [generatingVisual, setGeneratingVisual] = useState<string | null>(null);
  const [generatedVisuals, setGeneratedVisuals] = useState<Record<string, string>>({});

  const handleGenerateVisual = async (topic: string) => {
    setGeneratingVisual(topic);
    try {
      const { data, error } = await supabase.functions.invoke('generate-visual', {
        body: {
          topic: `Help understanding ${topic}`,
          context: `Educational diagram to help a student struggling with ${topic}`,
          style: 'diagram',
        },
      });

      if (error) throw error;

      if (data.imageUrl) {
        setGeneratedVisuals(prev => ({ ...prev, [topic]: data.imageUrl }));
        toast.success('Visual generated successfully!');
      }
    } catch (error) {
      console.error('Error generating visual:', error);
      toast.error('Failed to generate visual');
    } finally {
      setGeneratingVisual(null);
    }
  };

  const getSeverityColor = (severity: 'low' | 'medium' | 'high') => {
    switch (severity) {
      case 'high': return 'text-destructive border-destructive/30 bg-destructive/10';
      case 'medium': return 'text-amber-400 border-amber-400/30 bg-amber-400/10';
      case 'low': return 'text-primary border-primary/30 bg-primary/10';
    }
  };

  if ((!weaknesses || weaknesses.length === 0) && (!rawPatterns || rawPatterns.length === 0)) {
    return (
      <div className="glass rounded-xl p-5 text-center">
        <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-3">
          <Lightbulb className="w-6 h-6 text-primary" />
        </div>
        <h3 className="font-semibold mb-2">No Weaknesses Detected</h3>
        <p className="text-sm text-muted-foreground">
          Keep studying! We'll analyze your chat interactions to identify areas where you might need extra help.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Raw Patterns from Chat Analysis */}
      {rawPatterns && rawPatterns.length > 0 && (
        <div className="glass rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <h3 className="font-semibold">Detected Struggle Areas</h3>
          </div>
          <div className="space-y-3">
            {rawPatterns.map((pattern, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg border ${getSeverityColor(pattern.severity)}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{pattern.topic}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        pattern.severity === 'high' ? 'bg-destructive/20' :
                        pattern.severity === 'medium' ? 'bg-amber-400/20' : 'bg-primary/20'
                      }`}>
                        {pattern.severity} priority
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Mentioned {pattern.frequency} times • Indicators: {pattern.indicators.slice(0, 2).join(", ")}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleGenerateVisual(pattern.topic)}
                    disabled={generatingVisual === pattern.topic}
                    className="ml-2"
                  >
                    {generatingVisual === pattern.topic ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Image className="w-4 h-4" />
                    )}
                  </Button>
                </div>
                {generatedVisuals[pattern.topic] && (
                  <div className="mt-3 rounded-lg overflow-hidden border border-border/50">
                    <img 
                      src={generatedVisuals[pattern.topic]} 
                      alt={`Visual for ${pattern.topic}`}
                      className="w-full h-auto"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* AI Suggestions */}
      {weaknesses && weaknesses.length > 0 && (
        <div className="glass rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Lightbulb className="w-5 h-5 text-primary" />
            <h3 className="font-semibold">Improvement Suggestions</h3>
          </div>
          <div className="space-y-2">
            {weaknesses.map((weakness, index) => (
              <div key={index} className="p-3 rounded-lg bg-muted/30 border border-border/50">
                <p className="font-medium text-sm">{weakness.area}</p>
                <p className="text-xs text-muted-foreground mt-1">{weakness.suggestion}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
