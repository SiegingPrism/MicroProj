import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Sparkles, TrendingUp, Target, Clock, AlertCircle, Lightbulb, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { WeaknessAnalysis } from './WeaknessAnalysis';
import { BehaviorInsights } from './BehaviorInsights';
import { VisualizationSuggestions } from './VisualizationSuggestions';

interface LearningInsightsPanelProps {
  userId: string;
  domain: string | null;
}

interface Insight {
  type: 'success' | 'warning' | 'tip';
  title: string;
  description: string;
  icon: React.ElementType;
}

interface WeaknessPattern {
  topic: string;
  frequency: number;
  indicators: string[];
  severity: 'low' | 'medium' | 'high';
}

interface BehaviorData {
  preferredStudyTime: string;
  avgSessionDuration: number;
  consistencyScore: number;
  topicDiversity: number;
}

interface AIRecommendation {
  recommendation: string;
  focus_areas: string[];
  study_tips: string[];
  weaknesses?: { area: string; suggestion: string }[];
  behavior_insights?: BehaviorData;
  visualization_suggestions?: string[];
  raw_analysis?: {
    studyBehavior: BehaviorData;
    weaknessPatterns: WeaknessPattern[];
    questionTopics: string[];
    sessionCount: number;
    messageCount: number;
  };
}

export const LearningInsightsPanel = ({ userId, domain }: LearningInsightsPanelProps) => {
  const [insights, setInsights] = useState<Insight[]>([]);
  const [aiRecommendations, setAiRecommendations] = useState<AIRecommendation | null>(null);
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [stats, setStats] = useState({
    totalMinutes: 0,
    topicsCompleted: 0,
    currentStreak: 0,
    avgSessionLength: 0,
    mostStudiedTopic: '',
  });

  useEffect(() => {
    const analyzeData = async () => {
      // Fetch study sessions
      const { data: sessions } = await supabase
        .from('study_sessions')
        .select('*')
        .eq('user_id', userId)
        .order('started_at', { ascending: false });

      // Fetch completed topics
      const { count: topicsCount } = await supabase
        .from('completed_topics')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId);

      if (!sessions || sessions.length === 0) {
        setInsights([
          {
            type: 'tip',
            title: 'Start Your Journey',
            description: 'Begin your first study session to unlock personalized insights and recommendations.',
            icon: Lightbulb,
          },
        ]);
        return;
      }

      // Calculate stats
      const totalMinutes = sessions.reduce((acc, s) => acc + (s.duration_minutes || 0), 0);
      const avgSessionLength = Math.round(totalMinutes / sessions.length);
      
      // Find most studied topic
      const topicCounts: Record<string, number> = {};
      sessions.forEach(s => {
        topicCounts[s.topic] = (topicCounts[s.topic] || 0) + s.duration_minutes;
      });
      const mostStudiedTopic = Object.entries(topicCounts)
        .sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

      // Calculate streak
      const uniqueDays = [...new Set(sessions.map(s => new Date(s.started_at).toDateString()))];
      let streak = 0;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      for (let i = 0; i < uniqueDays.length; i++) {
        const checkDate = new Date(today);
        checkDate.setDate(checkDate.getDate() - i);
        if (uniqueDays.includes(checkDate.toDateString())) {
          streak++;
        } else if (i > 0) {
          break;
        }
      }

      setStats({
        totalMinutes,
        topicsCompleted: topicsCount || 0,
        currentStreak: streak,
        avgSessionLength,
        mostStudiedTopic,
      });

      // Generate insights
      const newInsights: Insight[] = [];

      // Streak insight
      if (streak >= 7) {
        newInsights.push({
          type: 'success',
          title: '🔥 Amazing Streak!',
          description: `You've studied for ${streak} days in a row! Your consistency is paying off.`,
          icon: TrendingUp,
        });
      } else if (streak >= 3) {
        newInsights.push({
          type: 'success',
          title: 'Building Momentum',
          description: `${streak} day streak! Keep it up to build stronger learning habits.`,
          icon: TrendingUp,
        });
      } else if (streak === 0) {
        newInsights.push({
          type: 'warning',
          title: 'Time to Study',
          description: "You haven't studied today yet. Even 15 minutes can make a difference!",
          icon: AlertCircle,
        });
      }

      // Session length insight
      if (avgSessionLength < 15) {
        newInsights.push({
          type: 'tip',
          title: 'Try Longer Sessions',
          description: 'Your average session is short. Try 25-minute focused sessions for better retention.',
          icon: Clock,
        });
      } else if (avgSessionLength > 60) {
        newInsights.push({
          type: 'tip',
          title: 'Consider Breaks',
          description: 'Long sessions are great, but remember to take short breaks every 45-50 minutes.',
          icon: Lightbulb,
        });
      }

      // Progress insight
      if (topicsCount && topicsCount >= 5) {
        newInsights.push({
          type: 'success',
          title: 'Great Progress!',
          description: `You've completed ${topicsCount} topics. You're making excellent progress!`,
          icon: Target,
        });
      }

      setInsights(newInsights);
    };

    analyzeData();
  }, [userId]);

  const generateAIRecommendations = async () => {
    setIsLoadingAI(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-insights', {
        body: {
          userId,
          domain,
          stats,
        },
      });

      if (error) throw error;
      setAiRecommendations(data);
    } catch (error) {
      console.error('Error generating AI recommendations:', error);
    } finally {
      setIsLoadingAI(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Stats Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="glass rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-primary">{Math.round(stats.totalMinutes / 60)}h</p>
          <p className="text-xs text-muted-foreground">Total Study Time</p>
        </div>
        <div className="glass rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-amber-400">{stats.topicsCompleted}</p>
          <p className="text-xs text-muted-foreground">Topics Completed</p>
        </div>
        <div className="glass rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-purple-400">{stats.avgSessionLength}m</p>
          <p className="text-xs text-muted-foreground">Avg Session</p>
        </div>
        <div className="glass rounded-xl p-4 text-center">
          <p className="text-2xl font-bold text-green-400">{stats.currentStreak}</p>
          <p className="text-xs text-muted-foreground">Day Streak</p>
        </div>
      </div>

      {/* Insights */}
      <div className="glass rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-primary" />
          <h3 className="font-semibold">Learning Insights</h3>
        </div>
        
        <div className="space-y-3">
          {insights.map((insight, index) => {
            const Icon = insight.icon;
            return (
              <div
                key={index}
                className={`p-4 rounded-lg border ${
                  insight.type === 'success' ? 'bg-primary/10 border-primary/30' :
                  insight.type === 'warning' ? 'bg-amber-500/10 border-amber-500/30' :
                  'bg-secondary/10 border-secondary/30'
                }`}
              >
                <div className="flex items-start gap-3">
                  <Icon className={`w-5 h-5 mt-0.5 ${
                    insight.type === 'success' ? 'text-primary' :
                    insight.type === 'warning' ? 'text-amber-400' :
                    'text-secondary'
                  }`} />
                  <div>
                    <p className="font-medium">{insight.title}</p>
                    <p className="text-sm text-muted-foreground">{insight.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AI Recommendations */}
      <div className="glass rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-amber-400" />
            <h3 className="font-semibold">AI Study Recommendations</h3>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={generateAIRecommendations}
            disabled={isLoadingAI}
          >
            {isLoadingAI ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : (
              'Get Recommendations'
            )}
          </Button>
        </div>

        {aiRecommendations ? (
          <div className="space-y-4">
            <p className="text-sm">{aiRecommendations.recommendation}</p>
            
            {aiRecommendations.focus_areas && aiRecommendations.focus_areas.length > 0 && (
              <div>
                <p className="text-sm font-medium mb-2">Focus Areas:</p>
                <div className="flex flex-wrap gap-2">
                  {aiRecommendations.focus_areas.map((area, i) => (
                    <span key={i} className="px-3 py-1 rounded-full bg-primary/20 text-primary text-xs">
                      {area}
                    </span>
                  ))}
                </div>
              </div>
            )}
            
            {aiRecommendations.study_tips && aiRecommendations.study_tips.length > 0 && (
              <div>
                <p className="text-sm font-medium mb-2">Study Tips:</p>
                <ul className="space-y-1">
                  {aiRecommendations.study_tips.map((tip, i) => (
                    <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                      <span className="text-primary">•</span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">
            Click "Get Recommendations" to receive personalized study suggestions based on your learning patterns.
          </p>
        )}
      </div>

      {/* Behavior Insights */}
      {aiRecommendations?.behavior_insights && (
        <BehaviorInsights insights={aiRecommendations.behavior_insights} />
      )}

      {/* Weakness Analysis */}
      {aiRecommendations && (
        <WeaknessAnalysis 
          weaknesses={aiRecommendations.weaknesses || []}
          rawPatterns={aiRecommendations.raw_analysis?.weaknessPatterns}
        />
      )}

      {/* AI Visual Suggestions */}
      {aiRecommendations?.visualization_suggestions && aiRecommendations.visualization_suggestions.length > 0 && (
        <VisualizationSuggestions 
          suggestions={aiRecommendations.visualization_suggestions}
          domain={domain}
        />
      )}
    </div>
  );
};
