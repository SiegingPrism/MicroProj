import { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';

interface StudySession {
  topic: string;
  duration_minutes: number;
}

interface TopicDistributionChartProps {
  sessions: StudySession[];
}

const COLORS = [
  'hsl(160 84% 39%)',
  'hsl(270 70% 50%)',
  'hsl(45 93% 47%)',
  'hsl(200 98% 39%)',
  'hsl(330 81% 60%)',
  'hsl(15 90% 55%)',
];

const chartConfig = {
  topic: {
    label: 'Topic',
  },
};

export const TopicDistributionChart = ({ sessions }: TopicDistributionChartProps) => {
  const topicData = useMemo(() => {
    const topicMap: Record<string, number> = {};
    
    sessions.forEach(session => {
      const topic = session.topic || 'General';
      topicMap[topic] = (topicMap[topic] || 0) + session.duration_minutes;
    });
    
    return Object.entries(topicMap)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6);
  }, [sessions]);

  if (sessions.length === 0 || topicData.length === 0) {
    return (
      <div className="glass rounded-xl p-6 text-center">
        <p className="text-muted-foreground">No topic data available yet.</p>
      </div>
    );
  }

  return (
    <div className="glass rounded-xl p-5">
      <h3 className="font-semibold mb-4">Study Time by Topic</h3>
      <ChartContainer config={chartConfig} className="h-[250px] w-full">
        <PieChart>
          <Pie
            data={topicData}
            cx="50%"
            cy="50%"
            innerRadius={50}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
            label={({ name, percent }) => `${name.slice(0, 10)}${name.length > 10 ? '...' : ''} (${(percent * 100).toFixed(0)}%)`}
            labelLine={false}
          >
            {topicData.map((_, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <ChartTooltip content={<ChartTooltipContent />} />
        </PieChart>
      </ChartContainer>
    </div>
  );
};
