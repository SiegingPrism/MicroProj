import { useState } from 'react';
import { ImageIcon, RefreshCw, Download, Maximize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface VisualizationSuggestionsProps {
  suggestions: string[];
  domain?: string | null;
}

export const VisualizationSuggestions = ({ suggestions, domain }: VisualizationSuggestionsProps) => {
  const [generating, setGenerating] = useState<string | null>(null);
  const [visuals, setVisuals] = useState<Record<string, { url: string; description: string }>>({});
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  const handleGenerate = async (topic: string, style: 'detailed' | 'diagram' | 'concept') => {
    setGenerating(topic);
    try {
      const { data, error } = await supabase.functions.invoke('generate-visual', {
        body: {
          topic,
          context: `Educational visualization for studying ${topic}`,
          style,
          domain: domain || undefined,
        },
      });

      if (error) throw error;

      if (data.imageUrl) {
        setVisuals(prev => ({
          ...prev,
          [topic]: { url: data.imageUrl, description: data.description || '' },
        }));
        toast.success('Visual generated!');
      }
    } catch (error) {
      console.error('Error generating visual:', error);
      toast.error('Failed to generate visual');
    } finally {
      setGenerating(null);
    }
  };

  const handleDownload = (url: string, topic: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = `${topic.replace(/\s+/g, '_')}_visual.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!suggestions || suggestions.length === 0) {
    return null;
  }

  return (
    <>
      <div className="glass rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <ImageIcon className="w-5 h-5 text-primary" />
          <h3 className="font-semibold">AI Visual Suggestions</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          Topics that would benefit from visual learning aids:
        </p>

        <div className="space-y-4">
          {suggestions.map((topic, index) => (
            <div key={index} className="p-4 rounded-lg bg-muted/30 border border-border/50">
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium text-sm">{topic}</span>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleGenerate(topic, 'diagram')}
                    disabled={generating === topic}
                    className="text-xs"
                  >
                    {generating === topic ? (
                      <RefreshCw className="w-3 h-3 animate-spin" />
                    ) : (
                      'Diagram'
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleGenerate(topic, 'concept')}
                    disabled={generating === topic}
                    className="text-xs"
                  >
                    Concept Map
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleGenerate(topic, 'detailed')}
                    disabled={generating === topic}
                    className="text-xs"
                  >
                    Detailed
                  </Button>
                </div>
              </div>

              {visuals[topic] && (
                <div className="relative group">
                  <img
                    src={visuals[topic].url}
                    alt={`Visual for ${topic}`}
                    className="w-full h-auto rounded-lg cursor-pointer"
                    onClick={() => setZoomedImage(visuals[topic].url)}
                  />
                  <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="secondary"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setZoomedImage(visuals[topic].url)}
                    >
                      <Maximize2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="secondary"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleDownload(visuals[topic].url, topic)}
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                  {visuals[topic].description && (
                    <p className="text-xs text-muted-foreground mt-2">
                      {visuals[topic].description}
                    </p>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Zoom Dialog */}
      <Dialog open={!!zoomedImage} onOpenChange={() => setZoomedImage(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Visual Detail</DialogTitle>
          </DialogHeader>
          {zoomedImage && (
            <img src={zoomedImage} alt="Zoomed visual" className="w-full h-auto rounded-lg" />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};
