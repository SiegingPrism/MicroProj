import { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';

interface StudySession {
  started_at: string;
  duration_minutes: number;
  topic: string;
}

interface StudyPatternChartProps {
  sessions: StudySession[];
}

const chartConfig = {
  minutes: {
    label: 'Study Time',
    color: 'hsl(160 84% 39%)',
  },
};

export const StudyPatternChart = ({ sessions }: StudyPatternChartProps) => {
  const weeklyData = useMemo(() => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dataMap: Record<string, number> = {};
    
    // Initialize all days with 0
    days.forEach(day => {
      dataMap[day] = 0;
    });
    
    // Aggregate session data by day of week
    sessions.forEach(session => {
      const date = new Date(session.started_at);
      const dayName = days[date.getDay()];
      dataMap[dayName] += session.duration_minutes;
    });
    
    return days.map(day => ({
      day,
      minutes: dataMap[day],
    }));
  }, [sessions]);

  if (sessions.length === 0) {
    return (
      <div className="glass rounded-xl p-6 text-center">
        <p className="text-muted-foreground">No study sessions recorded yet. Start learning to see your patterns!</p>
      </div>
    );
  }

  return (
    <div className="glass rounded-xl p-5">
      <h3 className="font-semibold mb-4">Weekly Study Pattern</h3>
      <ChartContainer config={chartConfig} className="h-[200px] w-full">
        <AreaChart data={weeklyData}>
          <defs>
            <linearGradient id="colorMinutes" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(160 84% 39%)" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="hsl(160 84% 39%)" stopOpacity={0.1}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(222 30% 18%)" />
          <XAxis 
            dataKey="day" 
            stroke="hsl(215 20% 55%)" 
            fontSize={12}
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            stroke="hsl(215 20% 55%)" 
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${value}m`}
          />
          <ChartTooltip content={<ChartTooltipContent />} />
          <Area 
            type="monotone" 
            dataKey="minutes" 
            stroke="hsl(160 84% 39%)" 
            fillOpacity={1}
            fill="url(#colorMinutes)" 
          />
        </AreaChart>
      </ChartContainer>
    </div>
  );
};
