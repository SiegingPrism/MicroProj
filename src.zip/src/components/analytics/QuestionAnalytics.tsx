import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { MessageSquare, Brain, TrendingUp } from 'lucide-react';

interface QuestionAnalyticsProps {
  userId: string;
}

interface Message {
  role: string;
  content: string;
  created_at: string;
}

const chartConfig = {
  questions: {
    label: 'Questions',
    color: 'hsl(270 70% 50%)',
  },
};

export const QuestionAnalytics = ({ userId }: QuestionAnalyticsProps) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchMessages = async () => {
      const { data } = await supabase
        .from('chat_messages')
        .select('role, content, created_at')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(500);

      setMessages(data || []);
      setIsLoading(false);
    };

    fetchMessages();
  }, [userId]);

  const analytics = useMemo(() => {
    const userMessages = messages.filter(m => m.role === 'user');
    const aiMessages = messages.filter(m => m.role === 'assistant');

    // Questions per day (last 7 days)
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const questionsByDay: Record<string, number> = {};
    days.forEach(d => { questionsByDay[d] = 0; });

    userMessages.forEach(msg => {
      const date = new Date(msg.created_at);
      const dayName = days[date.getDay()];
      questionsByDay[dayName]++;
    });

    const dailyData = days.map(day => ({
      day,
      questions: questionsByDay[day],
    }));

    // Common question types (basic categorization)
    const questionTypes: Record<string, number> = {
      'What/How': 0,
      'Why': 0,
      'Can you explain': 0,
      'Example': 0,
      'Other': 0,
    };

    userMessages.forEach(msg => {
      const content = msg.content.toLowerCase();
      if (content.includes('what') || content.includes('how')) {
        questionTypes['What/How']++;
      } else if (content.includes('why')) {
        questionTypes['Why']++;
      } else if (content.includes('explain')) {
        questionTypes['Can you explain']++;
      } else if (content.includes('example') || content.includes('show me')) {
        questionTypes['Example']++;
      } else {
        questionTypes['Other']++;
      }
    });

    const avgResponseLength = aiMessages.length > 0
      ? Math.round(aiMessages.reduce((acc, m) => acc + m.content.length, 0) / aiMessages.length)
      : 0;

    return {
      totalQuestions: userMessages.length,
      totalResponses: aiMessages.length,
      avgResponseLength,
      dailyData,
      questionTypes,
    };
  }, [messages]);

  if (isLoading) {
    return (
      <div className="glass rounded-xl p-6 animate-pulse">
        <div className="h-6 bg-muted rounded w-1/3 mb-4" />
        <div className="h-40 bg-muted rounded" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-3">
        <div className="glass rounded-xl p-4 text-center">
          <MessageSquare className="w-5 h-5 text-secondary mx-auto mb-2" />
          <p className="text-2xl font-bold">{analytics.totalQuestions}</p>
          <p className="text-xs text-muted-foreground">Questions Asked</p>
        </div>
        <div className="glass rounded-xl p-4 text-center">
          <Brain className="w-5 h-5 text-primary mx-auto mb-2" />
          <p className="text-2xl font-bold">{analytics.totalResponses}</p>
          <p className="text-xs text-muted-foreground">AI Responses</p>
        </div>
        <div className="glass rounded-xl p-4 text-center">
          <TrendingUp className="w-5 h-5 text-amber-400 mx-auto mb-2" />
          <p className="text-2xl font-bold">{analytics.avgResponseLength}</p>
          <p className="text-xs text-muted-foreground">Avg Response Chars</p>
        </div>
      </div>

      {/* Daily Questions Chart */}
      <div className="glass rounded-xl p-5">
        <h3 className="font-semibold mb-4">Questions This Week</h3>
        {analytics.totalQuestions > 0 ? (
          <ChartContainer config={chartConfig} className="h-[180px] w-full">
            <BarChart data={analytics.dailyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(222 30% 18%)" />
              <XAxis 
                dataKey="day" 
                stroke="hsl(215 20% 55%)" 
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                stroke="hsl(215 20% 55%)" 
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar 
                dataKey="questions" 
                fill="hsl(270 70% 50%)" 
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ChartContainer>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-8">
            No questions asked yet. Start chatting with the AI!
          </p>
        )}
      </div>

      {/* Question Types */}
      <div className="glass rounded-xl p-5">
        <h3 className="font-semibold mb-4">Question Types</h3>
        <div className="space-y-3">
          {Object.entries(analytics.questionTypes).map(([type, count]) => {
            const percentage = analytics.totalQuestions > 0 
              ? Math.round((count / analytics.totalQuestions) * 100) 
              : 0;
            return (
              <div key={type}>
                <div className="flex justify-between text-sm mb-1">
                  <span>{type}</span>
                  <span className="text-muted-foreground">{count} ({percentage}%)</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-primary to-secondary transition-all"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
