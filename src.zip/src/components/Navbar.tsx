import { Button } from "@/components/ui/button";
import { Brain, Menu, X, LogIn, Trophy, Settings, Wrench, ChevronRight, Sun, Moon, BookOpen, StickyNote } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { user, loading } = useAuth();
  const { isDark, toggleTheme } = useTheme();

  const isActive = (path: string) => location.pathname === path;

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 16);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled
      ? 'glass border-b border-border shadow-lg'
      : 'bg-transparent border-b border-transparent'
      }`}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-[68px]">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center relative overflow-hidden"
              style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}
            >
              <Brain className="w-5 h-5 text-white relative z-10" />
            </div>
            <span className="font-bold text-[17px] tracking-tight text-foreground">
              Study<span className="text-primary">AI</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {[
              { to: "/", label: "Home" },
              { to: "/chat", label: "AI Chat" },
              { to: "/tools", label: "Tools", icon: <Wrench className="w-3 h-3" /> },
              { to: "/flashcards", label: "Flashcards", icon: <BookOpen className="w-3 h-3" /> },
              { to: "/notes", label: "Notes", icon: <StickyNote className="w-3 h-3" /> },
              { to: "/leaderboard", label: "Leaderboard", icon: <Trophy className="w-3 h-3" /> },
            ].map(({ to, label, icon }) => (
              <Link
                key={to}
                to={to}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${isActive(to)
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}
              >
                {icon}
                {label}
                {isActive(to) && (
                  <span className="ml-1 w-1 h-1 rounded-full bg-primary inline-block" />
                )}
              </Link>
            ))}
          </div>

          {/* Right side: theme toggle + CTA */}
          <div className="hidden md:flex items-center gap-2">
            {/* 🌙 / ☀️ Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="w-9 h-9 rounded-lg flex items-center justify-center transition-all duration-300 border border-border hover:bg-muted hover:border-border text-muted-foreground hover:text-foreground"
              title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {isDark ? (
                <Sun className="w-4 h-4 transition-transform duration-300 rotate-0 hover:rotate-12" />
              ) : (
                <Moon className="w-4 h-4 transition-transform duration-300 rotate-0 hover:-rotate-12" />
              )}
            </button>

            {!loading && (
              user ? (
                <>
                  <Link to="/settings">
                    <Button variant="ghost" size="icon" className="w-9 h-9 hover:bg-muted rounded-lg">
                      <Settings className="w-4 h-4 text-muted-foreground" />
                    </Button>
                  </Link>
                  <Link to="/dashboard">
                    <Button
                      size="sm"
                      className="gap-1.5 rounded-lg px-4 font-semibold text-white border-0 shadow-md shadow-primary/20"
                      style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}
                    >
                      Dashboard
                      <ChevronRight className="w-3.5 h-3.5" />
                    </Button>
                  </Link>
                </>
              ) : (
                <Link to="/auth">
                  <Button
                    size="sm"
                    className="gap-2 rounded-lg px-5 font-semibold text-white border-0 shadow-md shadow-primary/20"
                    style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    Get Started
                  </Button>
                </Link>
              )
            )}
          </div>

          {/* Mobile: theme toggle + hamburger */}
          <div className="md:hidden flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className="w-9 h-9 rounded-lg flex items-center justify-center border border-border hover:bg-muted text-muted-foreground hover:text-foreground transition-all"
              title={isDark ? 'Light Mode' : 'Dark Mode'}
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              className="p-2 rounded-lg hover:bg-muted transition-colors"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col gap-1 pb-2">
              {[
                { to: "/", label: "Home" },
                { to: "/chat", label: "AI Chat" },
                { to: "/tools", label: "Tools" },
                { to: "/flashcards", label: "Flashcards" },
                { to: "/notes", label: "Notes" },
                { to: "/leaderboard", label: "Leaderboard" },
              ].map(({ to, label }) => (
                <Link
                  key={to}
                  to={to}
                  className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${isActive(to)
                    ? 'bg-primary/10 text-primary'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                    }`}
                  onClick={() => setIsOpen(false)}
                >
                  {label}
                </Link>
              ))}
              <div className="pt-3 mt-2 border-t border-border">
                {!loading && (
                  user ? (
                    <>
                      <Link to="/settings" onClick={() => setIsOpen(false)}>
                        <Button variant="outline" className="w-full gap-2 mb-2 rounded-lg">
                          <Settings className="w-4 h-4" /> Settings
                        </Button>
                      </Link>
                      <Link to="/dashboard" onClick={() => setIsOpen(false)}>
                        <Button
                          className="w-full rounded-lg font-semibold text-white border-0"
                          style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}
                        >
                          Dashboard
                        </Button>
                      </Link>
                    </>
                  ) : (
                    <Link to="/auth" onClick={() => setIsOpen(false)}>
                      <Button
                        className="w-full gap-2 rounded-lg font-semibold text-white border-0"
                        style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}
                      >
                        <LogIn className="w-4 h-4" /> Get Started
                      </Button>
                    </Link>
                  )
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
