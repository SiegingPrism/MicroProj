import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, RotateCcw, Sparkles } from "lucide-react";

interface Flashcard {
  front: string;
  back: string;
}

interface FlashcardDeckProps {
  flashcards: Flashcard[];
  topic: string;
}

export const FlashcardDeck = ({ flashcards, topic }: FlashcardDeckProps) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [masteredCards, setMasteredCards] = useState<Set<number>>(new Set());

  const currentCard = flashcards[currentIndex];

  const flipCard = () => {
    setIsFlipped(!isFlipped);
  };

  const nextCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % flashcards.length);
    }, 150);
  };

  const prevCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + flashcards.length) % flashcards.length);
    }, 150);
  };

  const markMastered = () => {
    setMasteredCards((prev) => new Set([...prev, currentIndex]));
    nextCard();
  };

  const resetDeck = () => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setMasteredCards(new Set());
  };

  const remainingCards = flashcards.length - masteredCards.size;

  return (
    <Card className="glass border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Flashcards: {topic}
          </span>
          <span className="text-sm font-normal text-muted-foreground">
            {remainingCards} remaining
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Progress dots */}
        <div className="flex justify-center gap-1">
          {flashcards.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setIsFlipped(false);
                setCurrentIndex(index);
              }}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentIndex
                  ? "w-6 bg-primary"
                  : masteredCards.has(index)
                  ? "bg-green-500"
                  : "bg-muted-foreground/30"
              }`}
            />
          ))}
        </div>

        {/* Flashcard */}
        <div
          className="relative h-64 cursor-pointer perspective-1000"
          onClick={flipCard}
        >
          <div
            className={`absolute inset-0 w-full h-full transition-transform duration-500 transform-style-preserve-3d ${
              isFlipped ? "rotate-y-180" : ""
            }`}
            style={{
              transformStyle: "preserve-3d",
              transform: isFlipped ? "rotateY(180deg)" : "rotateY(0deg)",
            }}
          >
            {/* Front */}
            <div
              className={`absolute inset-0 w-full h-full backface-hidden rounded-2xl p-6 flex flex-col items-center justify-center text-center border-2 border-primary/20 bg-gradient-to-br from-primary/10 to-primary/5 ${
                masteredCards.has(currentIndex) ? "border-green-500/50" : ""
              }`}
              style={{ backfaceVisibility: "hidden" }}
            >
              <p className="text-xs text-muted-foreground mb-2">Question</p>
              <p className="text-lg font-medium">{currentCard.front}</p>
              <p className="text-xs text-muted-foreground mt-4">
                Click to reveal answer
              </p>
            </div>

            {/* Back */}
            <div
              className="absolute inset-0 w-full h-full backface-hidden rounded-2xl p-6 flex flex-col items-center justify-center text-center border-2 border-secondary/20 bg-gradient-to-br from-secondary/10 to-secondary/5"
              style={{
                backfaceVisibility: "hidden",
                transform: "rotateY(180deg)",
              }}
            >
              <p className="text-xs text-muted-foreground mb-2">Answer</p>
              <p className="text-lg font-medium">{currentCard.back}</p>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            size="icon"
            onClick={prevCard}
            disabled={flashcards.length <= 1}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>

          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={markMastered}
              className="text-green-500 hover:bg-green-500/10"
              disabled={masteredCards.has(currentIndex)}
            >
              {masteredCards.has(currentIndex) ? "Mastered ✓" : "Got it!"}
            </Button>
            <Button variant="outline" onClick={nextCard}>
              Still Learning
            </Button>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={nextCard}
            disabled={flashcards.length <= 1}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Reset option */}
        {masteredCards.size > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={resetDeck}
            className="w-full gap-2"
          >
            <RotateCcw className="w-3 h-3" />
            Reset Deck
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default FlashcardDeck;
