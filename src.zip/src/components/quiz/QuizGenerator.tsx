import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, Loader2, Sparkles, Check, X, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { FlashcardDeck } from "./FlashcardDeck";

interface Question {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

interface Flashcard {
  front: string;
  back: string;
}

interface QuizData {
  questions: Question[];
  flashcards: Flashcard[];
}

export const QuizGenerator = () => {
  const { user } = useAuth();
  const [topic, setTopic] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [quizData, setQuizData] = useState<QuizData | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [showFlashcards, setShowFlashcards] = useState(false);
  const [quizComplete, setQuizComplete] = useState(false);

  const generateQuiz = async () => {
    if (!topic.trim()) {
      toast.error("Please enter a topic");
      return;
    }

    setIsLoading(true);
    setQuizData(null);
    setCurrentQuestion(0);
    setScore(0);
    setQuizComplete(false);
    setShowFlashcards(false);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-quiz`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
            "Authorization": `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({ topic, questionCount: 5 }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to generate quiz");
      }

      const data = await response.json();
      setQuizData(data);

      // Save flashcards to database
      if (user && data.flashcards?.length > 0) {
        const flashcardsToInsert = data.flashcards.map((fc: Flashcard) => ({
          user_id: user.id,
          front: fc.front,
          back: fc.back,
          topic: topic,
        }));

        await supabase.from("flashcards").insert(flashcardsToInsert);
      }

      toast.success("Quiz generated! Let's test your knowledge.");
    } catch (error) {
      console.error("Error generating quiz:", error);
      toast.error("Failed to generate quiz. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnswer = (index: number) => {
    if (showResult) return;
    
    setSelectedAnswer(index);
    setShowResult(true);

    if (quizData && index === quizData.questions[currentQuestion].correctIndex) {
      setScore((prev) => prev + 1);
    }
  };

  const nextQuestion = async () => {
    if (!quizData) return;

    if (currentQuestion < quizData.questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setQuizComplete(true);
      
      // Save quiz result to database
      if (user) {
        const scorePercentage = (score / quizData.questions.length) * 100;
        await supabase.from("quiz_results").insert({
          user_id: user.id,
          topic,
          total_questions: quizData.questions.length,
          correct_answers: score + (selectedAnswer === quizData.questions[currentQuestion].correctIndex ? 1 : 0),
          score_percentage: scorePercentage,
        });
      }
    }
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setQuizComplete(false);
  };

  if (showFlashcards && quizData?.flashcards) {
    return (
      <div className="space-y-4">
        <Button 
          variant="outline" 
          onClick={() => setShowFlashcards(false)}
          className="gap-2"
        >
          <RotateCcw className="w-4 h-4" />
          Back to Quiz
        </Button>
        <FlashcardDeck flashcards={quizData.flashcards} topic={topic} />
      </div>
    );
  }

  return (
    <Card className="glass border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-primary" />
          AI Quiz Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!quizData ? (
          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Enter a topic to generate a quiz..."
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && generateQuiz()}
                disabled={isLoading}
              />
              <Button onClick={generateQuiz} disabled={isLoading || !topic.trim()}>
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Sparkles className="w-4 h-4" />
                )}
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              Enter any topic and AI will generate quiz questions and flashcards for you!
            </p>
          </div>
        ) : quizComplete ? (
          <div className="text-center space-y-6 py-8">
            <div className="w-20 h-20 mx-auto rounded-full bg-primary/20 flex items-center justify-center animate-bounce-soft">
              <Sparkles className="w-10 h-10 text-primary" />
            </div>
            <div>
              <h3 className="text-2xl font-bold">Quiz Complete!</h3>
              <p className="text-muted-foreground mt-2">
                You scored {score + (selectedAnswer === quizData.questions[currentQuestion]?.correctIndex ? 1 : 0)} out of {quizData.questions.length}
              </p>
            </div>
            <div className="flex flex-col gap-2">
              <Button onClick={restartQuiz} className="gap-2">
                <RotateCcw className="w-4 h-4" />
                Try Again
              </Button>
              {quizData.flashcards?.length > 0 && (
                <Button 
                  variant="outline" 
                  onClick={() => setShowFlashcards(true)}
                  className="gap-2"
                >
                  <Brain className="w-4 h-4" />
                  Review Flashcards ({quizData.flashcards.length})
                </Button>
              )}
              <Button 
                variant="ghost" 
                onClick={() => {
                  setQuizData(null);
                  setTopic("");
                }}
              >
                New Topic
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Progress */}
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">
                Question {currentQuestion + 1} of {quizData.questions.length}
              </span>
              <span className="text-primary font-medium">Score: {score}</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{
                  width: `${((currentQuestion + 1) / quizData.questions.length) * 100}%`,
                }}
              />
            </div>

            {/* Question */}
            <div className="p-4 bg-muted/50 rounded-xl">
              <p className="text-lg font-medium">
                {quizData.questions[currentQuestion].question}
              </p>
            </div>

            {/* Options */}
            <div className="grid gap-3">
              {quizData.questions[currentQuestion].options.map((option, index) => {
                const isCorrect = index === quizData.questions[currentQuestion].correctIndex;
                const isSelected = index === selectedAnswer;

                return (
                  <button
                    key={index}
                    onClick={() => handleAnswer(index)}
                    disabled={showResult}
                    className={`p-4 text-left rounded-xl border-2 transition-all duration-200 ${
                      showResult
                        ? isCorrect
                          ? "border-green-500 bg-green-500/10"
                          : isSelected
                          ? "border-red-500 bg-red-500/10"
                          : "border-border/50 opacity-50"
                        : "border-border/50 hover:border-primary hover:bg-primary/5"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{option}</span>
                      {showResult && isCorrect && (
                        <Check className="w-5 h-5 text-green-500" />
                      )}
                      {showResult && isSelected && !isCorrect && (
                        <X className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Explanation */}
            {showResult && (
              <div className="p-4 bg-muted/50 rounded-xl border border-border/50 animate-fade-in">
                <p className="text-sm text-muted-foreground">
                  <strong>Explanation:</strong>{" "}
                  {quizData.questions[currentQuestion].explanation}
                </p>
              </div>
            )}

            {/* Next button */}
            {showResult && (
              <Button onClick={nextQuestion} className="w-full">
                {currentQuestion < quizData.questions.length - 1
                  ? "Next Question"
                  : "See Results"}
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default QuizGenerator;
