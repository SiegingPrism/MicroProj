import { useState, useEffect, useCallback, useRef } from 'react';
import { Play, Pause, RotateCcw, Coffee, Brain, Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

type SessionType = 'focus' | 'short_break' | 'long_break';
type AmbientSound = 'rain' | 'cafe' | 'lofi' | 'nature' | null;

const SESSION_DURATIONS: Record<SessionType, number> = {
  focus: 25 * 60,
  short_break: 5 * 60,
  long_break: 15 * 60,
};

const AMBIENT_SOUNDS: { id: AmbientSound; label: string; icon: string }[] = [
  { id: 'rain', label: 'Rain', icon: '🌧️' },
  { id: 'cafe', label: 'Cafe', icon: '☕' },
  { id: 'lofi', label: 'Lo-Fi', icon: '🎵' },
  { id: 'nature', label: 'Nature', icon: '🌿' },
];

const PomodoroTimer = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [sessionType, setSessionType] = useState<SessionType>('focus');
  const [timeRemaining, setTimeRemaining] = useState(SESSION_DURATIONS.focus);
  const [isRunning, setIsRunning] = useState(false);
  const [completedSessions, setCompletedSessions] = useState(0);
  const [ambientSound, setAmbientSound] = useState<AmbientSound>(null);
  const [isMuted, setIsMuted] = useState(false);
  const sessionIdRef = useRef<string | null>(null);
  const startTimeRef = useRef<Date | null>(null);

  const totalTime = SESSION_DURATIONS[sessionType];
  const progress = ((totalTime - timeRemaining) / totalTime) * 100;
  const circumference = 2 * Math.PI * 120;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const startSession = useCallback(async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('focus_sessions')
      .insert({
        user_id: user.id,
        duration_minutes: Math.floor(totalTime / 60),
        session_type: sessionType,
        ambient_sound: ambientSound,
      })
      .select('id')
      .single();

    if (error) {
      console.error('Error starting focus session:', error);
      return;
    }

    sessionIdRef.current = data.id;
    startTimeRef.current = new Date();
    setIsRunning(true);
  }, [user, totalTime, sessionType, ambientSound]);

  const pauseSession = useCallback(() => {
    setIsRunning(false);
  }, []);

  const completeSession = useCallback(async () => {
    if (!sessionIdRef.current || !startTimeRef.current) return;

    const completedMinutes = Math.floor((Date.now() - startTimeRef.current.getTime()) / 60000);

    await supabase
      .from('focus_sessions')
      .update({
        completed_duration_minutes: completedMinutes,
        ended_at: new Date().toISOString(),
        completed: true,
      })
      .eq('id', sessionIdRef.current);

    sessionIdRef.current = null;
    startTimeRef.current = null;

    if (sessionType === 'focus') {
      setCompletedSessions((prev) => prev + 1);
      toast({
        title: '🎉 Focus session complete!',
        description: 'Great work! Take a well-deserved break.',
      });
    }
  }, [sessionType, toast]);

  const resetTimer = useCallback(() => {
    setIsRunning(false);
    setTimeRemaining(SESSION_DURATIONS[sessionType]);
    sessionIdRef.current = null;
    startTimeRef.current = null;
  }, [sessionType]);

  const switchSession = useCallback((type: SessionType) => {
    setSessionType(type);
    setTimeRemaining(SESSION_DURATIONS[type]);
    setIsRunning(false);
    sessionIdRef.current = null;
    startTimeRef.current = null;
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isRunning && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining((prev) => prev - 1);
      }, 1000);
    } else if (timeRemaining === 0 && isRunning) {
      completeSession();
      setIsRunning(false);
      
      // Auto-switch to next session type
      if (sessionType === 'focus') {
        const nextType = completedSessions % 4 === 3 ? 'long_break' : 'short_break';
        switchSession(nextType);
      } else {
        switchSession('focus');
      }
    }

    return () => clearInterval(interval);
  }, [isRunning, timeRemaining, sessionType, completedSessions, completeSession, switchSession]);

  const getSessionColor = () => {
    switch (sessionType) {
      case 'focus':
        return 'hsl(var(--primary))';
      case 'short_break':
        return 'hsl(270, 70%, 50%)';
      case 'long_break':
        return 'hsl(200, 70%, 50%)';
    }
  };

  return (
    <Card className="glass-morphism border-0 overflow-hidden">
      <CardHeader className="text-center pb-2">
        <CardTitle className="flex items-center justify-center gap-2">
          {sessionType === 'focus' ? (
            <Brain className="h-5 w-5 text-primary" />
          ) : (
            <Coffee className="h-5 w-5 text-secondary" />
          )}
          <span className="gradient-text">
            {sessionType === 'focus' ? 'Focus Time' : sessionType === 'short_break' ? 'Short Break' : 'Long Break'}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center gap-6">
        {/* Session Type Buttons */}
        <div className="flex gap-2">
          {(['focus', 'short_break', 'long_break'] as SessionType[]).map((type) => (
            <Button
              key={type}
              variant={sessionType === type ? 'default' : 'ghost'}
              size="sm"
              onClick={() => switchSession(type)}
              className={cn(
                'text-xs',
                sessionType === type && 'animate-glow-pulse'
              )}
            >
              {type === 'focus' ? 'Focus' : type === 'short_break' ? 'Short' : 'Long'}
            </Button>
          ))}
        </div>

        {/* Circular Timer */}
        <div className="relative w-64 h-64">
          <svg className="w-full h-full transform -rotate-90">
            {/* Background circle */}
            <circle
              cx="128"
              cy="128"
              r="120"
              fill="none"
              stroke="hsl(var(--muted))"
              strokeWidth="8"
              className="opacity-30"
            />
            {/* Progress circle */}
            <circle
              cx="128"
              cy="128"
              r="120"
              fill="none"
              stroke={getSessionColor()}
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-1000 ease-linear"
              style={{
                filter: isRunning ? `drop-shadow(0 0 10px ${getSessionColor()})` : 'none',
              }}
            />
          </svg>
          
          {/* Timer display */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-5xl font-bold font-display tracking-tight text-shadow-glow">
              {formatTime(timeRemaining)}
            </span>
            <span className="text-sm text-muted-foreground mt-2">
              {completedSessions} sessions completed
            </span>
          </div>

          {/* Pulsing ring when running */}
          {isRunning && (
            <div 
              className="absolute inset-0 rounded-full animate-pulse-ring"
              style={{ 
                border: `2px solid ${getSessionColor()}`,
                opacity: 0.3,
              }}
            />
          )}
        </div>

        {/* Control Buttons */}
        <div className="flex gap-4">
          <Button
            size="lg"
            onClick={isRunning ? pauseSession : startSession}
            className={cn(
              'w-14 h-14 rounded-full transition-all duration-300',
              isRunning ? 'bg-secondary hover:bg-secondary/90' : 'bg-primary hover:bg-primary/90',
              'hover-lift'
            )}
          >
            {isRunning ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-1" />}
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={resetTimer}
            className="w-14 h-14 rounded-full hover-lift"
          >
            <RotateCcw className="h-5 w-5" />
          </Button>
        </div>

        {/* Ambient Sounds */}
        <div className="w-full">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-muted-foreground">Ambient Sounds</span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMuted(!isMuted)}
              className="h-8 w-8"
            >
              {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {AMBIENT_SOUNDS.map((sound) => (
              <Button
                key={sound.id}
                variant={ambientSound === sound.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => setAmbientSound(ambientSound === sound.id ? null : sound.id)}
                className={cn(
                  'flex flex-col gap-1 h-auto py-2',
                  ambientSound === sound.id && 'glow'
                )}
              >
                <span className="text-lg">{sound.icon}</span>
                <span className="text-xs">{sound.label}</span>
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PomodoroTimer;
