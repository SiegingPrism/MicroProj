import { useState, useEffect, useRef, useCallback } from 'react';
import { X, Play, Pause, SkipForward, Volume2, VolumeX, Timer, Maximize2, Minimize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FocusModeProps {
    onClose: () => void;
}

const AMBIENT_LABELS = ['Rain', 'Forest', 'Ocean', 'Silence'];

export default function FocusMode({ onClose }: FocusModeProps) {
    const [minutes, setMinutes] = useState(25);
    const [seconds, setSeconds] = useState(0);
    const [isRunning, setIsRunning] = useState(false);
    const [selectedDuration, setSelectedDuration] = useState(25);
    const [ambientSound, setAmbientSound] = useState<string | null>(null);
    const [isMuted, setIsMuted] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    // Timer logic
    useEffect(() => {
        if (!isRunning) return;
        const interval = setInterval(() => {
            setSeconds(prev => {
                if (prev === 0) {
                    if (minutes === 0) {
                        setIsRunning(false);
                        clearInterval(interval);
                        // Play a gentle notification
                        if (Notification.permission === 'granted') {
                            new Notification('Focus session complete! 🎉', { body: 'Great work! Take a well-deserved break.' });
                        }
                        return 0;
                    }
                    setMinutes(m => m - 1);
                    return 59;
                }
                return prev - 1;
            });
        }, 1000);
        return () => clearInterval(interval);
    }, [isRunning, minutes]);

    const resetTimer = useCallback(() => {
        setMinutes(selectedDuration);
        setSeconds(0);
        setIsRunning(false);
    }, [selectedDuration]);

    const toggleFullscreen = () => {
        if (!document.fullscreenElement) {
            containerRef.current?.requestFullscreen();
            setIsFullscreen(true);
        } else {
            document.exitFullscreen();
            setIsFullscreen(false);
        }
    };

    const progress = 1 - (minutes * 60 + seconds) / (selectedDuration * 60);
    const circumference = 2 * Math.PI * 120;
    const strokeDashoffset = circumference * (1 - progress);

    return (
        <div
            ref={containerRef}
            className="fixed inset-0 z-[100] flex items-center justify-center"
            style={{
                background: 'linear-gradient(160deg, hsl(220 20% 4%) 0%, hsl(220 20% 8%) 50%, hsl(160 30% 6%) 100%)',
            }}
        >
            {/* Gradient orbs */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] rounded-full opacity-10 blur-[120px]"
                    style={{ background: 'hsl(var(--primary))' }} />
                <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] rounded-full opacity-8 blur-[100px]"
                    style={{ background: 'hsl(var(--secondary))' }} />
            </div>

            {/* Close button */}
            <button
                onClick={onClose}
                className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/40 hover:text-white/80 transition-all z-10"
            >
                <X className="w-5 h-5" />
            </button>

            {/* Fullscreen toggle */}
            <button
                onClick={toggleFullscreen}
                className="absolute top-6 right-20 w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/40 hover:text-white/80 transition-all z-10"
            >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <div className="relative z-10 flex flex-col items-center gap-8 max-w-lg mx-auto px-6">
                {/* Timer ring */}
                <div className="relative">
                    <svg width="280" height="280" viewBox="0 0 280 280" className="transform -rotate-90">
                        {/* Background ring */}
                        <circle cx="140" cy="140" r="120" stroke="hsl(0 0% 100% / 0.06)" strokeWidth="6" fill="none" />
                        {/* Progress ring */}
                        <circle
                            cx="140" cy="140" r="120"
                            stroke="url(#focusGradient)"
                            strokeWidth="6"
                            fill="none"
                            strokeLinecap="round"
                            strokeDasharray={circumference}
                            strokeDashoffset={strokeDashoffset}
                            className="transition-all duration-1000"
                        />
                        <defs>
                            <linearGradient id="focusGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stopColor="hsl(160 84% 45%)" />
                                <stop offset="100%" stopColor="hsl(38 92% 55%)" />
                            </linearGradient>
                        </defs>
                    </svg>

                    {/* Timer display */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-6xl font-bold text-white tracking-tight font-mono">
                            {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                        </span>
                        <span className="text-sm text-white/30 mt-1 font-medium">
                            {isRunning ? 'Focusing...' : minutes === 0 && seconds === 0 ? 'Complete! 🎉' : 'Ready'}
                        </span>
                    </div>
                </div>

                {/* Controls */}
                <div className="flex items-center gap-4">
                    <button
                        onClick={() => setIsRunning(!isRunning)}
                        className="w-16 h-16 rounded-full flex items-center justify-center text-white transition-all hover:scale-105 active:scale-95 shadow-2xl"
                        style={{ background: 'linear-gradient(135deg, hsl(160 84% 39%) 0%, hsl(160 70% 32%) 100%)' }}
                    >
                        {isRunning ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
                    </button>
                    <button
                        onClick={resetTimer}
                        className="w-12 h-12 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/50 hover:text-white transition-all"
                    >
                        <SkipForward className="w-5 h-5" />
                    </button>
                </div>

                {/* Duration presets */}
                <div className="flex gap-2">
                    {[15, 25, 45, 60].map(dur => (
                        <button
                            key={dur}
                            onClick={() => { setSelectedDuration(dur); setMinutes(dur); setSeconds(0); setIsRunning(false); }}
                            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${selectedDuration === dur
                                    ? 'bg-white/15 text-white border border-white/20'
                                    : 'text-white/30 hover:text-white/60 hover:bg-white/5'
                                }`}
                        >
                            {dur}m
                        </button>
                    ))}
                </div>

                {/* Ambient sounds */}
                <div className="flex flex-col items-center gap-3">
                    <p className="text-xs text-white/20 font-medium uppercase tracking-widest">Ambient</p>
                    <div className="flex gap-2 items-center">
                        {AMBIENT_LABELS.map(label => (
                            <button
                                key={label}
                                onClick={() => setAmbientSound(ambientSound === label ? null : label)}
                                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${ambientSound === label
                                        ? 'bg-primary/20 text-primary border border-primary/30'
                                        : 'text-white/25 hover:text-white/50 hover:bg-white/5'
                                    }`}
                            >
                                {label}
                            </button>
                        ))}
                        <button
                            onClick={() => setIsMuted(!isMuted)}
                            className="ml-2 text-white/25 hover:text-white/50 transition-colors"
                        >
                            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                        </button>
                    </div>
                </div>

                {/* Motivational text */}
                <p className="text-white/10 text-sm text-center max-w-xs leading-relaxed italic">
                    "The secret of getting ahead is getting started."
                </p>
            </div>
        </div>
    );
}
