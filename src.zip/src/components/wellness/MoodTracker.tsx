import { useState, useEffect } from 'react';
import { Smile, Meh, Frown, Zap, Battery, BatteryLow, BatteryMedium, BatteryFull, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

type Mood = 'great' | 'good' | 'okay' | 'tired' | 'stressed';

const MOODS: { id: Mood; label: string; emoji: string; color: string }[] = [
  { id: 'great', label: 'Great', emoji: '😊', color: 'hsl(160, 84%, 39%)' },
  { id: 'good', label: 'Good', emoji: '🙂', color: 'hsl(140, 70%, 45%)' },
  { id: 'okay', label: 'Okay', emoji: '😐', color: 'hsl(45, 80%, 50%)' },
  { id: 'tired', label: 'Tired', emoji: '😴', color: 'hsl(270, 70%, 50%)' },
  { id: 'stressed', label: 'Stressed', emoji: '😰', color: 'hsl(0, 70%, 55%)' },
];

interface MoodLog {
  id: string;
  mood: Mood;
  energy_level: number;
  logged_at: string;
}

const MoodTracker = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [energyLevel, setEnergyLevel] = useState([3]);
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [recentLogs, setRecentLogs] = useState<MoodLog[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    if (user) {
      fetchRecentLogs();
    }
  }, [user]);

  const fetchRecentLogs = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('mood_logs')
      .select('id, mood, energy_level, logged_at')
      .eq('user_id', user.id)
      .order('logged_at', { ascending: false })
      .limit(7);

    if (!error && data) {
      setRecentLogs(data as MoodLog[]);
    }
  };

  const handleSubmit = async () => {
    if (!user || !selectedMood) return;

    setIsSubmitting(true);

    const { error } = await supabase.from('mood_logs').insert({
      user_id: user.id,
      mood: selectedMood,
      energy_level: energyLevel[0],
      notes: notes || null,
    });

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to log your mood. Please try again.',
        variant: 'destructive',
      });
    } else {
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 2000);
      
      toast({
        title: '✨ Mood logged!',
        description: 'Keep tracking to see your patterns.',
      });
      
      setSelectedMood(null);
      setEnergyLevel([3]);
      setNotes('');
      fetchRecentLogs();
    }

    setIsSubmitting(false);
  };

  const getEnergyIcon = () => {
    const level = energyLevel[0];
    if (level <= 1) return <BatteryLow className="h-5 w-5 text-destructive" />;
    if (level <= 2) return <BatteryMedium className="h-5 w-5 text-yellow-500" />;
    if (level <= 3) return <Battery className="h-5 w-5 text-muted-foreground" />;
    if (level <= 4) return <BatteryMedium className="h-5 w-5 text-primary" />;
    return <BatteryFull className="h-5 w-5 text-primary" />;
  };

  const getEnergyLabel = () => {
    const level = energyLevel[0];
    const labels = ['Very Low', 'Low', 'Moderate', 'Good', 'High'];
    return labels[level - 1];
  };

  return (
    <Card className="glass-morphism border-0 overflow-hidden relative">
      {/* Success animation overlay */}
      {showSuccess && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-10">
          <div className="flex flex-col items-center gap-2 animate-bounce-soft">
            <Sparkles className="h-12 w-12 text-primary animate-spin-slow" />
            <span className="text-lg font-medium gradient-text">Logged!</span>
          </div>
        </div>
      )}

      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          <Smile className="h-5 w-5 text-primary" />
          <span className="gradient-text">How are you feeling?</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Mood Selection */}
        <div className="grid grid-cols-5 gap-2">
          {MOODS.map((mood) => (
            <button
              key={mood.id}
              onClick={() => setSelectedMood(mood.id)}
              className={cn(
                'flex flex-col items-center gap-1 p-3 rounded-xl transition-all duration-300',
                'hover:scale-105 hover-lift',
                selectedMood === mood.id
                  ? 'bg-primary/20 ring-2 ring-primary glow'
                  : 'bg-muted/30 hover:bg-muted/50'
              )}
            >
              <span className="text-2xl">{mood.emoji}</span>
              <span className="text-xs font-medium">{mood.label}</span>
            </button>
          ))}
        </div>

        {/* Energy Level Slider */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">Energy Level</span>
            </div>
            <div className="flex items-center gap-2">
              {getEnergyIcon()}
              <span className="text-sm text-muted-foreground">{getEnergyLabel()}</span>
            </div>
          </div>
          <Slider
            value={energyLevel}
            onValueChange={setEnergyLevel}
            min={1}
            max={5}
            step={1}
            className="py-2"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Exhausted</span>
            <span>Energized</span>
          </div>
        </div>

        {/* Notes */}
        <div className="space-y-2">
          <span className="text-sm font-medium">Quick note (optional)</span>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="What's on your mind?"
            className="resize-none bg-muted/30 border-0 focus:ring-primary"
            rows={2}
          />
        </div>

        {/* Submit Button */}
        <Button
          onClick={handleSubmit}
          disabled={!selectedMood || isSubmitting}
          className="w-full hover-lift"
        >
          {isSubmitting ? (
            <span className="flex items-center gap-2">
              <span className="animate-spin">⏳</span>
              Logging...
            </span>
          ) : (
            'Log Mood'
          )}
        </Button>

        {/* Recent Mood History */}
        {recentLogs.length > 0 && (
          <div className="pt-4 border-t border-border/50">
            <span className="text-sm font-medium text-muted-foreground">Recent Check-ins</span>
            <div className="flex gap-1 mt-2">
              {recentLogs.slice(0, 7).map((log) => {
                const moodData = MOODS.find((m) => m.id === log.mood);
                return (
                  <div
                    key={log.id}
                    className="flex-1 h-8 rounded-lg flex items-center justify-center text-sm transition-all hover:scale-110"
                    style={{ backgroundColor: `${moodData?.color}30` }}
                    title={`${moodData?.label} - ${new Date(log.logged_at).toLocaleDateString()}`}
                  >
                    {moodData?.emoji}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MoodTracker;
