import { useState, useRef, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  RotateCcw, ZoomIn, ZoomOut, Layers, Eye, EyeOff, 
  Download, Maximize2, Move 
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from '@/components/ui/dialog';

interface ARConceptViewerProps {
  imageUrl: string;
  topic: string;
  description?: string;
}

export const ARConceptViewer = ({ imageUrl, topic, description }: ARConceptViewerProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [showLabels, setShowLabels] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [pan, setPan] = useState({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStart.x;
    const dy = e.clientY - dragStart.y;
    setRotation(prev => ({
      x: prev.x + dy * 0.3,
      y: prev.y + dx * 0.3,
    }));
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => setIsDragging(false);

  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    setIsDragging(true);
    setDragStart({ x: touch.clientX, y: touch.clientY });
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    const touch = e.touches[0];
    const dx = touch.clientX - dragStart.x;
    const dy = touch.clientY - dragStart.y;
    setRotation(prev => ({
      x: prev.x + dy * 0.3,
      y: prev.y + dx * 0.3,
    }));
    setDragStart({ x: touch.clientX, y: touch.clientY });
  };

  const resetView = () => {
    setRotation({ x: 0, y: 0 });
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `${topic.replace(/\s+/g, '-').toLowerCase()}-visual.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Card className="p-4 bg-card/50 border-border/50 space-y-3 overflow-hidden">
      {/* Viewer */}
      <div
        ref={containerRef}
        className="relative rounded-lg overflow-hidden bg-background/50 cursor-grab active:cursor-grabbing select-none"
        style={{ perspective: '1000px', minHeight: '280px' }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseUp}
      >
        <div
          className="w-full h-full flex items-center justify-center transition-transform duration-75"
          style={{
            transform: `
              rotateX(${rotation.x}deg) 
              rotateY(${rotation.y}deg) 
              scale(${zoom})
              translate(${pan.x}px, ${pan.y}px)
            `,
            transformStyle: 'preserve-3d',
          }}
        >
          <img
            src={imageUrl}
            alt={`Visual: ${topic}`}
            className="max-h-72 w-auto rounded-lg object-contain"
            draggable={false}
          />

          {/* Overlay labels */}
          {showLabels && (
            <div className="absolute bottom-3 left-3 right-3">
              <div className="glass-morphism rounded-lg px-3 py-2">
                <p className="text-xs font-medium">{topic}</p>
                {description && (
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{description}</p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Drag hint */}
        <div className="absolute top-3 left-3 glass-morphism rounded-full px-2 py-1 flex items-center gap-1 opacity-60">
          <Move className="w-3 h-3" />
          <span className="text-xs">Drag to rotate</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-1 flex-wrap">
        <Button variant="outline" size="sm" onClick={() => setZoom(z => Math.min(3, z + 0.25))} className="text-xs">
          <ZoomIn className="w-3 h-3 mr-1" /> Zoom In
        </Button>
        <Button variant="outline" size="sm" onClick={() => setZoom(z => Math.max(0.25, z - 0.25))} className="text-xs">
          <ZoomOut className="w-3 h-3 mr-1" /> Zoom Out
        </Button>
        <Button variant="outline" size="sm" onClick={() => setShowLabels(!showLabels)} className="text-xs">
          {showLabels ? <EyeOff className="w-3 h-3 mr-1" /> : <Eye className="w-3 h-3 mr-1" />}
          Labels
        </Button>
        <Button variant="outline" size="sm" onClick={resetView} className="text-xs">
          <RotateCcw className="w-3 h-3 mr-1" /> Reset
        </Button>

        <div className="ml-auto flex gap-1">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" className="text-xs">
                <Maximize2 className="w-3 h-3" />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] p-2">
              <img src={imageUrl} alt={`Visual: ${topic}`} className="w-full h-full object-contain" />
            </DialogContent>
          </Dialog>
          <Button variant="ghost" size="sm" onClick={handleDownload} className="text-xs">
            <Download className="w-3 h-3" />
          </Button>
        </div>
      </div>
    </Card>
  );
};
