import { useState, useRef, useEffect, useCallback } from 'react';
import { Volume2, VolumeX, Music, X, ChevronUp, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { cn } from '@/lib/utils';

interface SoundTrack {
    id: string;
    name: string;
    emoji: string;
    color: string;
    // Oscillator config for procedural audio
    type: OscillatorType;
    frequency: number;
    detune: number;
    gainLevel: number;
}

const TRACKS: SoundTrack[] = [
    { id: 'rain', name: 'Rain', emoji: '🌧️', color: 'hsl(200, 70%, 50%)', type: 'sawtooth', frequency: 200, detune: -1200, gainLevel: 0.02 },
    { id: 'ocean', name: 'Ocean Waves', emoji: '🌊', color: 'hsl(190, 80%, 45%)', type: 'sine', frequency: 120, detune: -600, gainLevel: 0.04 },
    { id: 'forest', name: 'Forest', emoji: '🌲', color: 'hsl(140, 60%, 40%)', type: 'triangle', frequency: 300, detune: -800, gainLevel: 0.03 },
    { id: 'fireplace', name: 'Fireplace', emoji: '🔥', color: 'hsl(20, 80%, 50%)', type: 'sawtooth', frequency: 80, detune: -1400, gainLevel: 0.015 },
    { id: 'cafe', name: 'Café', emoji: '☕', color: 'hsl(30, 60%, 45%)', type: 'square', frequency: 250, detune: -1600, gainLevel: 0.008 },
    { id: 'lofi', name: 'Lo-Fi', emoji: '🎵', color: 'hsl(270, 60%, 55%)', type: 'sine', frequency: 440, detune: 0, gainLevel: 0.03 },
];

const AmbientSounds = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [activeTrack, setActiveTrack] = useState<string | null>(null);
    const [volume, setVolume] = useState([50]);
    const [isMinimized, setIsMinimized] = useState(false);
    const audioCtxRef = useRef<AudioContext | null>(null);
    const nodesRef = useRef<{ osc: OscillatorNode; gain: GainNode; noise: AudioBufferSourceNode | null } | null>(null);
    const animFrameRef = useRef<number>(0);
    const [bars, setBars] = useState<number[]>([0.2, 0.5, 0.3, 0.6, 0.4]);

    const stopSound = useCallback(() => {
        if (nodesRef.current) {
            try {
                nodesRef.current.gain.gain.exponentialRampToValueAtTime(0.0001, audioCtxRef.current!.currentTime + 0.5);
                setTimeout(() => {
                    nodesRef.current?.osc.stop();
                    nodesRef.current?.noise?.stop();
                    nodesRef.current = null;
                }, 600);
            } catch { nodesRef.current = null; }
        }
        cancelAnimationFrame(animFrameRef.current);
    }, []);

    const playSound = useCallback((track: SoundTrack) => {
        stopSound();

        const ctx = audioCtxRef.current || new AudioContext();
        audioCtxRef.current = ctx;

        // Create noise buffer for ambient texture
        const bufferSize = ctx.sampleRate * 2;
        const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            output[i] = (Math.random() * 2 - 1) * 0.3;
        }

        const noiseSource = ctx.createBufferSource();
        noiseSource.buffer = noiseBuffer;
        noiseSource.loop = true;

        // Create filter for shaping noise
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = track.frequency;
        filter.Q.value = 0.5;

        // Oscillator for tonal element
        const osc = ctx.createOscillator();
        osc.type = track.type;
        osc.frequency.value = track.frequency;
        osc.detune.value = track.detune;

        // LFO for movement
        const lfo = ctx.createOscillator();
        lfo.frequency.value = 0.1 + Math.random() * 0.2;
        const lfoGain = ctx.createGain();
        lfoGain.gain.value = track.frequency * 0.15;
        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);

        // Main gain node
        const gain = ctx.createGain();
        const vol = (volume[0] / 100) * track.gainLevel;
        gain.gain.value = 0.0001;
        gain.gain.exponentialRampToValueAtTime(Math.max(vol, 0.0001), ctx.currentTime + 1);

        // Noise gain
        const noiseGain = ctx.createGain();
        noiseGain.gain.value = (volume[0] / 100) * 0.04;

        // Connect
        osc.connect(gain);
        noiseSource.connect(filter);
        filter.connect(noiseGain);
        noiseGain.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        lfo.start();
        noiseSource.start();

        nodesRef.current = { osc, gain, noise: noiseSource };

        // Animate bars
        const animate = () => {
            setBars(prev => prev.map(() => 0.15 + Math.random() * 0.85));
            animFrameRef.current = requestAnimationFrame(animate);
        };
        animate();
    }, [volume, stopSound]);

    useEffect(() => {
        return () => {
            stopSound();
            audioCtxRef.current?.close();
        };
    }, [stopSound]);

    // Update volume in real-time
    useEffect(() => {
        if (nodesRef.current && activeTrack) {
            const track = TRACKS.find(t => t.id === activeTrack);
            if (track) {
                const vol = (volume[0] / 100) * track.gainLevel;
                nodesRef.current.gain.gain.setTargetAtTime(Math.max(vol, 0.0001), audioCtxRef.current!.currentTime, 0.1);
            }
        }
    }, [volume, activeTrack]);

    const toggleTrack = (trackId: string) => {
        if (activeTrack === trackId) {
            stopSound();
            setActiveTrack(null);
        } else {
            const track = TRACKS.find(t => t.id === trackId);
            if (track) {
                playSound(track);
                setActiveTrack(trackId);
            }
        }
    };

    const currentTrack = TRACKS.find(t => t.id === activeTrack);

    if (!isOpen) {
        return (
            <button
                onClick={() => setIsOpen(true)}
                className={cn(
                    'fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full flex items-center justify-center',
                    'shadow-lg shadow-primary/20 transition-all duration-300 hover:scale-110',
                    'border border-border/50',
                    activeTrack
                        ? 'bg-primary/20 backdrop-blur-xl'
                        : 'bg-background/80 backdrop-blur-xl hover:bg-primary/10'
                )}
            >
                {activeTrack ? (
                    <div className="relative">
                        <Music className="w-5 h-5 text-primary" />
                        <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-primary rounded-full animate-pulse" />
                    </div>
                ) : (
                    <Music className="w-5 h-5 text-muted-foreground" />
                )}
            </button>
        );
    }

    if (isMinimized && activeTrack) {
        return (
            <div className="fixed bottom-6 right-6 z-50 glass-morphism rounded-2xl p-3 flex items-center gap-3 shadow-xl shadow-primary/10 animate-fade-in">
                <span className="text-lg">{currentTrack?.emoji}</span>
                <span className="text-sm font-medium">{currentTrack?.name}</span>
                <div className="flex items-center gap-0.5 h-5">
                    {bars.map((h, i) => (
                        <div
                            key={i}
                            className="w-1 rounded-full bg-primary transition-all duration-150"
                            style={{ height: `${h * 20}px` }}
                        />
                    ))}
                </div>
                <Button variant="ghost" size="icon" className="w-7 h-7" onClick={() => setIsMinimized(false)}>
                    <ChevronUp className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="w-7 h-7" onClick={() => setIsOpen(false)}>
                    <X className="w-3.5 h-3.5" />
                </Button>
            </div>
        );
    }

    return (
        <div className="fixed bottom-6 right-6 z-50 w-80 glass-morphism rounded-2xl shadow-2xl shadow-primary/10 overflow-hidden animate-fade-in">
            {/* Header */}
            <div className="px-5 py-4 flex items-center justify-between border-b border-border/30">
                <div className="flex items-center gap-2">
                    <Music className="w-4 h-4 text-primary" />
                    <span className="font-bold text-sm">Ambient Sounds</span>
                </div>
                <div className="flex items-center gap-1">
                    {activeTrack && (
                        <Button variant="ghost" size="icon" className="w-7 h-7" onClick={() => setIsMinimized(true)}>
                            <ChevronDown className="w-4 h-4" />
                        </Button>
                    )}
                    <Button variant="ghost" size="icon" className="w-7 h-7" onClick={() => setIsOpen(false)}>
                        <X className="w-3.5 h-3.5" />
                    </Button>
                </div>
            </div>

            {/* Sound Grid */}
            <div className="p-4 grid grid-cols-3 gap-2">
                {TRACKS.map(track => (
                    <button
                        key={track.id}
                        onClick={() => toggleTrack(track.id)}
                        className={cn(
                            'flex flex-col items-center gap-1.5 p-3 rounded-xl transition-all duration-300',
                            'hover:scale-105',
                            activeTrack === track.id
                                ? 'bg-primary/20 ring-2 ring-primary/50 shadow-md'
                                : 'bg-muted/30 hover:bg-muted/50'
                        )}
                    >
                        <span className="text-2xl">{track.emoji}</span>
                        <span className="text-[11px] font-medium">{track.name}</span>
                        {activeTrack === track.id && (
                            <div className="flex items-center gap-0.5 h-3">
                                {bars.slice(0, 3).map((h, i) => (
                                    <div
                                        key={i}
                                        className="w-0.5 rounded-full bg-primary transition-all duration-150"
                                        style={{ height: `${h * 12}px` }}
                                    />
                                ))}
                            </div>
                        )}
                    </button>
                ))}
            </div>

            {/* Volume Control */}
            <div className="px-5 pb-4 flex items-center gap-3">
                {volume[0] === 0 ? (
                    <VolumeX className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                ) : (
                    <Volume2 className="w-4 h-4 text-primary flex-shrink-0" />
                )}
                <Slider
                    value={volume}
                    onValueChange={setVolume}
                    min={0}
                    max={100}
                    step={1}
                    className="flex-1"
                />
                <span className="text-xs text-muted-foreground w-8 text-right">{volume[0]}%</span>
            </div>

            {/* Now Playing */}
            {activeTrack && currentTrack && (
                <div className="px-5 pb-4">
                    <div className="rounded-xl p-3 flex items-center gap-3"
                        style={{ background: `${currentTrack.color}15`, border: `1px solid ${currentTrack.color}30` }}>
                        <span className="text-xl">{currentTrack.emoji}</span>
                        <div className="flex-1">
                            <p className="text-sm font-medium">Now Playing</p>
                            <p className="text-xs text-muted-foreground">{currentTrack.name}</p>
                        </div>
                        <div className="flex items-end gap-0.5 h-5">
                            {bars.map((h, i) => (
                                <div
                                    key={i}
                                    className="w-1 rounded-full transition-all duration-200"
                                    style={{ height: `${h * 20}px`, backgroundColor: currentTrack.color }}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AmbientSounds;
