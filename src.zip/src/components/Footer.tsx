import { Link } from 'react-router-dom';
import { Brain, Twitter, Github, Linkedin, Mail } from 'lucide-react';

const Footer = () => {
    return (
        <footer className="border-t border-white/5 bg-background relative overflow-hidden">
            <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
            <div className="max-w-7xl mx-auto px-6 py-12 lg:py-16 relative z-10">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-12 lg:gap-8">

                    {/* Brand Section */}
                    <div className="col-span-1 md:col-span-2">
                        <Link to="/" className="flex items-center gap-3 group inline-flex mb-6">
                            <div
                                className="w-10 h-10 rounded-xl flex items-center justify-center relative overflow-hidden"
                                style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}
                            >
                                <Brain className="w-6 h-6 text-white relative z-10" />
                            </div>
                            <span className="font-bold text-xl tracking-tight text-foreground">
                                Study<span className="text-primary">AI</span>
                            </span>
                        </Link>
                        <p className="text-muted-foreground mb-6 max-w-sm">
                            Your personal AI-powered learning companion. Transform how you learn, understand complex questions, and personalize your journey.
                        </p>
                        <div className="flex gap-4">
                            <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-muted-foreground hover:bg-primary/10 hover:text-primary transition-colors border border-white/5">
                                <Twitter className="w-5 h-5" />
                            </a>
                            <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-muted-foreground hover:bg-primary/10 hover:text-primary transition-colors border border-white/5">
                                <Github className="w-5 h-5" />
                            </a>
                            <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-muted-foreground hover:bg-primary/10 hover:text-primary transition-colors border border-white/5">
                                <Linkedin className="w-5 h-5" />
                            </a>
                        </div>
                    </div>

                    {/* Links Section */}
                    <div>
                        <h3 className="font-semibold text-foreground mb-6">Product</h3>
                        <ul className="space-y-4">
                            <li><Link to="/chat" className="text-muted-foreground hover:text-primary transition-colors">AI Chat</Link></li>
                            <li><Link to="/tools" className="text-muted-foreground hover:text-primary transition-colors">Study Tools</Link></li>
                            <li><Link to="/flashcards" className="text-muted-foreground hover:text-primary transition-colors">Flashcards</Link></li>
                            <li><Link to="/notes" className="text-muted-foreground hover:text-primary transition-colors">Notebook</Link></li>
                            <li><Link to="/leaderboard" className="text-muted-foreground hover:text-primary transition-colors">Leaderboard</Link></li>
                        </ul>
                    </div>

                    <div>
                        <h3 className="font-semibold text-foreground mb-6">Company</h3>
                        <ul className="space-y-4">
                            <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">About Us</a></li>
                            <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Careers</a></li>
                            <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Privacy Policy</a></li>
                            <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Terms of Service</a></li>
                        </ul>
                    </div>

                </div>

                <div className="border-t border-white/10 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between text-sm text-muted-foreground">
                    <p>© {new Date().getFullYear()} StudyAI. All rights reserved.</p>
                    <div className="flex items-center gap-2 mt-4 md:mt-0">
                        <Mail className="w-4 h-4" />
                        <a href="mailto:hello@studyai.com" className="hover:text-primary transition-colors">hello@studyai.com</a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
