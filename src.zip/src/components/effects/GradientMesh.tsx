/**
 * GradientMesh – a smooth, GPU-friendly animated background mesh
 * that replaces the old ParticleBackground.
 */
const GradientMesh = () => (
    <div className="gradient-mesh" aria-hidden="true">
        <div className="mesh-orb" />
        <div className="mesh-orb" />
        <div className="mesh-orb" />
    </div>
);

export default GradientMesh;
