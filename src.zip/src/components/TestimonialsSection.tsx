import { useState, useEffect, useRef } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
    {
        name: 'Priya Sharma',
        role: 'Computer Science, IIT Delhi',
        avatar: 'PS',
        rating: 5,
        text: 'StudyAI completely transformed how I prepare for exams. The AI chat understands context perfectly and the flashcard system with spaced repetition helped me ace my algorithms course.',
        color: 'from-emerald-500/20 to-teal-500/20',
    },
    {
        name: 'Alex Chen',
        role: 'MBA Student, Stanford',
        avatar: 'AC',
        rating: 5,
        text: 'The focus mode timer is a game-changer. Combined with the daily streak system, I went from studying 30 minutes to 3 hours daily. My GPA improved by a full point.',
        color: 'from-amber-500/20 to-orange-500/20',
    },
    {
        name: 'Sarah Williams',
        role: 'Pre-Med, Johns Hopkins',
        avatar: 'SW',
        rating: 5,
        text: "I use the notebook feature to consolidate my biology notes and the AI explains complex concepts in ways my textbook can't. It's like having a private tutor available 24/7.",
        color: 'from-rose-500/20 to-pink-500/20',
    },
    {
        name: 'James Rodriguez',
        role: 'High School Senior',
        avatar: 'JR',
        rating: 5,
        text: 'Preparing for SATs was overwhelming until I found StudyAI. The study planner organized my prep schedule perfectly, and I scored in the 99th percentile!',
        color: 'from-violet-500/20 to-purple-500/20',
    },
    {
        name: 'Aisha Patel',
        role: 'Engineering, MIT',
        avatar: 'AP',
        rating: 5,
        text: "The document summarizer saves me hours every week. Upload a 50-page paper, get key insights in seconds. Plus the leaderboard keeps me motivated to stay consistent.",
        color: 'from-teal-500/20 to-cyan-500/20',
    },
    {
        name: 'David Kim',
        role: 'Law Student, Yale',
        avatar: 'DK',
        rating: 4,
        text: 'Reading case law used to take forever. Now I upload cases to StudyAI, get summaries, create flashcards, and quiz myself — all in one platform. Absolute lifesaver.',
        color: 'from-sky-500/20 to-blue-500/20',
    },
];

const TestimonialsSection = () => {
    const [activeIndex, setActiveIndex] = useState(0);
    const [isAutoPlaying, setIsAutoPlaying] = useState(true);
    const intervalRef = useRef<NodeJS.Timeout | null>(null);

    const visibleCount = 3; // Cards visible at once on desktop
    const maxIndex = testimonials.length - visibleCount;

    useEffect(() => {
        if (isAutoPlaying) {
            intervalRef.current = setInterval(() => {
                setActiveIndex(prev => (prev >= maxIndex ? 0 : prev + 1));
            }, 4000);
        }
        return () => {
            if (intervalRef.current) clearInterval(intervalRef.current);
        };
    }, [isAutoPlaying, maxIndex]);

    const handlePrev = () => {
        setIsAutoPlaying(false);
        setActiveIndex(prev => (prev <= 0 ? maxIndex : prev - 1));
    };

    const handleNext = () => {
        setIsAutoPlaying(false);
        setActiveIndex(prev => (prev >= maxIndex ? 0 : prev + 1));
    };

    return (
        <section className="py-24 px-6 relative overflow-hidden">
            {/* Background accents */}
            <div className="absolute top-1/3 left-0 w-[500px] h-[500px] rounded-full opacity-[0.04] blur-[120px]"
                style={{ background: 'hsl(var(--secondary))' }} />
            <div className="absolute bottom-1/3 right-0 w-[400px] h-[400px] rounded-full opacity-[0.04] blur-[100px]"
                style={{ background: 'hsl(var(--primary))' }} />

            <div className="max-w-7xl mx-auto relative z-10">
                {/* Section header */}
                <div className="text-center mb-16">
                    <div
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-secondary/25 mb-5"
                        style={{ background: 'hsl(var(--secondary) / 0.08)' }}
                    >
                        <Quote className="w-3.5 h-3.5 text-secondary" />
                        <span className="text-sm font-medium text-secondary/80">Loved by Students</span>
                    </div>
                    <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-4">
                        What our students{' '}
                        <span
                            style={{
                                background: 'linear-gradient(135deg, hsl(var(--secondary)) 0%, hsl(var(--accent)) 100%)',
                                WebkitBackgroundClip: 'text',
                                WebkitTextFillColor: 'transparent',
                                backgroundClip: 'text',
                            }}
                        >
                            are saying
                        </span>
                    </h2>
                    <p className="text-muted-foreground text-lg max-w-xl mx-auto">
                        Join thousands of students who've transformed their learning journey.
                    </p>
                </div>

                {/* Testimonial cards */}
                <div className="relative">
                    <div className="overflow-hidden">
                        <div
                            className="flex gap-5 transition-transform duration-700 ease-out"
                            style={{ transform: `translateX(-${activeIndex * (100 / visibleCount + 1.5)}%)` }}
                        >
                            {testimonials.map((t, i) => (
                                <div
                                    key={i}
                                    className="min-w-[calc(33.333%-14px)] flex-shrink-0 max-md:min-w-[calc(100%-16px)]"
                                >
                                    <div className="bento-card h-full noise-overlay group hover:!border-primary/20 transition-all duration-300">
                                        <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${t.color}`} />

                                        {/* Stars */}
                                        <div className="flex gap-0.5 mb-4">
                                            {Array.from({ length: 5 }).map((_, j) => (
                                                <Star
                                                    key={j}
                                                    className={`w-4 h-4 ${j < t.rating ? 'text-amber-400 fill-amber-400' : 'text-muted-foreground/20'}`}
                                                />
                                            ))}
                                        </div>

                                        {/* Quote */}
                                        <p className="text-sm text-foreground/80 leading-relaxed mb-6 line-clamp-4">
                                            "{t.text}"
                                        </p>

                                        {/* Author */}
                                        <div className="flex items-center gap-3 mt-auto">
                                            <div
                                                className="w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold text-white"
                                                style={{
                                                    background: `linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)`,
                                                }}
                                            >
                                                {t.avatar}
                                            </div>
                                            <div>
                                                <p className="font-semibold text-sm">{t.name}</p>
                                                <p className="text-xs text-muted-foreground">{t.role}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Navigation */}
                    <div className="flex items-center justify-center gap-4 mt-8">
                        <button
                            onClick={handlePrev}
                            className="w-10 h-10 rounded-full bg-muted/50 hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors border border-border"
                        >
                            <ChevronLeft className="w-4 h-4" />
                        </button>

                        {/* Dots */}
                        <div className="flex gap-2">
                            {Array.from({ length: maxIndex + 1 }).map((_, i) => (
                                <button
                                    key={i}
                                    onClick={() => { setActiveIndex(i); setIsAutoPlaying(false); }}
                                    className={`h-2 rounded-full transition-all duration-300 ${i === activeIndex
                                            ? 'w-8 bg-primary'
                                            : 'w-2 bg-muted-foreground/20 hover:bg-muted-foreground/40'
                                        }`}
                                />
                            ))}
                        </div>

                        <button
                            onClick={handleNext}
                            className="w-10 h-10 rounded-full bg-muted/50 hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors border border-border"
                        >
                            <ChevronRight className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default TestimonialsSection;
