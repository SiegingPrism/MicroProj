import { useState, useEffect } from 'react';
import { Bookmark, BookmarkCheck, Search, Trash2, ExternalLink, Filter, BookOpen, MessageCircle, Brain, FileText, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

export interface BookmarkItem {
    id: string;
    type: 'chat' | 'flashcard' | 'quiz' | 'note' | 'topic';
    title: string;
    content: string;
    createdAt: string;
    tags?: string[];
}

const STORAGE_KEY = 'studyai_bookmarks';

const TYPE_CONFIG: Record<string, { icon: React.ElementType; color: string; label: string }> = {
    chat: { icon: MessageCircle, color: 'hsl(200, 80%, 50%)', label: 'Chat' },
    flashcard: { icon: BookOpen, color: 'hsl(160, 70%, 45%)', label: 'Flashcard' },
    quiz: { icon: Brain, color: 'hsl(270, 70%, 55%)', label: 'Quiz' },
    note: { icon: FileText, color: 'hsl(45, 80%, 50%)', label: 'Note' },
    topic: { icon: BookOpen, color: 'hsl(340, 60%, 50%)', label: 'Topic' },
};

// Helper to add bookmarks from anywhere
export const addBookmark = (item: Omit<BookmarkItem, 'id' | 'createdAt'>) => {
    const bookmarks = getBookmarks();
    const newBookmark: BookmarkItem = {
        ...item,
        id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
        createdAt: new Date().toISOString(),
    };
    bookmarks.unshift(newBookmark);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookmarks));
    window.dispatchEvent(new CustomEvent('bookmark-updated'));
    return newBookmark;
};

export const getBookmarks = (): BookmarkItem[] => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch {
        return [];
    }
};

export const removeBookmark = (id: string) => {
    const bookmarks = getBookmarks().filter(b => b.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookmarks));
    window.dispatchEvent(new CustomEvent('bookmark-updated'));
};

const BookmarkSystem = () => {
    const [bookmarks, setBookmarks] = useState<BookmarkItem[]>(getBookmarks);
    const [search, setSearch] = useState('');
    const [filterType, setFilterType] = useState<string | null>(null);
    const [expandedId, setExpandedId] = useState<string | null>(null);

    useEffect(() => {
        const handler = () => setBookmarks(getBookmarks());
        window.addEventListener('bookmark-updated', handler);
        return () => window.removeEventListener('bookmark-updated', handler);
    }, []);

    // Seed demo bookmarks if empty
    useEffect(() => {
        if (bookmarks.length === 0) {
            const demos: Omit<BookmarkItem, 'id' | 'createdAt'>[] = [
                { type: 'chat', title: 'How neural networks learn', content: 'Neural networks learn through backpropagation, adjusting weights by computing gradients of the loss function...', tags: ['AI', 'ML'] },
                { type: 'flashcard', title: 'Photosynthesis equation', content: '6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂. Plants convert carbon dioxide and water into glucose and oxygen.', tags: ['Biology'] },
                { type: 'quiz', title: 'Data Structures Quiz #3', content: 'Score: 8/10. Missed: Binary tree traversal (inorder vs preorder) and hash collision resolution.', tags: ['CS'] },
                { type: 'note', title: 'Chapter 5 Summary - Macro Economics', content: 'GDP = C + I + G + (X-M). Key concepts: inflation, unemployment, fiscal/monetary policy trade-offs.', tags: ['Economics'] },
                { type: 'topic', title: 'React Hooks Deep Dive', content: 'useState, useEffect, useCallback, useMemo, useRef. Custom hooks for reusable state logic.', tags: ['Web Dev'] },
            ];
            demos.forEach(d => addBookmark(d));
        }
    }, []);

    const filtered = bookmarks.filter(b => {
        const matchesSearch = !search || b.title.toLowerCase().includes(search.toLowerCase()) || b.content.toLowerCase().includes(search.toLowerCase());
        const matchesType = !filterType || b.type === filterType;
        return matchesSearch && matchesType;
    });

    const handleDelete = (id: string) => {
        removeBookmark(id);
        setBookmarks(getBookmarks());
    };

    const typeFilters = Object.entries(TYPE_CONFIG).map(([key, config]) => ({
        key,
        ...config,
        count: bookmarks.filter(b => b.type === key).length,
    })).filter(f => f.count > 0);

    return (
        <div className="glass-morphism rounded-2xl overflow-hidden">
            {/* Header */}
            <div className="px-5 py-4 border-b border-border/30">
                <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                        <Bookmark className="w-5 h-5 text-primary" />
                        <h3 className="font-bold text-lg">
                            <span className="gradient-text">Bookmarks</span>
                        </h3>
                        <span className="text-xs bg-muted/50 px-2 py-0.5 rounded-full text-muted-foreground">
                            {bookmarks.length}
                        </span>
                    </div>
                </div>

                {/* Search */}
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        placeholder="Search bookmarks..."
                        className="pl-9 bg-muted/30 border-0 h-9 text-sm"
                    />
                    {search && (
                        <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2">
                            <X className="w-3.5 h-3.5 text-muted-foreground" />
                        </button>
                    )}
                </div>

                {/* Type filters */}
                {typeFilters.length > 1 && (
                    <div className="flex gap-1.5 mt-3 flex-wrap">
                        <button
                            onClick={() => setFilterType(null)}
                            className={cn(
                                'px-2.5 py-1 rounded-lg text-xs font-medium transition-all',
                                !filterType ? 'bg-primary/20 text-primary' : 'bg-muted/30 text-muted-foreground hover:bg-muted/50'
                            )}
                        >
                            All
                        </button>
                        {typeFilters.map(f => {
                            const Icon = f.icon;
                            return (
                                <button
                                    key={f.key}
                                    onClick={() => setFilterType(filterType === f.key ? null : f.key)}
                                    className={cn(
                                        'flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-all',
                                        filterType === f.key ? 'bg-primary/20 text-primary' : 'bg-muted/30 text-muted-foreground hover:bg-muted/50'
                                    )}
                                >
                                    <Icon className="w-3 h-3" />
                                    {f.label} ({f.count})
                                </button>
                            );
                        })}
                    </div>
                )}
            </div>

            {/* Bookmarks List */}
            <div className="max-h-[400px] overflow-y-auto">
                {filtered.length === 0 ? (
                    <div className="py-12 text-center">
                        <BookmarkCheck className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
                        <p className="text-sm text-muted-foreground">
                            {search ? 'No bookmarks match your search' : 'No bookmarks yet'}
                        </p>
                    </div>
                ) : (
                    <div className="p-3 space-y-2">
                        {filtered.map(bookmark => {
                            const config = TYPE_CONFIG[bookmark.type];
                            const Icon = config.icon;
                            const isExpanded = expandedId === bookmark.id;

                            return (
                                <div
                                    key={bookmark.id}
                                    className={cn(
                                        'rounded-xl p-3.5 transition-all duration-300 cursor-pointer',
                                        'bg-muted/20 border border-border/30 hover:border-border/60',
                                        isExpanded && 'bg-muted/30 border-primary/20'
                                    )}
                                    onClick={() => setExpandedId(isExpanded ? null : bookmark.id)}
                                >
                                    <div className="flex items-start gap-3">
                                        <div
                                            className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                                            style={{ backgroundColor: `${config.color}15`, border: `1px solid ${config.color}25` }}
                                        >
                                            <Icon className="w-4 h-4" style={{ color: config.color }} />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-center gap-2 mb-1">
                                                <h4 className="font-medium text-sm truncate">{bookmark.title}</h4>
                                                <span
                                                    className="text-[10px] px-1.5 py-0.5 rounded-full font-medium flex-shrink-0"
                                                    style={{ backgroundColor: `${config.color}15`, color: config.color }}
                                                >
                                                    {config.label}
                                                </span>
                                            </div>
                                            <p className={cn('text-xs text-muted-foreground', !isExpanded && 'line-clamp-2')}>
                                                {bookmark.content}
                                            </p>
                                            {isExpanded && (
                                                <div className="mt-3 flex items-center gap-2 animate-fade-in">
                                                    <span className="text-[10px] text-muted-foreground">
                                                        {new Date(bookmark.createdAt).toLocaleDateString()}
                                                    </span>
                                                    {bookmark.tags && bookmark.tags.map(tag => (
                                                        <span key={tag} className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">
                                                            {tag}
                                                        </span>
                                                    ))}
                                                    <button
                                                        onClick={e => { e.stopPropagation(); handleDelete(bookmark.id); }}
                                                        className="ml-auto text-muted-foreground hover:text-destructive transition-colors"
                                                    >
                                                        <Trash2 className="w-3.5 h-3.5" />
                                                    </button>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
};

export default BookmarkSystem;
