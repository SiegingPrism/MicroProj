import { useState } from 'react';
import { Check, Sparkles, Zap, Crown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const plans = [
    {
        name: 'Free',
        icon: Sparkles,
        monthlyPrice: 0,
        yearlyPrice: 0,
        description: 'Perfect for getting started',
        features: [
            '10 AI chat messages / day',
            'Basic flashcard decks',
            'Daily streak tracking',
            'Community study rooms',
            '1 notebook',
        ],
        cta: 'Get Started Free',
        popular: false,
        gradient: 'from-muted/50 to-muted/30',
        borderClass: 'border-border',
    },
    {
        name: 'Pro',
        icon: Zap,
        monthlyPrice: 12,
        yearlyPrice: 8,
        description: 'For serious students',
        features: [
            'Unlimited AI chat messages',
            'Unlimited flashcard decks',
            'Advanced spaced repetition',
            'Focus mode with ambient sounds',
            'Document summarizer',
            'AI study planner',
            'Priority support',
            'All badges & achievements',
        ],
        cta: 'Start 7-Day Free Trial',
        popular: true,
        gradient: 'from-primary/10 to-secondary/10',
        borderClass: 'border-primary/30',
    },
    {
        name: 'Team',
        icon: Crown,
        monthlyPrice: 29,
        yearlyPrice: 20,
        description: 'For study groups & schools',
        features: [
            'Everything in Pro',
            'Up to 25 team members',
            'Shared flashcard decks',
            'Group study rooms',
            'Team analytics dashboard',
            'Admin controls',
            'Bulk import/export',
            'Dedicated support',
        ],
        cta: 'Contact Sales',
        popular: false,
        gradient: 'from-secondary/10 to-accent/10',
        borderClass: 'border-border',
    },
];

const PricingSection = () => {
    const [isYearly, setIsYearly] = useState(false);

    return (
        <section className="py-24 px-6 relative overflow-hidden">
            {/* Background accents */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full opacity-[0.03] blur-[150px]"
                style={{ background: 'hsl(var(--primary))' }} />

            <div className="max-w-6xl mx-auto relative z-10">
                {/* Section header */}
                <div className="text-center mb-14">
                    <div
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/25 mb-5"
                        style={{ background: 'hsl(var(--primary) / 0.08)' }}
                    >
                        <Zap className="w-3.5 h-3.5 text-primary" />
                        <span className="text-sm font-medium text-primary/80">Simple Pricing</span>
                    </div>
                    <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-4">
                        Choose your{' '}
                        <span
                            style={{
                                background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)',
                                WebkitBackgroundClip: 'text',
                                WebkitTextFillColor: 'transparent',
                                backgroundClip: 'text',
                            }}
                        >
                            study plan
                        </span>
                    </h2>
                    <p className="text-muted-foreground text-lg max-w-xl mx-auto mb-8">
                        Start free, upgrade when you need more. No hidden fees.
                    </p>

                    {/* Billing toggle */}
                    <div className="inline-flex items-center gap-3 p-1.5 rounded-full border border-border bg-muted/30">
                        <button
                            onClick={() => setIsYearly(false)}
                            className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${!isYearly
                                    ? 'bg-white dark:bg-white/10 text-foreground shadow-sm'
                                    : 'text-muted-foreground hover:text-foreground'
                                }`}
                        >
                            Monthly
                        </button>
                        <button
                            onClick={() => setIsYearly(true)}
                            className={`px-5 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2 ${isYearly
                                    ? 'bg-white dark:bg-white/10 text-foreground shadow-sm'
                                    : 'text-muted-foreground hover:text-foreground'
                                }`}
                        >
                            Yearly
                            <span className="text-[10px] font-bold bg-primary/20 text-primary px-2 py-0.5 rounded-full">
                                Save 33%
                            </span>
                        </button>
                    </div>
                </div>

                {/* Pricing cards */}
                <div className="grid md:grid-cols-3 gap-6">
                    {plans.map((plan) => {
                        const price = isYearly ? plan.yearlyPrice : plan.monthlyPrice;
                        return (
                            <div
                                key={plan.name}
                                className={`bento-card relative noise-overlay transition-all duration-300 hover:scale-[1.02] ${plan.popular ? '!border-primary/40 shadow-lg shadow-primary/10 md:-translate-y-2' : ''
                                    }`}
                            >
                                {/* Popular badge */}
                                {plan.popular && (
                                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                                        <span
                                            className="text-[11px] font-bold text-white px-4 py-1.5 rounded-full shadow-lg"
                                            style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)' }}
                                        >
                                            Most Popular
                                        </span>
                                    </div>
                                )}

                                {/* Top gradient bar */}
                                <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${plan.gradient}`} />

                                {/* Header */}
                                <div className="mb-6">
                                    <div className="flex items-center gap-3 mb-3">
                                        <div
                                            className={`w-10 h-10 rounded-xl flex items-center justify-center ${plan.popular ? 'bg-primary/15' : 'bg-muted/50'
                                                }`}
                                        >
                                            <plan.icon className={`w-5 h-5 ${plan.popular ? 'text-primary' : 'text-muted-foreground'}`} />
                                        </div>
                                        <h3 className="text-xl font-bold">{plan.name}</h3>
                                    </div>
                                    <p className="text-sm text-muted-foreground">{plan.description}</p>
                                </div>

                                {/* Price */}
                                <div className="mb-6">
                                    <div className="flex items-baseline gap-1">
                                        <span className="text-4xl font-extrabold">
                                            {price === 0 ? 'Free' : `$${price}`}
                                        </span>
                                        {price > 0 && (
                                            <span className="text-sm text-muted-foreground">/mo</span>
                                        )}
                                    </div>
                                    {isYearly && price > 0 && (
                                        <p className="text-xs text-muted-foreground mt-1">
                                            Billed ${price * 12}/year
                                        </p>
                                    )}
                                </div>

                                {/* Features */}
                                <ul className="space-y-3 mb-8">
                                    {plan.features.map((feature) => (
                                        <li key={feature} className="flex items-start gap-2.5 text-sm">
                                            <Check className={`w-4 h-4 mt-0.5 shrink-0 ${plan.popular ? 'text-primary' : 'text-muted-foreground'}`} />
                                            <span className="text-foreground/80">{feature}</span>
                                        </li>
                                    ))}
                                </ul>

                                {/* CTA */}
                                <Link to="/auth">
                                    <Button
                                        className={`w-full h-11 rounded-xl font-semibold transition-all ${plan.popular
                                                ? 'text-white shadow-lg shadow-primary/20 hover:opacity-90'
                                                : 'hover:bg-muted'
                                            }`}
                                        variant={plan.popular ? 'default' : 'outline'}
                                        style={
                                            plan.popular
                                                ? { background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(160 70% 32%) 100%)' }
                                                : {}
                                        }
                                    >
                                        {plan.cta}
                                    </Button>
                                </Link>
                            </div>
                        );
                    })}
                </div>

                {/* Bottom note */}
                <p className="text-center text-sm text-muted-foreground mt-10">
                    All plans include a 7-day money-back guarantee. No credit card required for Free plan.
                </p>
            </div>
        </section>
    );
};

export default PricingSection;
