import { useState, useEffect } from 'react';
import { Flame, Target, Trophy, Calendar } from 'lucide-react';

interface StreakData {
    currentStreak: number;
    longestStreak: number;
    lastStudyDate: string | null; // ISO date string (YYYY-MM-DD)
    totalDays: number;
    dailyGoalMinutes: number;
    todayMinutes: number;
    weekHistory: boolean[]; // last 7 days, true = studied
}

const STORAGE_KEY = 'studyai_streak_data';
const today = () => new Date().toISOString().split('T')[0];

const loadStreak = (): StreakData => {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
            const data = JSON.parse(stored) as StreakData;
            // Reset streak if missed a day
            const lastDate = data.lastStudyDate;
            if (lastDate) {
                const diff = Math.floor((Date.now() - new Date(lastDate).getTime()) / 86400000);
                if (diff > 1) {
                    data.currentStreak = 0;
                    // Shift week history
                    const shifts = Math.min(diff, 7);
                    data.weekHistory = [...Array(shifts).fill(false), ...data.weekHistory].slice(0, 7);
                }
                if (lastDate !== today()) {
                    data.todayMinutes = 0;
                }
            }
            return data;
        }
    } catch { }
    return {
        currentStreak: 0,
        longestStreak: 0,
        lastStudyDate: null,
        totalDays: 0,
        dailyGoalMinutes: 30,
        todayMinutes: 0,
        weekHistory: [false, false, false, false, false, false, false],
    };
};

const saveStreak = (data: StreakData) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};

export default function DailyStreak() {
    const [streak, setStreak] = useState<StreakData>(loadStreak);

    // Log study time - call this whenever user studies
    const logStudyTime = (minutes: number) => {
        setStreak(prev => {
            const isNewDay = prev.lastStudyDate !== today();
            const updated: StreakData = {
                ...prev,
                todayMinutes: prev.todayMinutes + minutes,
                lastStudyDate: today(),
                currentStreak: isNewDay ? prev.currentStreak + 1 : prev.currentStreak,
                totalDays: isNewDay ? prev.totalDays + 1 : prev.totalDays,
                weekHistory: isNewDay
                    ? [true, ...prev.weekHistory.slice(0, 6)]
                    : [true, ...prev.weekHistory.slice(1)],
            };
            updated.longestStreak = Math.max(updated.longestStreak, updated.currentStreak);
            saveStreak(updated);
            return updated;
        });
    };

    // Auto-log 1 min every 60 seconds while page is open (simulates active study detection)
    useEffect(() => {
        const interval = setInterval(() => logStudyTime(1), 60000);
        // Log initial visit
        if (streak.lastStudyDate !== today()) {
            logStudyTime(0); // just mark the day
        }
        return () => clearInterval(interval);
    }, []);

    const goalProgress = Math.min(100, Math.round((streak.todayMinutes / streak.dailyGoalMinutes) * 100));
    const goalReached = goalProgress >= 100;

    const dayLabels = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    const todayDay = new Date().getDay();
    const reorderedDays = Array.from({ length: 7 }, (_, i) => {
        const dayIdx = (todayDay - 6 + i + 7) % 7;
        return { label: dayLabels[dayIdx], active: streak.weekHistory[6 - i] };
    });

    return (
        <div className="bento-card noise-overlay">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500/60 to-rose-500/60" />

            <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center">
                    <Flame className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                    <h3 className="font-bold text-lg">Daily Streak</h3>
                    <p className="text-xs text-muted-foreground">Keep your momentum going!</p>
                </div>
            </div>

            {/* Streak stats */}
            <div className="grid grid-cols-3 gap-3 mb-5">
                <div className="text-center p-3 rounded-xl bg-amber-500/10 border border-amber-500/15">
                    <Flame className="w-5 h-5 mx-auto mb-1 text-amber-400" />
                    <p className="text-2xl font-extrabold text-amber-400">{streak.currentStreak}</p>
                    <p className="text-[10px] text-muted-foreground font-medium">Current</p>
                </div>
                <div className="text-center p-3 rounded-xl bg-rose-500/10 border border-rose-500/15">
                    <Trophy className="w-5 h-5 mx-auto mb-1 text-rose-400" />
                    <p className="text-2xl font-extrabold text-rose-400">{streak.longestStreak}</p>
                    <p className="text-[10px] text-muted-foreground font-medium">Best</p>
                </div>
                <div className="text-center p-3 rounded-xl bg-primary/10 border border-primary/15">
                    <Calendar className="w-5 h-5 mx-auto mb-1 text-primary" />
                    <p className="text-2xl font-extrabold text-primary">{streak.totalDays}</p>
                    <p className="text-[10px] text-muted-foreground font-medium">Total</p>
                </div>
            </div>

            {/* Daily goal progress */}
            <div className="mb-5">
                <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                        <Target className="w-4 h-4 text-primary" />
                        <span className="text-sm font-medium">Daily Goal</span>
                    </div>
                    <span className={`text-sm font-bold ${goalReached ? 'text-primary' : 'text-muted-foreground'}`}>
                        {streak.todayMinutes}m / {streak.dailyGoalMinutes}m
                    </span>
                </div>
                <div className="w-full h-2.5 bg-muted rounded-full overflow-hidden">
                    <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{
                            width: `${goalProgress}%`,
                            background: goalReached
                                ? 'linear-gradient(90deg, hsl(var(--primary)), hsl(var(--secondary)))'
                                : 'linear-gradient(90deg, hsl(var(--primary) / 0.6), hsl(var(--primary)))',
                        }}
                    />
                </div>
                {goalReached && (
                    <p className="text-xs text-primary font-medium mt-1.5 animate-fade-in">🎉 Daily goal reached!</p>
                )}
            </div>

            {/* Week view */}
            <div>
                <p className="text-xs text-muted-foreground font-medium mb-2">Last 7 days</p>
                <div className="flex gap-2 justify-between">
                    {reorderedDays.map((day, i) => (
                        <div key={i} className="flex flex-col items-center gap-1">
                            <div
                                className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold transition-all ${day.active
                                        ? 'bg-primary/20 text-primary border border-primary/30'
                                        : 'bg-muted/50 text-muted-foreground border border-transparent'
                                    }`}
                            >
                                {day.active ? '✓' : day.label}
                            </div>
                            <span className="text-[9px] text-muted-foreground">{day.label}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
