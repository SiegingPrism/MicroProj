
-- Create study_rooms table for collaborative sessions
CREATE TABLE public.study_rooms (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  domain TEXT,
  created_by UUID NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  max_participants INTEGER NOT NULL DEFAULT 10,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create study_room_participants table
CREATE TABLE public.study_room_participants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.study_rooms(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  display_name TEXT NOT NULL DEFAULT 'Student',
  is_online BOOLEAN NOT NULL DEFAULT true,
  joined_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_active_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  study_minutes INTEGER NOT NULL DEFAULT 0,
  UNIQUE(room_id, user_id)
);

-- Create study_room_messages table
CREATE TABLE public.study_room_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.study_rooms(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  display_name TEXT NOT NULL DEFAULT 'Student',
  content TEXT NOT NULL,
  is_ai_response BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.study_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.study_room_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.study_room_messages ENABLE ROW LEVEL SECURITY;

-- Study rooms policies (anyone authenticated can view/create)
CREATE POLICY "Anyone can view active rooms" ON public.study_rooms FOR SELECT USING (is_active = true);
CREATE POLICY "Authenticated users can create rooms" ON public.study_rooms FOR INSERT WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Room creators can update" ON public.study_rooms FOR UPDATE USING (auth.uid() = created_by);
CREATE POLICY "Room creators can delete" ON public.study_rooms FOR DELETE USING (auth.uid() = created_by);

-- Participants policies
CREATE POLICY "Anyone can view participants" ON public.study_room_participants FOR SELECT USING (true);
CREATE POLICY "Users can join rooms" ON public.study_room_participants FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own participation" ON public.study_room_participants FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can leave rooms" ON public.study_room_participants FOR DELETE USING (auth.uid() = user_id);

-- Messages policies
CREATE POLICY "Anyone can view room messages" ON public.study_room_messages FOR SELECT USING (true);
CREATE POLICY "Users can send messages" ON public.study_room_messages FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Enable realtime for rooms
ALTER PUBLICATION supabase_realtime ADD TABLE public.study_room_participants;
ALTER PUBLICATION supabase_realtime ADD TABLE public.study_room_messages;

-- Indexes
CREATE INDEX idx_room_participants_room ON public.study_room_participants(room_id);
CREATE INDEX idx_room_messages_room ON public.study_room_messages(room_id);
CREATE INDEX idx_study_rooms_active ON public.study_rooms(is_active);

-- Update timestamps trigger
CREATE TRIGGER update_study_rooms_updated_at BEFORE UPDATE ON public.study_rooms FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
