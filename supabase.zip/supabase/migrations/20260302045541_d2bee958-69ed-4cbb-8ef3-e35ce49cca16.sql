
-- Create a security definer function that returns leaderboard data
-- This bypasses RLS so we can aggregate across users safely
CREATE OR REPLACE FUNCTION public.get_leaderboard()
RETURNS TABLE (
  user_id uuid,
  display_name text,
  total_study_minutes bigint,
  total_sessions bigint,
  total_quizzes bigint,
  avg_quiz_score numeric,
  topics_completed bigint,
  current_streak integer
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.user_id,
    COALESCE(p.full_name, 'Anonymous') AS display_name,
    COALESCE(ss.total_minutes, 0)::bigint AS total_study_minutes,
    COALESCE(ss.session_count, 0)::bigint AS total_sessions,
    COALESCE(qr.quiz_count, 0)::bigint AS total_quizzes,
    COALESCE(qr.avg_score, 0)::numeric AS avg_quiz_score,
    COALESCE(ct.topic_count, 0)::bigint AS topics_completed,
    0 AS current_streak
  FROM profiles p
  LEFT JOIN (
    SELECT s.user_id, SUM(s.duration_minutes) AS total_minutes, COUNT(*) AS session_count
    FROM study_sessions s
    GROUP BY s.user_id
  ) ss ON ss.user_id = p.user_id
  LEFT JOIN (
    SELECT q.user_id, COUNT(*) AS quiz_count, AVG(q.score_percentage) AS avg_score
    FROM quiz_results q
    GROUP BY q.user_id
  ) qr ON qr.user_id = p.user_id
  LEFT JOIN (
    SELECT c.user_id, COUNT(*) AS topic_count
    FROM completed_topics c
    GROUP BY c.user_id
  ) ct ON ct.user_id = p.user_id
  WHERE p.onboarding_completed = true
  ORDER BY COALESCE(ss.total_minutes, 0) DESC
  LIMIT 50;
END;
$$;
