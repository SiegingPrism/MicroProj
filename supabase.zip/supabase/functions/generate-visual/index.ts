import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface VisualRequest {
  topic: string;
  context: string;
  style?: "detailed" | "simplified" | "diagram" | "concept";
  domain?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { topic, context, style = "detailed", domain } = await req.json() as VisualRequest;

    if (!topic) {
      return new Response(
        JSON.stringify({ error: "Topic is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) {
      console.error("LOVABLE_API_KEY not found");
      return new Response(
        JSON.stringify({ error: "API key not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Build the prompt based on style
    let styleInstructions = "";
    switch (style) {
      case "simplified":
        styleInstructions = "Create a simple, minimalist educational illustration with basic shapes and minimal text. Use clean lines and limited colors. Focus on the core concept only.";
        break;
      case "diagram":
        styleInstructions = "Create a clean, labeled diagram or flowchart showing the process or structure. Use boxes, arrows, and clear labels. Professional technical illustration style.";
        break;
      case "concept":
        styleInstructions = "Create a conceptual visualization or mind map showing relationships between ideas. Use connecting lines and hierarchical layout.";
        break;
      default:
        styleInstructions = "Create a detailed, educational illustration with rich visuals and annotations. Use vibrant colors and include relevant details.";
    }

    const domainContext = domain ? ` in the field of ${domain}` : "";
    
    const prompt = `Educational illustration${domainContext}: ${topic}. 
${context ? `Context: ${context}` : ""}
${styleInstructions}
The image should be clear, educational, and suitable for students. Include labels where appropriate. Professional quality, suitable for textbooks.`;

    console.log("Generating visual with prompt:", prompt);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-image",
        messages: [
          {
            role: "user",
            content: prompt
          }
        ],
        modalities: ["image", "text"]
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI Gateway error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Service temporarily unavailable. Please try again later." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      return new Response(
        JSON.stringify({ error: "Failed to generate visual" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    console.log("AI response received");

    const textContent = data.choices?.[0]?.message?.content || "";
    const images = data.choices?.[0]?.message?.images || [];
    
    if (images.length === 0) {
      return new Response(
        JSON.stringify({ 
          error: "No image was generated. Try rephrasing your request.",
          suggestion: "Try asking for a more specific visual, like 'diagram of photosynthesis' or 'illustration of cell structure'"
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const imageUrl = images[0]?.image_url?.url;

    return new Response(
      JSON.stringify({ 
        imageUrl,
        description: textContent,
        topic,
        style
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in generate-visual function:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
