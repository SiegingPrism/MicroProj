import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface StudyStats {
  totalMinutes: number;
  topicsCompleted: number;
  currentStreak: number;
  avgSessionLength: number;
  mostStudiedTopic: string;
}

interface WeaknessPattern {
  topic: string;
  frequency: number;
  indicators: string[];
  severity: "low" | "medium" | "high";
}

interface StudyBehavior {
  preferredStudyTime: string;
  avgSessionDuration: number;
  consistencyScore: number;
  topicDiversity: number;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { userId, domain, stats, analysisType = "full" } = await req.json() as {
      userId: string;
      domain: string | null;
      stats: StudyStats;
      analysisType?: "full" | "weaknesses" | "behavior" | "recommendations";
    };

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get user's profile for more context
    const { data: profile } = await supabase
      .from("profiles")
      .select("full_name, education_level, interests")
      .eq("user_id", userId)
      .single();

    // Get recent study sessions for pattern analysis
    const { data: recentSessions } = await supabase
      .from("study_sessions")
      .select("topic, duration_minutes, started_at")
      .eq("user_id", userId)
      .order("started_at", { ascending: false })
      .limit(50);

    // Get chat messages to analyze learning patterns and weaknesses
    const { data: chatMessages } = await supabase
      .from("chat_messages")
      .select("content, role, created_at, conversation_id")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(100);

    // Analyze study behavior patterns
    const studyBehavior = analyzeStudyBehavior(recentSessions || []);
    
    // Detect weaknesses from chat interactions
    const weaknessPatterns = detectWeaknessPatterns(chatMessages || []);

    // Build context for AI
    const domainName = domain?.replace("_", " & ").replace(/^\w/, (c) => c.toUpperCase()) || "General";
    const interests = profile?.interests?.join(", ") || "various topics";
    
    const sessionSummary = recentSessions?.length 
      ? `Recent topics studied: ${[...new Set(recentSessions.map(s => s.topic))].slice(0, 5).join(", ")}`
      : "No recent sessions recorded";

    // Extract question patterns from chat
    const userQuestions = chatMessages?.filter(m => m.role === "user").map(m => m.content) || [];
    const questionTopics = extractQuestionTopics(userQuestions);

    const systemPrompt = `You are an AI learning companion providing personalized study recommendations and analysis. Be concise, actionable, and encouraging.

Student Profile:
- Domain: ${domainName}
- Education Level: ${profile?.education_level || "Not specified"}
- Interests: ${interests}
- Total Study Time: ${Math.round(stats.totalMinutes / 60)} hours
- Topics Completed: ${stats.topicsCompleted}
- Current Streak: ${stats.currentStreak} days
- Average Session: ${stats.avgSessionLength} minutes
- Most Studied: ${stats.mostStudiedTopic}
- ${sessionSummary}

Study Behavior Analysis:
- Preferred Study Time: ${studyBehavior.preferredStudyTime}
- Consistency Score: ${studyBehavior.consistencyScore}/100
- Topic Diversity: ${studyBehavior.topicDiversity} different topics

Recent Questions/Topics Asked About:
${questionTopics.slice(0, 10).join("\n")}

Detected Weakness Patterns:
${weaknessPatterns.map(w => `- ${w.topic}: ${w.severity} severity (asked ${w.frequency} times)`).join("\n") || "No clear weaknesses detected yet"}

Provide a JSON response with:
1. "recommendation": A personalized 2-3 sentence recommendation based on their patterns
2. "focus_areas": Array of 2-3 specific topics they should focus on next
3. "study_tips": Array of 2-3 practical study tips tailored to their habits
4. "weaknesses": Array of detected weakness areas with suggested improvements
5. "behavior_insights": Object with insights about their study behavior
6. "visualization_suggestions": Array of 2-3 topics that would benefit from visual diagrams`;

    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!lovableApiKey) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${lovableApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: "Generate comprehensive study analysis and personalized recommendations for this student." },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`AI API error: ${error}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    let recommendations;
    try {
      recommendations = JSON.parse(content);
    } catch {
      recommendations = {
        recommendation: content || "Keep up your great study habits! Focus on consistency and try to maintain your current streak.",
        focus_areas: [stats.mostStudiedTopic || "Core concepts", "Practice problems", "Review sessions"],
        study_tips: [
          "Try the Pomodoro technique: 25 minutes of focused study, 5 minute break",
          "Review notes within 24 hours for better retention",
          "Practice active recall instead of passive reading",
        ],
        weaknesses: weaknessPatterns.map(w => ({
          area: w.topic,
          suggestion: `Review foundational concepts in ${w.topic}`,
        })),
        behavior_insights: studyBehavior,
        visualization_suggestions: ["Key concepts overview", "Process flowcharts", "Mind maps"],
      };
    }

    // Add raw analysis data
    recommendations.raw_analysis = {
      studyBehavior,
      weaknessPatterns,
      questionTopics: questionTopics.slice(0, 15),
      sessionCount: recentSessions?.length || 0,
      messageCount: chatMessages?.length || 0,
    };

    return new Response(JSON.stringify(recommendations), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error in ai-insights:", error);
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        recommendation: "Keep studying consistently! Regular practice is key to mastery.",
        focus_areas: ["Review fundamentals", "Practice exercises"],
        study_tips: ["Set specific daily goals", "Take regular breaks"],
        weaknesses: [],
        behavior_insights: {
          preferredStudyTime: "Unknown",
          avgSessionDuration: 0,
          consistencyScore: 0,
          topicDiversity: 0,
        },
        visualization_suggestions: [],
        raw_analysis: null,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

function analyzeStudyBehavior(sessions: { started_at: string; duration_minutes: number; topic: string }[]): StudyBehavior {
  if (sessions.length === 0) {
    return {
      preferredStudyTime: "Unknown",
      avgSessionDuration: 0,
      consistencyScore: 0,
      topicDiversity: 0,
    };
  }

  // Analyze preferred study time
  const hourCounts: Record<number, number> = {};
  sessions.forEach(s => {
    const hour = new Date(s.started_at).getHours();
    hourCounts[hour] = (hourCounts[hour] || 0) + 1;
  });
  
  const peakHour = Object.entries(hourCounts)
    .sort((a, b) => b[1] - a[1])[0]?.[0] || "12";
  
  const hour = parseInt(peakHour);
  let preferredStudyTime = "Morning (6-12)";
  if (hour >= 12 && hour < 17) preferredStudyTime = "Afternoon (12-5)";
  else if (hour >= 17 && hour < 21) preferredStudyTime = "Evening (5-9)";
  else if (hour >= 21 || hour < 6) preferredStudyTime = "Night (9-6)";

  // Calculate average session duration
  const avgSessionDuration = Math.round(
    sessions.reduce((sum, s) => sum + s.duration_minutes, 0) / sessions.length
  );

  // Calculate consistency score (based on regular study patterns)
  const studyDates = [...new Set(sessions.map(s => new Date(s.started_at).toDateString()))];
  const daySpan = sessions.length > 0 
    ? Math.max(1, Math.ceil((new Date(sessions[0].started_at).getTime() - new Date(sessions[sessions.length - 1].started_at).getTime()) / (1000 * 60 * 60 * 24)))
    : 1;
  const consistencyScore = Math.min(100, Math.round((studyDates.length / daySpan) * 100));

  // Calculate topic diversity
  const uniqueTopics = new Set(sessions.map(s => s.topic));
  const topicDiversity = uniqueTopics.size;

  return {
    preferredStudyTime,
    avgSessionDuration,
    consistencyScore,
    topicDiversity,
  };
}

function detectWeaknessPatterns(messages: { content: string; role: string; created_at: string }[]): WeaknessPattern[] {
  const userMessages = messages.filter(m => m.role === "user");
  
  // Keywords that indicate struggle or confusion
  const struggleIndicators = [
    "don't understand", "confused", "help me", "explain again",
    "what is", "how does", "why does", "can you explain",
    "still unclear", "not sure", "difficult", "hard to understand",
    "wrong", "mistake", "error", "problem with"
  ];

  // Track topic mentions and struggle indicators
  const topicStruggles: Record<string, { count: number; indicators: string[] }> = {};

  userMessages.forEach(msg => {
    const content = msg.content.toLowerCase();
    const hasStruggle = struggleIndicators.some(indicator => content.includes(indicator));
    
    if (hasStruggle) {
      // Extract potential topic (simple word extraction)
      const words = content.split(/\s+/).filter(w => w.length > 4);
      words.forEach(word => {
        const cleanWord = word.replace(/[^a-z]/g, "");
        if (cleanWord.length > 4 && !struggleIndicators.some(i => i.includes(cleanWord))) {
          if (!topicStruggles[cleanWord]) {
            topicStruggles[cleanWord] = { count: 0, indicators: [] };
          }
          topicStruggles[cleanWord].count++;
          const matchedIndicator = struggleIndicators.find(i => content.includes(i));
          if (matchedIndicator && !topicStruggles[cleanWord].indicators.includes(matchedIndicator)) {
            topicStruggles[cleanWord].indicators.push(matchedIndicator);
          }
        }
      });
    }
  });

  // Convert to weakness patterns
  return Object.entries(topicStruggles)
    .filter(([_, data]) => data.count >= 2)
    .map(([topic, data]): WeaknessPattern => ({
      topic: topic.charAt(0).toUpperCase() + topic.slice(1),
      frequency: data.count,
      indicators: data.indicators,
      severity: data.count >= 5 ? "high" : data.count >= 3 ? "medium" : "low",
    }))
    .sort((a, b) => b.frequency - a.frequency)
    .slice(0, 5);
}

function extractQuestionTopics(questions: string[]): string[] {
  const topics: string[] = [];
  
  questions.forEach(q => {
    // Simple extraction - get the main subject of questions
    const cleaned = q.replace(/[?!.,]/g, "").toLowerCase();
    const words = cleaned.split(/\s+/);
    
    // Look for key phrases
    const importantWords = words.filter(w => 
      w.length > 4 && 
      !["about", "could", "would", "should", "please", "explain", "understand", "there", "where", "which", "these", "those"].includes(w)
    );
    
    if (importantWords.length > 0) {
      topics.push(importantWords.slice(0, 3).join(" "));
    }
  });

  // Return unique topics
  return [...new Set(topics)];
}
