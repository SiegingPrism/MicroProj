import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface Message {
  role: "user" | "assistant" | "system";
  content: string;
}

const domainInfo: Record<string, { name: string; topics: string[] }> = {
  tech_engineering: {
    name: "Technology & Engineering",
    topics: ["programming", "software development", "computer science", "engineering", "electronics", "robotics", "AI", "machine learning", "data science", "web development", "mobile development", "databases", "networking", "cybersecurity", "cloud computing", "DevOps", "algorithms", "data structures", "mathematics for CS", "physics for engineering"]
  },
  business_management: {
    name: "Business & Management",
    topics: ["business", "management", "marketing", "finance", "accounting", "economics", "entrepreneurship", "leadership", "human resources", "operations", "strategy", "project management", "sales", "business analytics", "supply chain", "organizational behavior", "business law", "corporate finance", "investment", "banking"]
  },
  sciences: {
    name: "Sciences",
    topics: ["biology", "chemistry", "physics", "mathematics", "astronomy", "geology", "environmental science", "ecology", "genetics", "microbiology", "biochemistry", "organic chemistry", "inorganic chemistry", "mechanics", "thermodynamics", "electromagnetism", "quantum physics", "statistics", "calculus", "research methods"]
  },
  arts_humanities: {
    name: "Arts & Humanities",
    topics: ["literature", "history", "philosophy", "art", "music", "theater", "film studies", "creative writing", "linguistics", "cultural studies", "sociology", "psychology", "anthropology", "political science", "international relations", "ethics", "religious studies", "archaeology", "communication", "media studies"]
  },
  other: {
    name: "General Studies",
    topics: ["general knowledge", "study skills", "research methods", "critical thinking", "writing skills", "presentation skills", "time management", "learning techniques", "exam preparation", "note-taking", "memory techniques", "academic writing", "citation", "plagiarism prevention", "educational resources"]
  }
};

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, domain } = await req.json() as { messages: Message[]; domain?: string };

    if (!messages || !Array.isArray(messages)) {
      return new Response(
        JSON.stringify({ error: "Messages array is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) {
      console.error("LOVABLE_API_KEY not found");
      return new Response(
        JSON.stringify({ error: "API key not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const userDomain = domain && domainInfo[domain] ? domainInfo[domain] : domainInfo.other;
    
    const systemPrompt: Message = {
      role: "system",
      content: `You are an intelligent AI study companion specialized in ${userDomain.name}. 

IMPORTANT DOMAIN RESTRICTION:
- You are ONLY allowed to help with topics related to: ${userDomain.topics.join(", ")}
- If a user asks about a topic that is NOT related to ${userDomain.name}, you MUST politely decline and say: "I'm sorry, but that topic is outside my area of expertise. I'm specialized in ${userDomain.name} and can only help with related subjects like ${userDomain.topics.slice(0, 5).join(", ")}, etc. Please ask me something within this domain!"
- Be strict about this - do not provide detailed answers for off-topic questions

Your role within ${userDomain.name}:
1. Help students understand complex topics by breaking them down into simple explanations
2. Answer questions thoroughly with examples and analogies when helpful
3. Encourage curiosity and deeper learning
4. Provide step-by-step explanations for problem-solving
5. Be supportive, patient, and encouraging
6. Use clear formatting with bullet points and numbered lists when appropriate
7. If you don't know something, be honest about it
8. Suggest related topics or follow-up questions to explore within ${userDomain.name}

Always maintain a friendly, educational tone that makes learning enjoyable.`
    };

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [systemPrompt, ...messages],
        max_tokens: 2048,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI Gateway error:", errorText);
      return new Response(
        JSON.stringify({ error: "Failed to get AI response" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    const assistantMessage = data.choices?.[0]?.message?.content || "I couldn't generate a response.";

    return new Response(
      JSON.stringify({ response: assistantMessage }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in ai-chat function:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
