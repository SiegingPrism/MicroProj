import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { subjects, preferences, existingSchedule, domain } = await req.json();

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: "API key not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const systemPrompt = `You are an expert study schedule optimizer. Create an optimal weekly study schedule based on:
- Student's subjects and topics to cover
- Their preferences (morning/evening person, session length preferences)
- Their domain of study: ${domain || 'General'}
- Any existing commitments

Return a JSON object with this exact structure:
{
  "schedule": [
    {
      "day": 0-6 (0=Sunday),
      "subject": "Subject name",
      "startTime": "HH:MM",
      "endTime": "HH:MM",
      "priority": "high" | "medium" | "low",
      "tips": "Study tips for this session"
    }
  ],
  "recommendations": [
    "General recommendation 1",
    "General recommendation 2"
  ],
  "weeklyHours": 20
}

Optimize for:
1. Spaced repetition - don't cram same subject
2. Difficult subjects when alert (based on preferences)
3. Breaks between sessions
4. Balance across the week`;

    const userPrompt = `Create a study schedule for:
Subjects: ${JSON.stringify(subjects)}
Preferences: ${JSON.stringify(preferences)}
Existing schedule: ${JSON.stringify(existingSchedule || [])}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI Gateway error:", errorText);
      return new Response(
        JSON.stringify({ error: "Failed to generate schedule" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";
    
    // Parse JSON from response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return new Response(
        JSON.stringify({ error: "Failed to parse schedule data" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const scheduleData = JSON.parse(jsonMatch[0]);

    return new Response(
      JSON.stringify(scheduleData),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in study-scheduler:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
